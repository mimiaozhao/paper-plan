import hashlib
import json
from pathlib import Path
import sys
import zipfile
import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'scripts'))
import build_release
import install_paper_plugin


def test_release_allowlist_and_checksums_exclude_local_data(tmp_path):
    result=build_release.build(tmp_path/'release')
    with zipfile.ZipFile(result['archive']) as archive:
        prefix=f'paper-plan-{build_release.VERSION}-windows/'
        manifest=json.loads(archive.read(prefix+'PACKAGE.json'))
        names=archive.namelist()
        assert all(not build_release.FORBIDDEN_PARTS.intersection(Path(n).parts) for n in names)
        assert not any('restart_bridge_host' in n or 'TEST_RESULTS' in n for n in names)
        for item in manifest['files']:
            assert hashlib.sha256(archive.read(prefix+item['path'])).hexdigest()==item['sha256']
        assert prefix+'Install.cmd' in names
        assert prefix+'USAGE.md' in names
        assert prefix+'goal-fulltext.png' in names
    assert not (Path(result['public_source'])/'data').exists()


def test_release_audit_rejects_runtime_data_and_secret_markers(tmp_path):
    (tmp_path/'data').mkdir()
    private=tmp_path/'data'/'plans.sqlite3';private.write_text('test-only')
    with pytest.raises(ValueError):build_release.audit(tmp_path)
    private.unlink()
    token=tmp_path/'oops.txt';token.write_text('ghp_'+'x'*40)
    with pytest.raises(ValueError):build_release.audit(tmp_path)


def test_prepare_resolves_relocated_unicode_paths(tmp_path,monkeypatch):
    root=tmp_path/'Chinese path'/'中文 空格'
    (root/'.venv/Scripts').mkdir(parents=True)
    (root/'.venv/Scripts/python.exe').write_text('test executable placeholder')
    (root/'frontend/dist').mkdir(parents=True)
    (root/'frontend/dist/index.html').write_text('test UI')
    (root/'skills/plan-panel').mkdir(parents=True)
    (root/'skills/plan-panel/SKILL.md').write_text('Read runtime.json for the installation path.')
    for folder in ('backend','scripts','schema'):(root/folder).mkdir()
    monkeypatch.setattr(install_paper_plugin,'ROOT',root)
    monkeypatch.setattr(install_paper_plugin,'MARKETPLACE',root/'marketplace')
    plugin=root/'marketplace/plugins/paper-plan'
    monkeypatch.setattr(install_paper_plugin,'PLUGIN',plugin)
    install_paper_plugin.prepare()
    runtime=json.loads((plugin/'runtime.json').read_text())
    mcp=json.loads((plugin/'.mcp.json').read_text())['mcpServers']['paper-plan']
    assert runtime['project']==str(root) and mcp['cwd']==str(root)
    assert mcp['command']==str(root/'.venv/Scripts/python.exe')
    assert mcp['args']==[str(root/'scripts/mcp_server.py')]


def test_existing_release_is_not_overwritten(tmp_path):
    (tmp_path/'github-source').mkdir()
    with pytest.raises(ValueError,match='never overwritten'):build_release.build(tmp_path)
