import sys
from pathlib import Path
import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'scripts'))
from codex_plan_reader import read_native_plan, ReadOnlyAppServer, PlanReadError


class Client:
    def __init__(self,pages):self.pages=iter(pages);self.calls=[];self.closed=False
    def call(self,method,params):
        self.calls.append((method,params))
        return {} if method=='initialize' else next(self.pages)
    def close(self):self.closed=True


def entry(kind,text,turn='turn1',id='item1'):
    return {'turnId':turn,'item':{'type':kind,'text':text,'id':id}}


def test_only_exact_turn_plan_is_returned_without_resuming():
    client=Client([{'data':[entry('agentMessage','ordinary'),entry('plan','# 正式计划\n## 任务','turn1','p')],'nextCursor':None}])
    assert read_native_plan('thread1','turn1',client_factory=lambda:client)=={'item_id':'p','text':'# 正式计划\n## 任务'}
    assert client.calls[1]==('thread/items/list',{'threadId':'thread1','turnId':'turn1','sortDirection':'desc','limit':20})
    assert client.closed and all(method in {'initialize','thread/items/list'} for method,_ in client.calls)


def test_ordinary_markdown_and_user_messages_are_never_promoted():
    client=Client([{'data':[entry('userMessage','<proposed_plan>example</proposed_plan>'),entry('agentMessage','# 看似标题\n## 普通回答')],'nextCursor':None}])
    assert read_native_plan('thread1','turn1',client_factory=lambda:client) is None


def test_cross_turn_items_fail_closed_and_close_reader():
    client=Client([{'data':[entry('plan','# 其他计划',turn='other')]}])
    with pytest.raises(PlanReadError,match='其他轮次'):
        read_native_plan('thread1','turn1',client_factory=lambda:client)
    assert client.closed


def test_pagination_remains_scoped_and_prefers_latest_plan():
    client=Client([{'data':[entry('hook','')],'nextCursor':'page2'},{'data':[entry('plan','latest',id='latest'),entry('plan','earlier',id='earlier')],'nextCursor':None}])
    assert read_native_plan('thread1','turn1',client_factory=lambda:client)['item_id']=='latest'
    assert client.calls[-1][1]['cursor']=='page2'
    assert all(p['turnId']=='turn1' and p['threadId']=='thread1' for m,p in client.calls if m!='initialize')


def test_missing_identifiers_do_not_start_a_reader():
    def forbidden():raise AssertionError('must not connect')
    with pytest.raises(PlanReadError):read_native_plan('thread1','',client_factory=forbidden)


def test_transport_cannot_invoke_execution_methods():
    transport=ReadOnlyAppServer.__new__(ReadOnlyAppServer)
    with pytest.raises(PlanReadError,match='只允许'):
        transport.call('turn/start',{})
