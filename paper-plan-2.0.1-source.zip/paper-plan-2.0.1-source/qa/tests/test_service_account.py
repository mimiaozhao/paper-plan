import pytest
from backend import runtime_context


def test_real_account_not_inherited_profile_controls_launch(monkeypatch,tmp_path):
    monkeypatch.setenv('USERPROFILE',str(tmp_path/'DesktopUser'))
    monkeypatch.setenv('PLAN_PANEL_DISPATCH','1')
    monkeypatch.setattr(runtime_context,'runtime_account',lambda:'CodexSandboxOffline')
    with pytest.raises(RuntimeError,match='隔离账户'):
        runtime_context.require_dispatch_account()
    monkeypatch.setattr(runtime_context,'runtime_account',lambda:'DesktopUser')
    runtime_context.require_dispatch_account()


def test_isolated_test_server_can_explicitly_disable_delivery(monkeypatch):
    monkeypatch.setenv('PLAN_PANEL_DISPATCH','0')
    monkeypatch.setattr(runtime_context,'runtime_account',lambda:'CodexSandboxOffline')
    runtime_context.require_dispatch_account()
