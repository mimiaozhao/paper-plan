from unittest.mock import patch
import subprocess
import pytest
from backend.dispatcher import dispatch_to_codex

THREAD = '11111111-1111-4111-8111-111111111111'


@pytest.fixture(autouse=True)
def desktop_account(monkeypatch):
    monkeypatch.setattr('backend.dispatcher.restricted_runtime',lambda:False)


def test_sandbox_service_cannot_attempt_desktop_delivery(monkeypatch):
    monkeypatch.setenv('PLAN_PANEL_DISPATCH','1')
    monkeypatch.setattr('backend.dispatcher.restricted_runtime',lambda:True)
    with patch('backend.dispatcher.subprocess.run') as run:
        result=dispatch_to_codex(THREAD,'private request')
        assert result['status']=='manual' and '隔离账户' in result['error']
        run.assert_not_called()


def test_delivery_reports_transport_reason_without_echoing_message(monkeypatch):
    monkeypatch.setenv('PLAN_PANEL_DISPATCH','1')
    with patch('backend.dispatcher.codex_executable',return_value='codex.exe'), patch('backend.dispatcher.subprocess.run',return_value=subprocess.CompletedProcess([],1,'','failed to connect: os error 10050; secret-message')):
        result=dispatch_to_codex(THREAD,'secret-message')
        assert '无法连接' in result['error'] and '退出码 1' in result['error']
        assert 'secret-message' not in result['error']


def test_disabled_dispatch_never_calls_cli(monkeypatch):
    monkeypatch.setenv('PLAN_PANEL_DISPATCH', '0')
    with patch('backend.dispatcher.subprocess.run') as run:
        assert dispatch_to_codex(THREAD, 'test')['status'] == 'manual'
        run.assert_not_called()


def test_invalid_thread_never_calls_cli(monkeypatch):
    monkeypatch.setenv('PLAN_PANEL_DISPATCH', '1')
    with patch('backend.dispatcher.subprocess.run') as run:
        assert dispatch_to_codex('not-a-uuid', 'test')['status'] == 'manual'
        run.assert_not_called()


def test_queue_uses_exact_thread_and_argument_list(monkeypatch):
    monkeypatch.setenv('PLAN_PANEL_DISPATCH', '1')
    message = '原对话执行；$(no-shell)\n真实换行'
    with patch('backend.dispatcher.codex_executable', return_value='codex.exe'), patch('backend.dispatcher.subprocess.run', return_value=subprocess.CompletedProcess([], 0, '', '')) as run:
        assert dispatch_to_codex(THREAD, message) == {'status': 'queued', 'error': None}
        assert run.call_args.args[0] == ['codex.exe', 'queue', '--thread', THREAD, '--message', message]
        assert run.call_args.kwargs['shell'] is False
        assert run.call_args.kwargs['timeout'] == 15
        assert '--model' not in run.call_args.args[0]


def test_failed_delivery_does_not_claim_execution(monkeypatch):
    monkeypatch.setenv('PLAN_PANEL_DISPATCH', '1')
    with patch('backend.dispatcher.codex_executable', return_value='codex.exe'), patch('backend.dispatcher.subprocess.run', return_value=subprocess.CompletedProcess([], 1, '', 'unknown thread')):
        result = dispatch_to_codex(THREAD, 'test')
        assert result['status'] == 'manual' and result['error']


def test_ambiguous_timeout_does_not_retry(monkeypatch):
    monkeypatch.setenv('PLAN_PANEL_DISPATCH', '1')
    with patch('backend.dispatcher.codex_executable', return_value='codex.exe'), patch('backend.dispatcher.subprocess.run', side_effect=subprocess.TimeoutExpired('codex', 15)) as run:
        result = dispatch_to_codex(THREAD, 'test')
        assert result['status'] == 'manual' and '检查' in result['error']
        assert run.call_count == 1
