"""Independent boundary QA for the installed skill fallback; no HTTP/model side effects."""
from __future__ import annotations

import importlib.util
import io
import json
import sys
from pathlib import Path

import httpx
import pytest

PROJECT = Path(__file__).resolve().parents[2]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


@pytest.fixture
def api(monkeypatch):
    monkeypatch.setenv("PLAN_PANEL_API_URL", "http://127.0.0.1:8776")
    return load_module("qa_bridge_api", PROJECT / "scripts" / "bridge_api.py")


@pytest.mark.parametrize("base", ["http://127.0.0.1:8776/", "http://localhost:8776", "http://[::1]:8776"])
def test_fallback_accepts_only_local_http_base(api, monkeypatch, base):
    monkeypatch.setenv("PLAN_PANEL_API_URL", base)
    assert api.api_base() == base.rstrip("/")


@pytest.mark.parametrize("base", [
    "https://127.0.0.1:8776", "http://example.test:8776", "http://127.0.0.1.example.test:8776",
    "http://user:secret@127.0.0.1:8776", "http://127.0.0.1:8776/api",
    "http://127.0.0.1:8776?thread=wrong", "http://127.0.0.1:8776#wrong", "file:///tmp/service",
])
def test_external_or_ambiguous_service_is_rejected_before_http(api, monkeypatch, base):
    monkeypatch.setenv("PLAN_PANEL_API_URL", base)
    contacted = []
    def forbidden_client(**kwargs):
        contacted.append(kwargs)
        raise AssertionError("Unsafe service must never be contacted")
    # api_base is a preflight used by public helpers; check it directly, without relying on transport failure.
    monkeypatch.setattr(api.httpx, "Client", forbidden_client)
    with pytest.raises(ValueError, match="loopback"):
        api.api_base()
    assert contacted == []


def test_thread_request_encodes_untrusted_segments_and_preserves_authorized_payload(api, monkeypatch):
    seen = []
    def record(method, route, payload=None):
        seen.append((method, route, payload))
        return {"state": None}
    monkeypatch.setattr(api, "request", record)
    thread = "task/a?foreign=1#x"
    continuation = "request/x?replace=1"
    token = "opaque-claim-token"
    payload = {"claim_token": token, "status": "completed", "output": "中文结果\n保留来源", "error": None}
    api.complete_thread_continuation(thread, continuation, payload)
    assert seen == [("POST", "/threads/task%2Fa%3Fforeign%3D1%23x/continuations/request%2Fx%3Freplace%3D1/complete", payload)]
    result = api.get_thread_plan(thread)
    assert result["panel_url"] == "http://127.0.0.1:8776/?thread=task%2Fa%3Fforeign%3D1%23x"
    assert seen[-1][1] == "/threads/task%2Fa%3Fforeign%3D1%23x/plan"
    api.get_confirmed_thread_plan(thread, "v/id?new=1")
    assert seen[-1][1].endswith("/confirmed-plan?version_id=v%2Fid%3Fnew%3D1")


def test_http_client_ignores_system_proxy_and_keeps_business_errors(api, monkeypatch):
    original_client = httpx.Client
    options = []
    captured = []
    def respond(request):
        captured.append(request)
        return httpx.Response(409, json={"detail": {"message": "确认版本已过期，重新读取计划。"}})
    def client_factory(**kwargs):
        options.append(kwargs)
        return original_client(transport=httpx.MockTransport(respond), **kwargs)
    monkeypatch.setattr(api.httpx, "Client", client_factory)
    with pytest.raises(ValueError, match="HTTP 409：确认版本已过期"):
        api.request_thread_continuation("qa-current-thread", 3, "snapshot-3")
    assert options == [{"timeout": 25, "trust_env": False}]
    assert str(captured[0].url) == "http://127.0.0.1:8776/api/threads/qa-current-thread/continuations"
    assert json.loads(captured[0].content) == {"expected_version": 3, "version_id": "snapshot-3"}


def test_unavailable_service_recovers_once_then_reports_failure(api, monkeypatch):
    import service_runtime
    starts=[]
    monkeypatch.setattr(service_runtime,'ensure_service',lambda:starts.append(True))
    original_client = httpx.Client
    attempted = []
    def disconnected(request):
        attempted.append(str(request.url))
        raise httpx.ConnectError("offline", request=request)
    monkeypatch.setattr(api.httpx, "Client", lambda **kwargs: original_client(transport=httpx.MockTransport(disconnected), **kwargs))
    with pytest.raises(ValueError, match="服务不可用"):
        api.get_thread_plan("qa-current-thread")
    assert attempted == ["http://127.0.0.1:8776/api/threads/qa-current-thread/plan"]*2
    assert starts==[True]


def test_ambiguous_http_timeout_never_repeats_a_write(api,monkeypatch):
    import service_runtime
    starts=[];attempted=[]
    monkeypatch.setattr(service_runtime,'ensure_service',lambda:starts.append(True))
    original_client=httpx.Client
    def timeout(request):
        attempted.append(request)
        raise httpx.ReadTimeout('response unknown',request=request)
    monkeypatch.setattr(api.httpx,'Client',lambda **kwargs:original_client(transport=httpx.MockTransport(timeout),**kwargs))
    with pytest.raises(ValueError,match='服务不可用'):
        api.request('POST','/threads/t/continuations',{'expected_version':1})
    assert len(attempted)==1 and not starts


@pytest.fixture
def cli(api, monkeypatch):
    output, errors = io.StringIO(), io.StringIO()
    monkeypatch.setattr(sys, "stdout", output)
    monkeypatch.setattr(sys, "stderr", errors)
    monkeypatch.setattr(sys, "path", sys.path.copy())
    monkeypatch.setitem(sys.modules, "bridge_api", api)
    module = load_module("qa_bridge_cli", PROJECT / "scripts" / "bridge.py")
    return module, output, errors


def test_cli_unicode_bom_file_is_scoped_and_never_implicitly_confirms_or_dispatches(cli, api, monkeypatch, tmp_path, capsys):
    module, output, errors = cli
    payload = {"document": {"title": "研究计划", "goal": "用户锁定内容 $(不执行) `保留`"}, "expected_version": 7}
    payload_path = tmp_path / "中文计划.json"
    payload_path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8-sig")
    seen = []
    monkeypatch.setattr(api, "request", lambda method, route, body=None: seen.append((method, route, body)) or {"更新": "成功"})
    monkeypatch.setattr(sys, "argv", ["bridge.py", "update", "--thread", "qa-exact-thread", "--payload", str(payload_path)])
    assert module.main() == 0
    assert seen == [("PUT", "/threads/qa-exact-thread/plan", payload)]
    captured = capsys.readouterr(); assert json.loads(captured.out)["更新"] == "成功"
    assert "研究计划" in payload_path.read_text(encoding="utf-8-sig")
    assert captured.err == ""


@pytest.mark.parametrize("args", [
    ["get"], ["request", "--thread", "qa-thread"],
    ["claim", "--thread", "qa-thread", "--continuation-id", "qa-request"],
    ["complete", "--thread", "qa-thread", "--continuation-id", "qa-request"],
    ["dispatch", "--thread", "qa-thread"],
])
def test_cli_incomplete_authority_fails_before_any_request(cli, api, monkeypatch, args):
    module, _, _ = cli
    seen = []
    monkeypatch.setattr(api, "request", lambda *a, **k: seen.append((a, k)) or {})
    monkeypatch.setattr(sys, "argv", ["bridge.py", *args])
    with pytest.raises(SystemExit) as error:
        module.main()
    assert error.value.code == 2
    assert seen == []


def test_cli_request_and_claim_keep_exact_snapshot_and_claimant_without_dispatch(cli, api, monkeypatch, capsys):
    module, output, _ = cli
    seen = []
    monkeypatch.setattr(api, "request", lambda method, route, body=None: seen.append((method, route, body)) or {"status": "pending"})
    monkeypatch.setattr(sys, "argv", ["bridge.py", "request", "--thread", "qa-thread", "--version-id", "immutable-v4", "--expected-version", "4"])
    assert module.main() == 0
    monkeypatch.setattr(sys, "argv", ["bridge.py", "claim", "--thread", "qa-thread", "--continuation-id", "qa-request", "--claimant-id", "qa-thread:qa-request"])
    assert module.main() == 0
    assert seen == [
        ("POST", "/threads/qa-thread/continuations", {"expected_version": 4, "version_id": "immutable-v4"}),
        ("POST", "/threads/qa-thread/continuations/qa-request/claim", {"claimant_id": "qa-thread:qa-request"}),
    ]
    assert len(capsys.readouterr().out.splitlines()) == 2


def test_cli_completion_forwards_private_token_and_real_result_only_to_exact_request(cli, api, monkeypatch, tmp_path):
    module, _, _ = cli
    payload = {"claim_token": "private-token", "status": "failed", "output": "已完成部分：证据整理", "error": "缺少用户原始数据"}
    payload_path = tmp_path / "result.json"
    payload_path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    seen = []
    monkeypatch.setattr(api, "request", lambda method, route, body=None: seen.append((method, route, body)) or {"status": "failed"})
    monkeypatch.setattr(sys, "argv", ["bridge.py", "complete", "--thread", "qa-original-thread", "--continuation-id", "qa-original-request", "--payload", str(payload_path)])
    assert module.main() == 0
    assert seen == [("POST", "/threads/qa-original-thread/continuations/qa-original-request/complete", payload)]
