"""Installer edits only the owned legacy registration, including nested env settings."""
from pathlib import Path
import sys
import tomllib

sys.path.insert(0,str(Path(__file__).resolve().parents[2]/"scripts"))
from install_paper_plugin import remove_owned_mcp


def test_legacy_cleanup_preserves_other_servers_plugins_and_global_settings():
    source='''model = "existing-model"
[mcp_servers.plan_panel]
command = "python"
args = ["existing.py"]
[mcp_servers.plan_panel.env]
PLAN_PANEL_API_URL = "http://127.0.0.1:8765"
[mcp_servers.other]
command = "other"
[plugins."paper-plan@paper-plans-local"]
enabled = true
[plugins."existing@personal"]
enabled = false
'''
    before=tomllib.loads(source)
    after=tomllib.loads(remove_owned_mcp(source))
    del before['mcp_servers']['plan_panel']
    assert after==before


def test_no_legacy_registration_is_a_noop():
    source='''# user configuration
[mcp_servers.other]
command = "other"
'''
    assert remove_owned_mcp(source)==source
