"""Export backend-authoritative JSON Schema for TypeScript code generation."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from backend.models import PlanDocument


def complete_wire_schema(value):
    # API responses always include Pydantic defaults. Make that wire guarantee
    # explicit for generated frontend types instead of optional draft inputs.
    if isinstance(value, dict):
        if 'properties' in value:
            value['required'] = list(value['properties'])
        for nested in value.values():
            complete_wire_schema(nested)
    elif isinstance(value, list):
        for nested in value:
            complete_wire_schema(nested)


schema = PlanDocument.model_json_schema(mode='serialization')
complete_wire_schema(schema)
path = ROOT / 'schema' / 'plan-document.schema.json'
path.parent.mkdir(parents=True, exist_ok=True)
path.write_text(json.dumps(schema, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(path)
