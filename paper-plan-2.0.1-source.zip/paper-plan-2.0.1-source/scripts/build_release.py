"""Build an allowlisted public source tree and a relocatable Windows ZIP."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]
VERSION='2.0.1'
RUNTIME_SCRIPTS=('bridge.py','bridge_api.py','codex_plan_reader.py','install_paper_plugin.py','mcp_server.py','paper_hook.py','run_server.py','service_runtime.py')
FORBIDDEN_PARTS={'data','.venv','node_modules','__pycache__','.git','.pytest_cache','artifacts','plugin-backups'}
SENSITIVE_PATTERNS=(re.escape(str(ROOT)),re.escape(ROOT.as_posix()),r'(?i)[A-Z]:[/\\]+Users[/\\]+[^/\\\s\"\']+',r'01a[a-f0-9]{5}-[a-f0-9-]{27,}',r'(?i)(?:ghp_|github_pat_|sk-proj-)[A-Za-z0-9_]{20,}')


def copy_file(source:Path,target:Path):
    if source.is_symlink() or not source.is_file():
        raise ValueError(f'Expected a regular release file: {source.name}')
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)


def audit(folder:Path):
    for file in folder.rglob('*'):
        if file.is_symlink():raise ValueError('Release cannot contain symlinks')
        if not file.is_file():continue
        relative=file.relative_to(folder)
        if FORBIDDEN_PARTS.intersection(relative.parts) or file.suffix.lower() in {'.sqlite3','.sqlite','.db','.log','.pyc','.pem','.pfx'}:
            raise ValueError(f'Private/runtime file in release: {relative}')
        try:text=file.read_text(encoding='utf-8-sig')
        except UnicodeDecodeError:continue
        if any(re.search(pattern,text) for pattern in SENSITIVE_PATTERNS):
            raise ValueError(f'Personal path or secret marker in release: {relative}')


def runtime_tree(destination:Path):
    destination.mkdir(parents=True,exist_ok=False)
    for file in sorted((ROOT/'backend').glob('*.py')):copy_file(file,destination/'backend'/file.name)
    for name in ('requirements.txt','requirements-bridge.txt'):copy_file(ROOT/'backend'/name,destination/'backend'/name)
    for name in RUNTIME_SCRIPTS:copy_file(ROOT/'scripts'/name,destination/'scripts'/name)
    for file in sorted((ROOT/'frontend/dist').rglob('*')):
        if file.is_file():copy_file(file,destination/'frontend/dist'/file.relative_to(ROOT/'frontend/dist'))
    for relative in ('schema/plan-document.schema.json','skills/plan-panel/SKILL.md','install-plugin.ps1','stop.ps1','start.cmd'):
        copy_file(ROOT/relative,destination/relative)
    for source,name in (('Install.cmd','Install.cmd'),('start.ps1','start.ps1'),('README.md','README.md'),('USAGE.md','USAGE.md'),('goal-fulltext.png','goal-fulltext.png'),('RELEASE_NOTES.md','RELEASE_NOTES.md')):
        copy_file(ROOT/'distribution'/source,destination/name)


def build(output:Path) -> dict:
    if not (ROOT/'frontend/dist/index.html').is_file():raise ValueError('Build frontend before packaging')
    output=output.resolve()
    bundle=output/f'paper-plan-{VERSION}-windows'
    source=output/'github-source'
    if bundle.exists() or source.exists():raise ValueError('Use a new empty output folder; existing releases are never overwritten')
    output.mkdir(parents=True,exist_ok=True)
    runtime_tree(bundle)
    audit(bundle)
    files=[{'path':file.relative_to(bundle).as_posix(),'sha256':hashlib.sha256(file.read_bytes()).hexdigest()} for file in sorted(bundle.rglob('*')) if file.is_file()]
    (bundle/'PACKAGE.json').write_text(json.dumps({'name':'paper-plan','version':VERSION,'platform':'windows','files':files},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    archive=output/f'paper-plan-{VERSION}-windows.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as zip_file:
        for file in sorted(bundle.rglob('*')):
            if file.is_file():zip_file.write(file,f'{bundle.name}/{file.relative_to(bundle).as_posix()}')
    checksum=hashlib.sha256(archive.read_bytes()).hexdigest()
    (output/(archive.name+'.sha256')).write_text(f'{checksum}  {archive.name}\n',encoding='ascii')

    # Public sources are constructed separately; never `git add` the live app.
    runtime_tree(source)
    for file in (source/'frontend/dist').rglob('*'):
        if file.is_file():file.unlink()
    for folder in ('frontend/src','frontend/scripts','backend/tests','distribution'):
        for file in sorted((ROOT/folder).rglob('*')):
            if file.is_file() and not FORBIDDEN_PARTS.intersection(file.relative_to(ROOT).parts):copy_file(file,source/file.relative_to(ROOT))
    for relative in ('frontend/package.json','frontend/pnpm-lock.yaml','frontend/pnpm-workspace.yaml','frontend/tsconfig.json','frontend/vite.config.ts','frontend/index.html','backend/requirements-dev.txt','scripts/export_schema.py','scripts/build_release.py'):
        copy_file(ROOT/relative,source/relative)
    for file in sorted((ROOT/'qa/tests').glob('*.py')):
        if file.name!='test_bridge_recovery.py':copy_file(file,source/'qa/tests'/file.name)
    (source/'.gitignore').write_text('.venv/\n__pycache__/\n.pytest_cache/\nfrontend/node_modules/\nfrontend/dist/\nfrontend/*.tsbuildinfo\ndata/\nmarketplace/\nreleases/\nqa/artifacts/\n*.sqlite*\n*.log\n*.pid\n',encoding='utf-8')
    audit(source)
    report={'version':VERSION,'archive':str(archive),'sha256':checksum,'archive_bytes':archive.stat().st_size,'runtime_files':len(files),'public_source':str(source),'personal_data_included':False}
    (output/'build-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    arguments=parser.parse_args()
    print(json.dumps(build(arguments.output),ensure_ascii=False))
