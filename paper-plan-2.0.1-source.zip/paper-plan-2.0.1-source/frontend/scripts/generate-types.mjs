import { compileFromFile } from 'json-schema-to-typescript';
import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
const schema = fileURLToPath(new URL('../../schema/plan-document.schema.json',import.meta.url));
const target = fileURLToPath(new URL('../src/generated/plan-document.ts',import.meta.url));
await mkdir(fileURLToPath(new URL('../src/generated',import.meta.url)),{recursive:true});
const source = await compileFromFile(schema,{bannerComment:'/* Generated from backend Pydantic schema. Run pnpm generate:types; do not hand edit. */',style:{singleQuote:true}});
await writeFile(target,source,'utf8');
