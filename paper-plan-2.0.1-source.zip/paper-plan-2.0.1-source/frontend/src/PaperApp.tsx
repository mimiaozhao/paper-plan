import { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowUp, Check, ChevronDown, ChevronRight, Download, GripVertical, IndentDecrease, IndentIncrease, Play, Plus, Redo2, Save, Trash2, Undo2 } from 'lucide-react';
import type { PlanDocument, TreeNode } from './generated/plan-document';
import type { Continuation, PlanRevision, PlanState, PlanVersion } from './types';
import { api, download, json } from './api';
import ThreadApp from './ThreadApp';
import { descendants, flatten, keyboardMove, moveNode, newNode, normalize, removeNode, setHeadingLevel, toMarkdown } from './outlineTree';
import HeadingLevelInput from './HeadingLevelInput';
import GrowingTextarea from './GrowingTextarea';
import './paper.css';

type Runtime={permission_mode:string;turn_id:string;last_error:string};
type Candidate={turn_id:string;document:PlanDocument;base_version:number;reason?:string};
type View={state:PlanState|null;runtime:Runtime|null;sync?:{status:string;source_kind?:string;error?:string}|null;candidates:Candidate[];continuations:Continuation[];revisions?:PlanRevision[]};
const labels:Record<string,string>={pending:'待执行',running:'执行中',completed:'已完成',failed:'失败',superseded:'已被替代',cancelled:'已取消',interrupted:'已中断'};
const same=(a:unknown,b:unknown)=>JSON.stringify(a)===JSON.stringify(b);
const message=(error:unknown)=>error instanceof Error?error.message:String(error);

export default function PaperApp({threadId}:{threadId:string}){
  const path='/threads/'+encodeURIComponent(threadId);
  const [view,setView]=useState<View|null>(null);
  const [doc,setDoc]=useState<PlanDocument|null>(null);
  const [saved,setSaved]=useState<PlanState|null>(null);
  const [error,setError]=useState('');
  const [connectionError,setConnectionError]=useState('');
  const [notice,setNotice]=useState('');
  const [busy,setBusy]=useState(false);
  const [saving,setSaving]=useState(false);
  const [composing,setComposing]=useState(false);
  const [dirty,setDirty]=useState(false);
  const [external,setExternal]=useState<PlanState|null>(null);
  const [collapsed,setCollapsed]=useState<Set<string>>(new Set());
  const [expanded,setExpanded]=useState<Set<string>>(new Set());
  const [history,setHistory]=useState<PlanDocument[]>([]);
  const [future,setFuture]=useState<PlanDocument[]>([]);
  const [versions,setVersions]=useState<PlanVersion[]>([]);
  const [revisionOpen,setRevisionOpen]=useState(false);
  const [revisionNotes,setRevisionNotes]=useState('');
  const [drag,setDrag]=useState<string|null>(null);
  const [drop,setDrop]=useState<{id:string;placement:'before'|'after'|'inside'}|null>(null);
  const docRef=useRef(doc),savedRef=useRef(saved),dirtyRef=useRef(dirty),operation=useRef(false),alive=useRef(true);
  const composition=useRef(false);
  const restoreKey=`paper-plan:draft:${threadId}`;
  const restored=useRef(false);
  const refreshSequence=useRef(0);
  const active=view?.continuations.find(c=>c.status==='pending'||c.status==='running');
  const revision=view?.revisions?.find(r=>r.status==='pending'||r.status==='discussing');
  const locked=!!active;
  const disabled=busy||locked;
  const confirmed=!!saved?.confirmed&&!dirty;
  const recent=view?.continuations.find(c=>c.version_id===saved?.version_id);
  const lockLabel=active?.status==='running'?'执行中 · 已锁定':active?.delivery_status==='manual'?'投递失败 · 已锁定':'等待领取 · 已锁定';
  const latestRevision=view?.revisions?.[0];
  const seenRevision=useRef<{id:string;status:string}|null>(null);
  useEffect(()=>{
    if(!latestRevision)return;
    const previous=seenRevision.current;
    seenRevision.current={id:latestRevision.id,status:latestRevision.status};
    if(previous?.id!==latestRevision.id||previous.status===latestRevision.status)return;
    if(latestRevision.status==='completed'||latestRevision.status==='candidate'){
      setRevisionOpen(false);
      setNotice(latestRevision.status==='completed'?'再梳理后的完整计划已生成，请检查并重新确认。':'再梳理已完成；目录有人工修改，新计划已保留为候选，请比较后采用。');
    }
  },[latestRevision?.id,latestRevision?.status]);

  function adopt(state:PlanState,clear=false){
    savedRef.current=state;docRef.current=state.document;dirtyRef.current=false;
    setSaved(state);setDoc(state.document);setDirty(false);setExternal(null);
    if(clear){setHistory([]);setFuture([]);}
  }
  function change(next:PlanDocument,record=true){
    if(disabled)return;
    if(record&&docRef.current){const previous=docRef.current;setHistory(h=>[...h.slice(-99),previous]);setFuture([]);}
    docRef.current=next;dirtyRef.current=true;setDoc(next);setDirty(true);setError('');
    sessionStorage.setItem(restoreKey,JSON.stringify({version:savedRef.current?.version,document:next}));
  }
  async function refresh(){
    if(operation.current)return;
    const sequence=++refreshSequence.current;
    const result=await api<View>(path+'/outline');
    if(!alive.current||operation.current||sequence!==refreshSequence.current)return;
    const state=result.state;if(!state){setView(result);return;}
    if(savedRef.current&&(state.version<savedRef.current.version||(state.version===savedRef.current.version&&Date.parse(state.updated_at)<Date.parse(savedRef.current.updated_at))))return;
    setView(result);
    if(state.binding?.thread_id!==threadId)throw new Error('返回的计划不属于当前对话。');
    const executing=result.continuations.some(c=>c.status==='pending'||c.status==='running');
    if(executing&&dirtyRef.current){
      adopt(state);restored.current=false;setNotice('当前显示执行中的确认版本；本窗口未保存的修改已保留，将在执行结束后恢复。');
    }else if(dirtyRef.current||composition.current){
      if(state.version!==savedRef.current?.version)setExternal(state);
    }else if(!savedRef.current||state.version!==savedRef.current.version||state.confirmed!==savedRef.current.confirmed){adopt(state);}
    if(!restored.current&&!executing){
      restored.current=true;
      try{
        const raw=sessionStorage.getItem(restoreKey);const draft=raw?JSON.parse(raw):null;
        if(draft?.document?.id===state.document.id&&!same(draft.document,state.document)){
          docRef.current=draft.document;dirtyRef.current=true;setDoc(draft.document);setDirty(true);
          if(draft.version!==state.version)setExternal(state);
          setNotice('已恢复本窗口未保存的修改。');
        }
      }catch{sessionStorage.removeItem(restoreKey);}
    }
  }
  useEffect(()=>{
    alive.current=true;let timer:ReturnType<typeof setTimeout>;
    if(!/^[A-Za-z0-9_-]{1,128}$/.test(threadId)){setError('无效的对话标识。');return;}
    const poll=async()=>{try{await refresh();if(alive.current)setConnectionError('');}catch(e){if(alive.current)setConnectionError(message(e));}if(alive.current)timer=setTimeout(poll,1800);};
    void poll();return()=>{alive.current=false;clearTimeout(timer);};
  },[threadId]);
  useEffect(()=>{const leave=(e:BeforeUnloadEvent)=>{if(dirtyRef.current){e.preventDefault();e.returnValue='';}};window.addEventListener('beforeunload',leave);return()=>window.removeEventListener('beforeunload',leave);},[]);

  async function save(){
    const current=savedRef.current,document=docRef.current;
    if(!current||!document)throw new Error('计划尚未生成。');
    if(!dirtyRef.current)return current;
    if(external)throw new Error('存在另一版本，请先比较并处理冲突。');
    const state=await api<PlanState>('/plans/'+document.id,{...json({document,expected_version:current.version}),method:'PUT'});
    // A save acknowledges the submitted snapshot, not whatever the user has
    // typed since. Keep the live document/DOM and caret untouched on every ack.
    savedRef.current=state;setSaved(state);
    const pending=docRef.current!==document;
    dirtyRef.current=pending;setDirty(pending);
    if(pending)sessionStorage.setItem(restoreKey,JSON.stringify({version:state.version,document:docRef.current}));
    else sessionStorage.removeItem(restoreKey);
    return state;
  }
  async function perform(action:()=>Promise<void>,background=false){
    if(operation.current)return;
    operation.current=true;++refreshSequence.current;if(background)setSaving(true);else setBusy(true);setError('');
    try{await action();}catch(e){setError(message(e));}finally{operation.current=false;if(background)setSaving(false);else setBusy(false);try{await refresh();setConnectionError('');}catch(e){setConnectionError(message(e));}}
  }
  useEffect(()=>{
    if(!dirty||busy||saving||composing||locked||external||error||connectionError)return;
    const timer=setTimeout(()=>{if(!composition.current)void perform(async()=>{await save();},true);},800);
    return()=>clearTimeout(timer);
  },[doc,dirty,busy,saving,composing,locked,external,error,connectionError]);
  function setTree(tree:TreeNode[]){if(doc)change({...doc,tree});}
  function updateNode(id:string,patch:Partial<TreeNode>){if(doc)setTree(doc.tree.map(n=>n.id===id?{...n,...patch}:n));}
  function toggle(setter:React.Dispatch<React.SetStateAction<Set<string>>>,id:string){setter(value=>{const next=new Set(value);next.has(id)?next.delete(id):next.add(id);return next;});}
  function transform(action:()=>TreeNode[]){try{setTree(action());setDrop(null);setDrag(null);}catch(e){setError(message(e));}}
  function add(parent:string|null,after?:string){
    if(!doc)return;
    const siblings=doc.tree.filter(n=>n.parent_id===parent);
    const node=newNode(parent,Math.max(-1,...siblings.map(n=>n.order))+1);
    let tree=[...doc.tree,node];if(after)tree=moveNode(tree,node.id,after,'after');
    setTree(normalize(tree));setExpanded(e=>new Set([...e,node.id]));
    if(parent)setCollapsed(e=>{const next=new Set(e);next.delete(parent);return next;});
  }
  function undo(){if(!history.length||disabled)return;const previous=history[history.length-1];setFuture(f=>[doc!,...f]);setHistory(h=>h.slice(0,-1));change(previous,false);}
  function redo(){if(!future.length||disabled)return;const next=future[0];setHistory(h=>[...h,doc!]);setFuture(f=>f.slice(1));change(next,false);}
  async function start(){
    if(!saved||!confirmed)return;
    let item=active;
    if(!item)item=await api<Continuation>(path+'/continuations',json({expected_version:saved.version,version_id:saved.version_id}));
    const sent=await api<Continuation>(path+'/continuations/'+item.id+'/dispatch',json({}));
    setNotice(sent.delivery_status==='queued'?'请求已投递；领取前会核对当前模式和确认版本。':sent.delivery_error??'请在原对话发送继续指令。');
  }
  async function sendRevision(notes=revisionNotes){
    const state=await save();
    const item=await api<PlanRevision>(path+'/revisions',json({expected_version:state.version,version_id:state.version_id,notes}));
    await deliverRevision(item);
  }
  async function deliverRevision(item:PlanRevision){
    const sent=await api<PlanRevision>(path+'/revisions/'+item.id+'/dispatch',json({}));
    setRevisionOpen(true);
    setNotice(sent.delivery_status==='queued'?'再修改请求已发送到原对话。请在计划模式回答 Codex 的问题；不会开始执行计划。':sent.delivery_error??'请复制再修改指令到原对话。');
  }
  if(saved?.document.schema_version===1)return <ThreadApp threadId={threadId}/>;
  const rows=doc?flatten(doc.tree):[];
  const hidden=new Set<string>();
  for(const id of collapsed)if(doc)for(const child of descendants(doc.tree,id))if(child!==id)hidden.add(child);
  const parents=new Set(doc?.tree.map(n=>n.parent_id));
  const leafNodes=doc?.tree.filter(n=>!parents.has(n.id))??[];
  function progress(id:string){
    if(!doc||!recent)return null;
    if(!parents.has(id))return recent.progress?.[id];
    const children=descendants(doc.tree,id);const leaves=leafNodes.filter(n=>children.has(n.id));
    const entries=leaves.map(n=>recent.progress?.[n.id]);
    const done=entries.filter(p=>p?.status==='completed').length;
    return {status:done===leaves.length?'completed':entries.some(p=>p?.status==='running')?'running':entries.some(p=>p?.status==='failed')?'failed':entries.some(p=>p?.status==='interrupted')?'interrupted':'pending',output:`${done}/${leaves.length}`,evidence:'',adjustment_reason:''};
  }
  return <main className="paper-app" onCompositionStartCapture={()=>{composition.current=true;setComposing(true);}} onCompositionEndCapture={()=>{composition.current=false;setComposing(false);}}>
    <header className="paper-header"><div className="paper-brand"><span className="paper-mark">目</span><div><strong>论文式计划</strong><span>当前对话 · 可编辑目录</span></div></div><span className={'paper-state '+(locked?'is-locked':'')}>{locked?lockLabel:saving?'正在保存…':dirty?'有未保存修改':revision?'再修改中 · v'+revision.version:confirmed?'已确认 · v'+saved?.version:saved?'草稿 · v'+saved.version:'等待计划'}</span></header>
    {error&&<div role="alert" className="paper-alert">{error}<button onClick={()=>setError('')}>关闭</button></div>}
    {connectionError&&<div role="alert" className="paper-alert">{connectionError} 正在自动重连，本地修改已保留。</div>}
    {view?.runtime?.last_error&&<div role="alert" className="paper-alert">自动同步失败：{view.runtime.last_error}</div>}
    {notice&&<div role="status" className="paper-notice">{notice}<button onClick={()=>setNotice('')}>关闭</button></div>}
    {!!view?.candidates.length&&<section className="paper-conflict" aria-label="新的正式计划"><strong>新的正式计划待比较 · {view.candidates.length}</strong>{view.candidates.map(c=><div key={c.turn_id} className="paper-candidate"><h2>{c.document.title}</h2><p>{c.reason||'生成期间目录有变化或存在未结束请求，已保留当前版本。采用后需要重新确认。'}</p><details><summary>比较目录</summary><div className="paper-compare"><pre>{doc?toMarkdown(doc.title,doc.tree):'尚无目录'}</pre><pre>{toMarkdown(c.document.title,c.document.tree)}</pre></div></details><div className="paper-actions"><button disabled={disabled||saving||composing||dirty||!!external} onClick={()=>void perform(async()=>{const result=await api<{state:PlanState}>(path+'/candidates/'+c.turn_id,json({expected_version:saved!.version,accept:true}));adopt(result.state,true);sessionStorage.removeItem(restoreKey);restored.current=true;setNotice('已采用新的正式计划，请检查目录并重新确认。');})}>采用此计划</button><button disabled={disabled||saving||composing||dirty} onClick={()=>void perform(async()=>{await api(path+'/candidates/'+c.turn_id,json({expected_version:saved!.version,accept:false}));})}>保留当前版本</button></div>{locked&&<p>先取消未领取请求，或停止正在执行的任务，再采用新计划。</p>}</div>)}</section>}
    {external&&<section className="paper-conflict"><strong>另一窗口已有新版本；你的修改已保留。</strong><div className="paper-actions"><button onClick={()=>download('未保存目录.json',JSON.stringify(doc,null,2))}>导出我的修改</button><button disabled={disabled||saving||composing} onClick={()=>{adopt(external,true);sessionStorage.removeItem(restoreKey);}}>采用最新版本</button></div><details><summary>比较两个版本</summary><pre>{JSON.stringify({我的修改:doc,服务器版本:external.document},null,2)}</pre></details></section>}
    {!doc?<section className="paper-empty"><span className="paper-empty-number">1 / 1.1 / 1.1.1</span><h1>{view?.sync?.status==='error'?'计划同步未完成':view?.sync?.status==='ignored'?'本轮尚无正式计划':'计划将在这里展开'}</h1><p>{view?.sync?.status==='error'?'同步错误见上方提示；聊天中的完整计划仍然保留。':view?.sync?.status==='ignored'?'本轮已结束，未检测到正式计划条目。正常问答不会生成目录。':'在当前对话的计划模式中继续讨论。正式计划生成后，多级标题会自动出现。'}</p><p className="paper-muted">{view?.runtime?'已收到当前对话的钩子事件。':'尚未收到当前对话的钩子事件，请检查插件是否已启用并信任。'}</p></section>:<>
      <section className="paper-title"><input aria-label="计划名称" disabled={disabled} value={doc.title} onChange={e=>change({...doc,title:e.target.value})}/><p>拖动调整先后，或输入级别 1、2、3…；展开标题补充具体要求。</p></section>
      <nav className="paper-toolbar" aria-label="目录操作"><div className="paper-actions"><button disabled={disabled} onClick={()=>add(null)}><Plus size={15}/>添加标题</button><button aria-label="撤销" title="撤销" disabled={disabled||!history.length} onClick={undo}><Undo2 size={16}/></button><button aria-label="重做" title="重做" disabled={disabled||!future.length} onClick={redo}><Redo2 size={16}/></button><button title="导出 Markdown" aria-label="导出 Markdown" onClick={()=>download(doc.title+'.md',toMarkdown(doc.title,doc.tree))}><Download size={16}/></button></div><div className="paper-actions"><button disabled={disabled||saving||composing||!dirty} onClick={()=>void perform(async()=>{await save();},true)}><Save size={15}/>保存</button><button disabled={disabled||!!external} onClick={()=>setRevisionOpen(v=>!v)}>再修改</button><button className="paper-primary" disabled={disabled||saving||composing||!!revision||confirmed||!!external} onClick={()=>void perform(async()=>{const state=await save();adopt(await api<PlanState>('/plans/'+state.document.id+'/confirm',json({expected_version:state.version})));setNotice('已确认。切回 Codex 执行模式后，点击“开始执行”。');})}><Check size={15}/>确认计划</button></div></nav>
      {(revisionOpen||revision)&&<section className="paper-revision" aria-label="再修改计划">
        <strong>让 Codex 再梳理一遍</strong>
        {!revision?<>
          <p>先将当前 Codex 对话切换到计划模式。发送后，Codex 会依据你编辑后的目录先问问题，需求明确后再给完整新计划。</p>
          <label>这次重点想调整什么（可选）<textarea rows={3} maxLength={12000} disabled={busy||locked} value={revisionNotes} onChange={e=>setRevisionNotes(e.target.value)} placeholder="例如：重新安排论证顺序，帮我找出缺少的内容"/></label>
          <div className="paper-actions"><button className="paper-primary" disabled={disabled||saving||composing||!!external} onClick={()=>void perform(()=>sendRevision())}>已切到计划模式，发送提问</button><button disabled={busy} onClick={()=>setRevisionOpen(false)}>收起</button></div>
          <p className="paper-muted">会先保存当前修改，无需先确认执行。此按钮不能自动切换 Codex 模式。</p>
        </>:<>
          <p>{revision.status==='discussing'?'已送达原对话，请在计划模式继续回答问题。':revision.delivery_status==='queued'?'请求已排队，等待原对话开始提问。':revision.delivery_status==='manual'?'尚未成功发送，可以重试或复制指令。':'请求尚未发送。'} 本次依据 v{revision.version}。</p>
          {revision.notes&&<p>调整重点：{revision.notes}</p>}
          <p className="paper-muted">问答期间仍可编辑。若目录又有变化，新计划会作为候选保留，采用后需重新确认。</p>
          {revision.delivery_error&&<p role="alert">{revision.delivery_error}</p>}
          <div className="paper-actions">
            {revision.status==='pending'&&!['sending','queued'].includes(revision.delivery_status)&&<button disabled={busy||saving||dirty||saved?.version_id!==revision.version_id} onClick={()=>void perform(()=>deliverRevision(revision))}>重试发送</button>}
            {(dirty||saved?.version_id!==revision.version_id)&&<button disabled={disabled||saving||composing||!!external} onClick={()=>void perform(()=>sendRevision(revision.notes))}>按最新目录重新发送</button>}
            <button disabled={busy||saving} onClick={()=>void perform(async()=>{await api(path+'/revisions/'+revision.id+'/cancel',json({}));setRevisionOpen(false);setNotice('已取消再修改请求，当前目录保留。');})}>取消再修改</button>
          </div>
          {revision.delivery_status==='manual'&&<details><summary>手动提问指令</summary><textarea readOnly aria-label="再修改指令" value={revision.message}/></details>}
        </>}
      </section>}
      <div className="paper-outline" role="tree" aria-label="计划目录">
        {rows.filter(r=>!hidden.has(r.node.id)).map(({node,number,depth})=>{
          const hasChildren=parents.has(node.id),details=expanded.has(node.id),p=progress(node.id);
          const target=drop?.id===node.id?drop.placement:null;
          return <article key={node.id} role="treeitem" aria-level={depth+1} aria-expanded={hasChildren?!collapsed.has(node.id):undefined} className={'paper-node '+(target?'drop-'+target:'')} data-node-id={node.id} style={{'--depth':Math.min(depth,8)} as React.CSSProperties}
            onDragOver={event=>{if(!drag||disabled)return;event.preventDefault();event.stopPropagation();const box=event.currentTarget.querySelector('.paper-node-row')!.getBoundingClientRect();const y=event.clientY-box.top;setDrop({id:node.id,placement:y<box.height*.28?'before':y>box.height*.72?'after':'inside'});}}
            onDrop={event=>{event.preventDefault();event.stopPropagation();if(drag&&drop&&!disabled)transform(()=>moveNode(doc.tree,drag,drop.id,drop.placement));}}
          >
            {target&&<div className="paper-drop-label">{target==='inside'?'移为此标题的子项':target==='before'?'插入此标题之前':'插入此标题之后'}</div>}
            <div className="paper-node-row">
              <button className="paper-grip" aria-label={`移动 ${number}`} title="拖动，或 Alt＋方向键调整层级与顺序" draggable={!disabled} disabled={disabled} onDragStart={e=>{e.dataTransfer.setData('text/plain',node.id);e.dataTransfer.effectAllowed='move';setDrag(node.id);}} onDragEnd={()=>{setDrag(null);setDrop(null);}} onKeyDown={e=>{const action=({ArrowUp:'up',ArrowDown:'down',ArrowRight:'indent',ArrowLeft:'outdent'} as const)[e.key as 'ArrowUp'];if(e.altKey&&action){e.preventDefault();transform(()=>keyboardMove(doc.tree,node.id,action));}}}><GripVertical size={15}/></button>
              <button className="paper-fold" aria-label={`${collapsed.has(node.id)?'展开':'折叠'}子标题 ${number}`} disabled={!hasChildren} onClick={()=>toggle(setCollapsed,node.id)}>{hasChildren?(collapsed.has(node.id)?<ChevronRight size={16}/>:<ChevronDown size={16}/>):<span className="paper-leaf-dot"/>}</button>
              <span className="paper-number">{number}</span><input aria-label={`标题 ${number}`} value={node.title} disabled={disabled} onChange={e=>updateNode(node.id,{title:e.target.value})}/>
              {p&&<span className={'paper-progress '+p.status}>{hasChildren?p.output:labels[p.status]}</span>}
              <HeadingLevelInput level={depth+1} number={number} disabled={disabled} onCommit={level=>{
                const current=docRef.current;
                if(!current||busy||locked)return;
                const tree=setHeadingLevel(current.tree,node.id,level);
                change({...current,tree});
                const moved=tree.find(item=>item.id===node.id);
                if(moved?.parent_id)setCollapsed(value=>{const next=new Set(value);let parent=moved.parent_id;while(parent){next.delete(parent);parent=tree.find(item=>item.id===parent)?.parent_id??null;}return next;});
              }}/>
              <button className="paper-detail-toggle" aria-label={`${details?'收起':'展开'}详情 ${number}`} aria-expanded={details} onClick={()=>toggle(setExpanded,node.id)}>{details?'收起':'详情'}</button>
            </div>
            {details&&<div className="paper-node-details">
              <fieldset disabled={disabled}><label>具体要求<textarea rows={4} value={node.details} onChange={e=>updateNode(node.id,{details:e.target.value})}/></label><label>预期产出<textarea rows={2} value={node.output} onChange={e=>updateNode(node.id,{output:e.target.value})}/></label><label>验收条件<span>每行一项</span><textarea rows={2} value={node.acceptance_criteria.join('\n')} onChange={e=>updateNode(node.id,{acceptance_criteria:e.target.value?e.target.value.split('\n'):[]})}/></label>
                {!hasChildren&&<details className="paper-dependencies"><summary>前置任务 {node.depends_on.length?`· ${node.depends_on.length}`:''}</summary>{leafNodes.filter(n=>n.id!==node.id).map(n=><label key={n.id}><input type="checkbox" checked={node.depends_on.includes(n.id)} onChange={e=>updateNode(node.id,{depends_on:e.target.checked?[...node.depends_on,n.id]:node.depends_on.filter(i=>i!==n.id)})}/>{n.title}</label>)}</details>}
                <div className="paper-node-actions"><button onClick={()=>add(node.parent_id,node.id)}><Plus size={13}/>同级</button><button onClick={()=>add(node.id)}><Plus size={13}/>子级</button><button aria-label={`上移 ${number}`} title="上移" onClick={()=>transform(()=>keyboardMove(doc.tree,node.id,'up'))}><ArrowUp size={14}/></button><button aria-label={`下移 ${number}`} title="下移" onClick={()=>transform(()=>keyboardMove(doc.tree,node.id,'down'))}><ArrowDown size={14}/></button><button aria-label={`缩进 ${number}`} title="缩进" onClick={()=>transform(()=>keyboardMove(doc.tree,node.id,'indent'))}><IndentIncrease size={14}/></button><button aria-label={`取消缩进 ${number}`} title="取消缩进" onClick={()=>transform(()=>keyboardMove(doc.tree,node.id,'outdent'))}><IndentDecrease size={14}/></button><button className="paper-delete" aria-label={`删除 ${number}`} title="删除标题及全部子项（可撤销）" onClick={()=>setTree(removeNode(doc.tree,node.id))}><Trash2 size={14}/></button></div>
              </fieldset>
              {p&&<div className="paper-node-result"><strong>执行记录</strong>{p.output&&<p>{p.output}</p>}{p.evidence&&<p>验证依据：{p.evidence}</p>}{p.adjustment_reason&&<p>调序原因：{p.adjustment_reason}</p>}</div>}
            </div>}
          </article>;
        })}
      </div>
      <section className="paper-execution"><div><strong>{active?.waiting_for_context?'等待桥接恢复':active?.waiting_for_mode?'等待切换执行模式':active?active.status==='running'?'正在按确认目录执行':active.delivery_status==='manual'?'投递失败，尚未执行':'等待原对话领取':recent?labels[recent.status]:'准备执行'}</strong><p>{locked?'内容和结构已锁定；仍可展开标题查看详情。':confirmed?'先手动切回 Codex 执行模式，再开始执行。':'调整目录后确认计划，即可交回原对话。'}</p></div><div className="paper-actions">{active?.status==='pending'&&<button disabled={busy} onClick={()=>void perform(async()=>{await api(path+'/continuations/'+active.id+'/cancel',json({}));setNotice('未执行请求已取消，可以继续编辑或采用新计划。');})}>取消请求并解锁</button>}{active?.status!=='running'&&<button className="paper-primary" disabled={busy||saving||composing||!!revision||!confirmed||!!external||!!active&&!active.waiting_for_mode&&!active.waiting_for_context&&active.delivery_status!=='manual'} onClick={()=>void perform(start)}><Play size={15}/>{active?.waiting_for_context?'重试桥接':active?.waiting_for_mode?'已切换，重试':active?.delivery_status==='manual'?'重试投递':'开始执行'}</button>}</div>{active?.status==='running'&&<p className="paper-muted">需要停止时，请使用 Codex 对话中的停止按钮。</p>}
        {active?.blocked_reason&&<p className="paper-bridge-blocked" role="status">{active.blocked_reason}</p>}
        {active?.delivery_status==='manual'&&<details><summary>手动继续指令</summary><p>复制以下内容，在当前同一对话发送：</p><textarea readOnly value={active.message}/></details>}
      </section>
      <section className="paper-secondary">
        <details><summary>全局要求</summary><fieldset disabled={disabled}><label>最终目标<span>全文 · {Array.from(doc.goal).length} 字</span><GrowingTextarea aria-label="最终目标" value={doc.goal} onChange={e=>change({...doc,goal:e.target.value})}/></label>{doc.constraints.map((c,i)=><label key={c.id}>约束 {i+1}<GrowingTextarea aria-label={`约束 ${i+1}`} value={c.text} onChange={e=>change({...doc,constraints:doc.constraints.map(v=>v.id===c.id?{...v,text:e.target.value}:v)})}/></label>)}<button onClick={()=>change({...doc,constraints:[...doc.constraints,{id:crypto.randomUUID(),text:'',locked:false}]})}>添加全局约束</button>{doc.assumptions.map(a=><label key={a.id}>{a.text}<select value={a.status} onChange={e=>change({...doc,assumptions:doc.assumptions.map(v=>v.id===a.id?{...v,status:e.target.value as typeof a.status}:v)})}><option value="pending">待确认</option><option value="accepted">接受</option><option value="rejected">拒绝</option></select></label>)}</fieldset></details>
        <details onToggle={e=>{if(e.currentTarget.open&&saved)void api<{versions:PlanVersion[]}>('/plans/'+saved.document.id+'/versions').then(r=>setVersions(r.versions)).catch(e=>setError(message(e)));}}><summary>版本记录</summary>{versions.map(v=><details key={v.id}><summary>v{v.version} · {v.confirmed?'已确认':'草稿'}</summary><pre>{v.document.schema_version===2?toMarkdown(v.document.title,v.document.tree):JSON.stringify(v.document,null,2)}</pre></details>)}</details>
        <details><summary>执行记录 · {view?.continuations.length??0}</summary>{view?.continuations.map(c=><div key={c.id} className="paper-run"><strong>v{c.version} · {labels[c.status]}</strong>{c.output&&<pre>{c.output}</pre>}{c.error&&<p>{c.error}</p>}</div>)}</details>
      </section>
    </>}
    <footer className="paper-footer">本地保存 · 原对话执行 · 目录顺序优先</footer>
  </main>;
}
