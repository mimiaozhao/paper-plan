export class ApiError extends Error {
  status:number; detail:unknown;
  constructor(message:string,status:number,detail:unknown){super(message);this.status=status;this.detail=detail;}
}
export async function api<T>(path:string,options:RequestInit={}):Promise<T>{
  let response:Response;
  try {response=await fetch(`/api${path}`,{...options,headers:{'Content-Type':'application/json',...options.headers}});}
  catch(error){if(error instanceof DOMException && error.name==='AbortError')throw error;throw new ApiError('无法连接本地服务。请确认程序已启动，再重试。',0,null);}
  const data=await response.json().catch(()=>null);
  if(!response.ok){
    const detail=data?.detail??data;
    const message=typeof detail==='string'?detail:Array.isArray(detail)?detail.map(item=>[item.loc?.join('.'),item.msg].filter(Boolean).join('：')).join('；').slice(0,500):detail?.message??`请求失败（${response.status}）`;
    throw new ApiError(message,response.status,detail);
  }
  return data as T;
}
export const json=(value:unknown):Pick<RequestInit,'method'|'body'>=>({method:'POST',body:JSON.stringify(value)});
export function download(filename:string,content:string,type='text/plain;charset=utf-8'){
  const url=URL.createObjectURL(new Blob([content],{type}));const anchor=document.createElement('a');anchor.href=url;anchor.download=filename;anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
