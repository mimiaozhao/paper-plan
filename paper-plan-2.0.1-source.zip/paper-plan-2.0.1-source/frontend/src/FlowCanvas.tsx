import { useMemo, useRef, useState } from 'react';
import { ReactFlow, Background, BackgroundVariant, Controls, MiniMap, Handle, Position, MarkerType, applyNodeChanges, applyEdgeChanges, type Node, type NodeProps, type NodeChange, type EdgeChange, type Connection, type ReactFlowInstance } from '@xyflow/react';
import dagre from '@dagrejs/dagre';
import { ArrowUpRight, Check, FileText, LockKeyhole, Plus, Scan, Workflow } from 'lucide-react';
import type { PlanDocument, PlanNode } from './types';

type TaskData = {task:PlanNode;index:number;incoming:number;outgoing:number;selected:boolean;[key:string]:unknown};
type TaskFlowNode = Node<TaskData,'task'>;
const TASK_WIDTH=320;
const TASK_HEIGHT=220;
function TaskCard({data}:NodeProps<TaskFlowNode>){
  const {task,index,incoming,outgoing}=data;
  return <div className={`task-card ${data.selected?'selected':''}`} data-testid={`node-card-${task.id}`}>
    <Handle type="target" position={Position.Left} aria-label={`连接到 ${task.title}`} />
    <div className="task-top"><span className="task-number">{String(index+1).padStart(2,'0')}</span><span className="task-id">{task.id}</span>{task.locked_fields.length>0&&<LockKeyhole size={12} className="task-lock" />}</div>
    <h3 title={task.title}>{task.title||'未命名任务'}<ArrowUpRight size={18}/></h3>
    <p title={task.goal}>{task.goal||'填写任务目标，让计划更清晰。'}</p>
    <div className="task-footer"><span title={task.output_format}><FileText size={14}/>{task.output_format||'待定义输出'}</span><span>{incoming} 入 · {outgoing} 出</span></div>
    <Handle type="source" position={Position.Right} aria-label={`从 ${task.title} 连接`} />
  </div>;
}
const nodeTypes={task:TaskCard};
export function layoutDocument(document:PlanDocument):PlanDocument{
  const graph=new dagre.graphlib.Graph();graph.setDefaultEdgeLabel(()=>({}));graph.setGraph({rankdir:'LR',nodesep:56,ranksep:88,marginx:40,marginy:40});
  document.nodes.forEach(node=>graph.setNode(node.id,{width:TASK_WIDTH,height:TASK_HEIGHT}));
  document.edges.forEach(edge=>{if(document.nodes.some(n=>n.id===edge.source)&&document.nodes.some(n=>n.id===edge.target))graph.setEdge(edge.source,edge.target);});
  dagre.layout(graph);
  return {...document,layout:Object.fromEntries(document.nodes.map(node=>{const position=graph.node(node.id);return [node.id,{x:position.x-TASK_WIDTH/2,y:position.y-TASK_HEIGHT/2}];}))};
}
export function FlowCanvas({document,selected,onSelect,onChange,onAdd,disabled}:{document:PlanDocument;selected:string|null;onSelect:(id:string|null)=>void;onChange:(document:PlanDocument)=>void;onAdd:()=>void;disabled:boolean}){
  const [selectedEdge,setSelectedEdge]=useState<string|null>(null);
  const [zoom,setZoom]=useState(1);
  const canvasElement=useRef<HTMLDivElement|null>(null);
  const focusCanvas=()=>{canvasElement.current?.focus({preventScroll:true});requestAnimationFrame(()=>canvasElement.current?.focus({preventScroll:true}));};
  const instance=useRef<ReactFlowInstance<TaskFlowNode>|null>(null);
  const nodes=useMemo(()=>document.nodes.map((node,index):TaskFlowNode=>({id:node.id,type:'task',position:document.layout[node.id]??{x:40+(index%3)*(TASK_WIDTH+88),y:40+Math.floor(index/3)*(TASK_HEIGHT+56)},selected:selected===node.id,data:{task:node,index,selected:selected===node.id,incoming:document.edges.filter(e=>e.target===node.id).length,outgoing:document.edges.filter(e=>e.source===node.id).length}})),[document,selected]);
  const readingNode=nodes.find(node=>node.id===selected)??nodes[0];
  const readingViewport={x:32-(readingNode?.position.x??0),y:76-(readingNode?.position.y??0),zoom:1};
  const edges=useMemo(()=>document.edges.map(edge=>({...edge,selected:selectedEdge===edge.id,type:'smoothstep',markerEnd:{type:MarkerType.ArrowClosed,width:17,height:17},style:{stroke:'#718b7c',strokeWidth:2}})),[document.edges,selectedEdge]);
  function nodesChange(changes:NodeChange<TaskFlowNode>[]){
    if(disabled)return;
    const updates=changes.filter(change=>change.type==='position');
    if(!updates.length)return;
    const next=applyNodeChanges(updates,nodes);
    onChange({...document,layout:{...document.layout,...Object.fromEntries(next.map(node=>[node.id,node.position]))}});
  }
  function edgesChange(changes:EdgeChange[]){
    if(disabled)return;
    if(changes.some(c=>c.type==='remove'))onChange({...document,edges:applyEdgeChanges(changes,edges).map(({id,source,target})=>({id,source,target}))});
  }
  function connect(connection:Connection){
    if(disabled||!connection.source||!connection.target)return;
    if(document.edges.some(edge=>edge.source===connection.source&&edge.target===connection.target))return;
    onChange({...document,edges:[...document.edges,{id:`edge_${crypto.randomUUID().slice(0,8)}`,source:connection.source,target:connection.target}]});
  }
  return <div ref={canvasElement} className="flow-canvas" data-testid="flow-canvas" tabIndex={0} role="group" aria-label="可视化任务画布" onMouseDown={event=>event.currentTarget.focus({preventScroll:true})} onKeyDown={event=>{if(disabled||!['Delete','Backspace'].includes(event.key))return;event.preventDefault();if(selectedEdge){onChange({...document,edges:document.edges.filter(edge=>edge.id!==selectedEdge)});setSelectedEdge(null);}else if(selected){onChange({...document,nodes:document.nodes.filter(node=>node.id!==selected),edges:document.edges.filter(edge=>edge.source!==selected&&edge.target!==selected),output_outline:document.output_outline.map(item=>({...item,node_ids:item.node_ids.filter(id=>id!==selected)})),layout:Object.fromEntries(Object.entries(document.layout).filter(([id])=>id!==selected))});onSelect(null);}}}>
    <ReactFlow<TaskFlowNode> nodes={nodes} edges={edges} nodeTypes={nodeTypes} onInit={flow=>{instance.current=flow;}} onNodesChange={nodesChange} onEdgesChange={edgesChange} onConnect={connect} onNodeClick={(_,node)=>{setSelectedEdge(null);onSelect(node.id);focusCanvas();}} onEdgeClick={(_,edge)=>{setSelectedEdge(edge.id);onSelect(null);focusCanvas();}} onPaneClick={()=>{setSelectedEdge(null);onSelect(null);focusCanvas();}} nodesDraggable={!disabled} nodesConnectable={!disabled} elementsSelectable={!disabled} deleteKeyCode={null} defaultViewport={readingViewport} onMoveEnd={(_,viewport)=>setZoom(viewport.zoom)} minZoom={0.25} maxZoom={2} proOptions={{hideAttribution:true}}>
      <Background variant={BackgroundVariant.Dots} gap={20} size={1} color="#d9dfda" />
      <Controls showInteractive={false} position="bottom-left" />
      <MiniMap position="bottom-right" maskColor="rgba(248,250,247,0.7)" nodeColor="#a7c8bd" nodeBorderRadius={3} pannable zoomable/>
    </ReactFlow>
    <div className="canvas-topline"><span><Workflow size={15}/>依赖关系 · 从左到右</span><div className="canvas-view-tools"><button className="canvas-fit" aria-label="按实际大小阅读任务" title="恢复 100% 并定位当前任务" onClick={()=>instance.current?.setViewport(readingViewport,{duration:250})}>{Math.round(zoom*100)}%</button><button className="canvas-fit" aria-label="适应画布" title="查看完整任务图" onClick={()=>instance.current?.fitView({padding:0.15,maxZoom:1,duration:300})}><Scan size={16}/>全图</button></div></div>
    {!document.nodes.length&&<div className="canvas-empty"><Workflow size={30}/><h3>先添加一个任务</h3><p>将需求拆成可编辑、有明确产出的步骤。</p><button className="btn btn-primary" onClick={onAdd} disabled={disabled}><Plus size={15}/>添加任务</button></div>}
    <span className="canvas-guide"><Check size={11}/>拖动节点调整布局 · 连接圆点设置依赖</span>
  </div>;
}

