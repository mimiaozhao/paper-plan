import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowRight, BookOpen, Check, ChevronDown, Clock3, Download, FileJson2, GitBranch, History, Layers3, Loader2, Maximize2, Plus, RotateCcw, Save, ShieldCheck, Sparkles, Upload, Workflow, X } from 'lucide-react';
import { ReactFlowProvider } from '@xyflow/react';
import { api, download, json } from './api';
import type { CompileResult, Issue, PlanDocument, PlanState, PlanSummary, PlanVersion, Provider, ProviderId, Run, Segment } from './types';
import PaperApp from './PaperApp';
import { semanticKey, messageOf, issuesOf } from './planState';
import { FlowCanvas, layoutDocument } from './FlowCanvas';
import { GlobalPanel, NodeInspector, OutlineEditor } from './Editors';
import { Workbench, type BottomTab } from './Workbench';

const DEMO_REQUEST='为一个科研课题制定可执行的研究计划：先梳理研究问题与已有证据，再确定研究方法、设计实验，制定数据分析和验收标准，最后整理为结构清晰的研究计划书。面向研究生，语言简洁；任何尚不明确的信息请作为待确认假设。';
const readableTime=(value:string)=>new Date(value).toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'});
function Logo(){return <div className="brand"><span className="brand-mark"><Workflow size={22}/></span><span>planform<span className="brand-dot">.</span></span></div>;}
export default function App(){const thread=new URLSearchParams(window.location.search).get('thread');return thread!==null?<PaperApp threadId={thread}/>:<StandaloneApp/>;}
function StandaloneApp(){
  const [saved,setSaved]=useState<PlanState|null>(null);
  const [document,setDocument]=useState<PlanDocument|null>(null);
  const [plans,setPlans]=useState<PlanSummary[]>([]);
  const [providers,setProviders]=useState<Provider[]>([]);
  const [provider,setProvider]=useState<ProviderId>('mock');
  const [request,setRequest]=useState('');
  const [selected,setSelected]=useState<string|null>(null);
  const [canvasTab,setCanvasTab]=useState<'graph'|'outline'>('graph');
  const [bottomTab,setBottomTab]=useState<BottomTab>('prompt');
  const [compile,setCompile]=useState<CompileResult|null>(null);
  const [compiledKey,setCompiledKey]=useState('');
  const [compileError,setCompileError]=useState<string|null>(null);
  const [compilePending,setCompilePending]=useState(false);
  const [validation,setValidation]=useState<{key:string;issues:Issue[]}|null>(null);
  const [versions,setVersions]=useState<PlanVersion[]>([]);
  const [comparisonId,setComparisonId]=useState('');
  const [runVersionId,setRunVersionId]=useState('');
  const [runs,setRuns]=useState<Run[]>([]);
  const [selectedRun,setSelectedRun]=useState('');
  const [historyOpen,setHistoryOpen]=useState(false);
  const [busy,setBusy]=useState<string|null>('initializing');
  const [error,setError]=useState<string|null>(null);
  const [notice,setNotice]=useState<string|null>(null);
  const operation=useRef(false);
  const fileInput=useRef<HTMLInputElement|null>(null);
  const activeId=useRef<string|null>(null);
  const currentDocument=useRef(document);currentDocument.current=document;
  const key=useMemo(()=>document?semanticKey(document):'',[document]);
  const semanticDirty=!!document&&!!saved&&key!==semanticKey(saved.document);
  const layoutDirty=!!document&&!!saved&&JSON.stringify(document.layout)!==JSON.stringify(saved.document.layout);
  const dirty=semanticDirty||layoutDirty;
  const confirmed=!!saved?.confirmed&&!semanticDirty;
  const compilationCurrent=compiledKey===key;
  const issues=validation?.key===key?validation.issues:compilationCurrent?compile?.issues??[]:[];
  const disabled=!!busy;

  useEffect(()=>{if(!notice)return;const timer=setTimeout(()=>setNotice(null),4000);return()=>clearTimeout(timer);},[notice]);
  useEffect(()=>{const onLeave=(event:BeforeUnloadEvent)=>{if(dirty){event.preventDefault();event.returnValue='';}};window.addEventListener('beforeunload',onLeave);return()=>window.removeEventListener('beforeunload',onLeave);},[dirty]);
  const refreshPlans=useCallback(async()=>{const result=await api<{plans:PlanSummary[]}>('/plans');setPlans(result.plans);},[]);
  const refreshMetadata=useCallback(async(id:string)=>{
    const results=await Promise.allSettled([api<{versions:PlanVersion[]}>('/plans/'+id+'/versions'),api<{runs:Run[]}>('/plans/'+id+'/runs'),api<{plans:PlanSummary[]}>('/plans')]);
    if(activeId.current!==id)return;
    if(results[0].status==='fulfilled')setVersions(results[0].value.versions.sort((a,b)=>b.version-a.version));
    if(results[1].status==='fulfilled')setRuns(results[1].value.runs.sort((a,b)=>Date.parse(b.created_at)-Date.parse(a.created_at)));
    if(results[2].status==='fulfilled')setPlans(results[2].value.plans);
    const failed=results.find(result=>result.status==='rejected');if(failed?.status==='rejected')setNotice('计划已加载，但历史记录读取失败：'+messageOf(failed.reason));
  },[]);
  const installPlan=useCallback((state:PlanState)=>{
    const withLayout=Object.keys(state.document.layout).length<state.document.nodes.length?layoutDocument(state.document):state.document;
    activeId.current=state.document.id;setSaved(state);setDocument(withLayout);setSelected(state.document.nodes[0]?.id??null);setCanvasTab('graph');setCompile(null);setCompiledKey('');setCompileError(null);setValidation(null);setVersions([]);setRuns([]);setComparisonId('');setRunVersionId('');setSelectedRun('');setError(null);setHistoryOpen(false);
    try{localStorage.setItem('planform:last-plan',state.document.id);}catch{/* Persistence still works through the API. */}
  },[]);
  const initialize=useCallback(async()=>{
    if(operation.current)return;operation.current=true;setBusy('initializing');setError(null);
    try{
      const results=await Promise.allSettled([api<{providers:Provider[]}>('/providers'),api<{plans:PlanSummary[]}>('/plans')]);
      if(results[0].status==='fulfilled')setProviders(results[0].value.providers);
      if(results[1].status==='fulfilled'){
        setPlans(results[1].value.plans);
        let last:string|null=null;try{last=localStorage.getItem('planform:last-plan');}catch{/* Optional preference. */}
        if(last&&results[1].value.plans.some(plan=>plan.id===last)){const state=await api<PlanState>('/plans/'+last);installPlan(state);await refreshMetadata(last);}
      }
      const failed=results.find(result=>result.status==='rejected');if(failed?.status==='rejected')throw failed.reason;
    }catch(error){setError(messageOf(error));}
    finally{operation.current=false;setBusy(null);}
  },[installPlan,refreshMetadata]);
  useEffect(()=>{void initialize();},[initialize]);
  useEffect(()=>{
    if(!key){setCompile(null);setCompiledKey('');setCompilePending(false);return;}
    const controller=new AbortController();let stale=false;setCompilePending(true);setCompileError(null);
    const timer=setTimeout(async()=>{
      const doc=currentDocument.current;if(!doc)return;
      try{const result=await api<CompileResult>('/compile',{...json({document:doc}),signal:controller.signal});if(stale)return;setCompile(result);setCompiledKey(key);}
      catch(error){if(stale||(error instanceof DOMException&&error.name==='AbortError'))return;setCompile(null);setCompiledKey(key);setCompileError(messageOf(error));setValidation({key,issues:issuesOf(error)});}
      finally{if(!stale)setCompilePending(false);}
    },350);
    return()=>{stale=true;clearTimeout(timer);controller.abort();};
  },[key]);

  function updateDocument(next:PlanDocument){if(operation.current)return;setDocument(next);setError(null);if(!document||semanticKey(next)!==semanticKey(document))setValidation(null);}
  function canDiscard(){return !dirty||window.confirm('当前计划有尚未保存的修改。继续将丢弃这些修改。');}
  async function loadPlan(id:string){
    if(!id||operation.current||!canDiscard())return;operation.current=true;setBusy('loading');setError(null);
    try{const state=await api<PlanState>('/plans/'+id);installPlan(state);await refreshMetadata(id);}
    catch(error){setError(messageOf(error));}finally{operation.current=false;setBusy(null);}
  }
  function newPlan(){
    if(operation.current||!canDiscard())return;
    activeId.current=null;setDocument(null);setSaved(null);setSelected(null);setVersions([]);setRuns([]);setHistoryOpen(false);setError(null);setRequest('');
    try{localStorage.removeItem('planform:last-plan');}catch{/* Optional preference. */}
  }
  async function generate(demo=false){
    if(operation.current||(!demo&&!request.trim())||!canDiscard())return;
    operation.current=true;setBusy('generating');setError(null);
    try{const state=await api<PlanState>('/plans/generate',json({request:demo?DEMO_REQUEST:request,provider:demo?'mock':provider}));installPlan(state);await refreshMetadata(state.document.id);setNotice(demo?'演示计划已加载。先调整假设，再确认计划。':'可视化计划已生成。');}
    catch(error){setError(messageOf(error));}finally{operation.current=false;setBusy(null);}
  }
  async function saveDocument():Promise<PlanState>{
    if(!document||!saved)throw new Error('尚未选择计划。');
    if(!dirty)return saved;
    const state=await api<PlanState>('/plans/'+document.id,{method:'PUT',body:JSON.stringify({document,expected_version:saved.version})});setSaved(state);setDocument(state.document);await refreshMetadata(state.document.id);return state;
  }
  async function save(){
    if(operation.current||!document)return;operation.current=true;setBusy('saving');setError(null);
    try{await saveDocument();setNotice('草稿已保存到本地。');}
    catch(error){setError(messageOf(error));const found=issuesOf(error);if(found.length)setValidation({key,issues:found});}
    finally{operation.current=false;setBusy(null);}
  }
  async function confirmPlan(){
    if(operation.current||!document)return;operation.current=true;setBusy('confirming');setError(null);
    try{
      const state=await saveDocument();
      const checked=await api<{valid:boolean;issues:Issue[]}>('/validate',json({document:state.document,mode:'confirm'}));setValidation({key:semanticKey(state.document),issues:checked.issues});
      if(!checked.valid){setBottomTab('validation');setNotice('请先处理校验问题，再确认计划。');return;}
      const confirmedState=await api<PlanState>('/plans/'+state.document.id+'/confirm',json({expected_version:state.version}));setSaved(confirmedState);setDocument(confirmedState.document);setRunVersionId('');await refreshMetadata(state.document.id);setNotice('计划 v'+confirmedState.version+' 已确认，可以运行。');
    }catch(error){setError(messageOf(error));const found=issuesOf(error);if(found.length){setValidation({key,issues:found});setBottomTab('validation');}}
    finally{operation.current=false;setBusy(null);}
  }
  async function validate(){
    if(operation.current||!document)return;operation.current=true;setBusy('validating');setError(null);
    try{const result=await api<{valid:boolean;issues:Issue[]}>('/validate',json({document,mode:'confirm'}));setValidation({key,issues:result.issues});setNotice(result.valid?'计划通过确认校验。':'请修正列出的校验问题。');}
    catch(error){setError(messageOf(error));}finally{operation.current=false;setBusy(null);}
  }
  async function importFile(file:File){
    if(operation.current||!canDiscard())return;operation.current=true;setBusy('importing');setError(null);
    try{
      const parsed=JSON.parse(await file.text());const imported=parsed?.document??parsed;
      const state=await api<PlanState>('/plans',json({document:imported}));installPlan(state);await refreshMetadata(state.document.id);setNotice('JSON 计划已导入为独立草稿。');
    }catch(error){setError(error instanceof SyntaxError?'文件不是有效的 JSON，请选择导出的计划文件。':messageOf(error));}
    finally{operation.current=false;setBusy(null);}
  }
  async function runPlan(){
    if(operation.current||!saved||!document)return;
    const chosen=versions.find(version=>version.id===runVersionId);
    const versionId=chosen?.confirmed?chosen.id:!runVersionId&&confirmed?saved.version_id:null;
    if(!versionId){setNotice('请先确认计划，或选择一个已确认历史版本。');return;}
    operation.current=true;setBusy('running');setError(null);setBottomTab('result');
    try{const run=await api<Run>('/plans/'+document.id+'/runs',json({provider,version_id:versionId}));setRuns(current=>[run,...current.filter(item=>item.id!==run.id)]);setSelectedRun(run.id);if(run.status==='failed')setError(run.error??'执行失败');else setNotice(run.is_mock?'Mock 演示运行完成。':'Codex 运行完成。');}
    catch(error){setError(messageOf(error));}finally{operation.current=false;setBusy(null);}
  }
  function addNode(){
    if(!document)return;
    const id='task_'+crypto.randomUUID().slice(0,8);
    updateDocument({...document,nodes:[...document.nodes,{id,title:'新任务',goal:'',inputs:[],requirements:'',output_format:'',acceptance_criteria:[],locked_fields:[]}],layout:{...document.layout,[id]:{x:80+(document.nodes.length%3)*330,y:80+Math.floor(document.nodes.length/3)*220}}});setSelected(id);setCanvasTab('graph');
  }
  function deleteNode(id:string){
    if(!document)return;
    updateDocument({...document,nodes:document.nodes.filter(node=>node.id!==id),edges:document.edges.filter(edge=>edge.source!==id&&edge.target!==id),output_outline:document.output_outline.map(item=>({...item,node_ids:item.node_ids.filter(nodeId=>nodeId!==id)})),layout:Object.fromEntries(Object.entries(document.layout).filter(([nodeId])=>nodeId!==id))});setSelected(null);
  }
  function locate(source:Segment|Issue){
    const focus=(id:string)=>{const target=window.document.getElementById(id);target?.scrollIntoView({block:'nearest',behavior:'smooth'});target?.focus({preventScroll:true});};
    if('source_type' in source){
      if(source.source_type==='node'){setSelected(source.source_id);setCanvasTab('graph');setTimeout(()=>focus('node-field-'+(source.field==='dependencies'?'dependencies':source.field)),0);}
      else if(source.source_type==='outline'){setCanvasTab('outline');setTimeout(()=>(()=>{const target=window.document.getElementById('outline-'+source.source_id);target?.scrollIntoView({block:'nearest',behavior:'smooth'});target?.querySelector('input')?.focus({preventScroll:true});})(),0);}
      else if(source.field==='instructions'){setNotice('此段是固定执行规则，由编译模板提供。');focus('global-provenance');}else{focus('global-'+source.field);}
    }else{
      if(source.node_id&&document?.nodes.some(node=>node.id===source.node_id)){setSelected(source.node_id);setCanvasTab('graph');setTimeout(()=>focus('node-field-'+(source.field==='edges'?'dependencies':source.field==='layout'?'title':source.field??'title')),0);}
      else if(source.field==='output_outline'){setCanvasTab('outline');setTimeout(()=>{window.document.querySelector<HTMLInputElement>('.outline-item-header input')?.focus();},0);}else if(source.field==='edges'||source.field==='nodes'||source.field==='layout'){setCanvasTab('graph');setTimeout(()=>window.document.querySelector<HTMLElement>('[data-testid=flow-canvas]')?.focus(),0);}else{const field=source.field??(source.code.includes('assumption')?'assumptions':'goal');focus('global-'+field);}
    }
  }
  async function copyPrompt(){if(!compile||!compilationCurrent)return;try{await navigator.clipboard.writeText(compile.text);setNotice('提示词已复制。');}catch{setError('剪贴板不可用，请使用导出按钮保存提示词。');}}
  const providerAvailable=providers.find(item=>item.id===provider)?.available;

  return <div className={'app '+(document?'has-plan':'welcome-app')}>
    <header className="app-header"><Logo/><div className="header-divider"/><span className="product-label">可视化计划工作台</span><div className="header-spacer"/>
      {document?<><div className="save-status" data-testid="plan-status"><span className={'status-dot '+(confirmed?'':'draft')}/>{confirmed?'已确认':semanticDirty?'草稿 · 已修改':'草稿'}<span className="mono">v{saved?.version}</span>{layoutDirty&&!semanticDirty&&<span className="layout-status">布局未保存</span>}</div><button className="btn header-save" onClick={()=>void save()} disabled={disabled||!dirty}>{busy==='saving'?<Loader2 className="spin" size={14}/>:<Save size={14}/>}保存草稿</button><button className="btn btn-primary" onClick={()=>void confirmPlan()} disabled={disabled||confirmed}>{busy==='confirming'?<Loader2 className="spin" size={14}/>:<ShieldCheck size={14}/>}确认计划</button></>:<span className="header-local"><span className="status-dot"/>本地 · 隐私优先</span>}
    </header>
    <div className="workspace-nav"><div className="workspace-nav-left"><span className="workspace-icon"><Layers3 size={16}/></span><span className="workspace-label">我的工作区</span><ChevronDown size={12}/><span className="nav-slash">/</span><select className="plan-switch" aria-label="切换计划" value={document?.id??''} onChange={event=>void loadPlan(event.target.value)} disabled={disabled}><option value="">{document?'选择计划':'新建计划'}</option>{plans.map(plan=><option value={plan.id} key={plan.id}>{plan.title||'未命名计划'} · v{plan.version}</option>)}</select></div><div className="workspace-nav-right"><button className="text-button" onClick={newPlan} disabled={disabled}><Plus size={13}/>新建</button><button className="text-button" onClick={()=>fileInput.current?.click()} disabled={disabled}><Upload size={13}/>导入 JSON</button>{document&&<><button className="text-button" onClick={()=>download((document.title||'plan')+'.json',JSON.stringify(document,null,2),'application/json;charset=utf-8')}><Download size={13}/>导出 JSON</button><button className={'text-button '+(historyOpen?'active-button':'')} onClick={()=>setHistoryOpen(!historyOpen)} disabled={disabled}><History size={14}/>版本历史</button></>}</div><input ref={fileInput} className="visually-hidden" type="file" accept=".json,application/json" aria-label="导入计划 JSON 文件" onChange={event=>{const file=event.target.files?.[0];if(file)void importFile(file);event.target.value='';}}/></div>
    {error&&<div className="error-banner" role="alert"><span>{error}</span><div>{!document&&<button className="text-button" onClick={()=>void initialize()} disabled={disabled}><RotateCcw size={12}/>重试连接</button>}{document&&<button className="text-button" onClick={()=>void loadPlan(document.id)} disabled={disabled}><RotateCcw size={12}/>重新加载</button>}<button className="icon-button" aria-label="关闭错误提示" onClick={()=>setError(null)}><X size={15}/></button></div></div>}
    {document?<><div className="workspace-grid"><GlobalPanel document={document} onChange={updateDocument} disabled={disabled}/><main className="plan-panel"><div className="panel-heading center-heading"><span className="panel-label"><span className="step-dot">02</span>可视化计划</span><div className="view-tabs"><button className={canvasTab==='graph'?'active':''} onClick={()=>setCanvasTab('graph')}><GitBranch size={13}/>任务流程<span>{document.nodes.length}</span></button><button className={canvasTab==='outline'?'active':''} onClick={()=>setCanvasTab('outline')}><BookOpen size={13}/>输出大纲</button></div><div className="canvas-tools"><button className="icon-button" aria-label="自动布局" title="自动布局" disabled={disabled} onClick={()=>updateDocument(layoutDocument(document))}><Maximize2 size={15}/></button><button className="btn btn-small" disabled={disabled} onClick={addNode}><Plus size={13}/>添加任务</button></div></div>{canvasTab==='graph'?<ReactFlowProvider key={document.id}><FlowCanvas document={document} selected={selected} onSelect={setSelected} onChange={updateDocument} onAdd={addNode} disabled={disabled}/></ReactFlowProvider>:<OutlineEditor document={document} onChange={updateDocument} disabled={disabled}/>}</main><NodeInspector document={document} selected={selected} onChange={updateDocument} onDelete={deleteNode} disabled={disabled}/></div>
      <Workbench tab={bottomTab} onTab={tab=>{setBottomTab(tab);if(tab==='diff'&&!comparisonId)setComparisonId(versions.find(version=>version.confirmed)?.id??versions[0]?.id??'');}} document={document} compile={compilationCurrent?compile:null} compilePending={compilePending||!compilationCurrent} compileError={compilationCurrent?compileError:null} issues={issues} onValidate={()=>void validate()} onLocate={locate} onCopy={()=>void copyPrompt()} onDownload={()=>compile&&download((document.title||'plan')+'-prompt.txt',compile.text)} versions={versions} comparisonId={comparisonId} onComparison={setComparisonId} runVersionId={runVersionId} onRunVersion={setRunVersionId} runs={runs} selectedRun={selectedRun} onSelectedRun={setSelectedRun} providers={providers} runProvider={provider} onProvider={setProvider} onRun={()=>void runPlan()} disabled={disabled} confirmed={confirmed} currentVersionId={saved?.version_id??''} currentVersion={saved?.version??0} busy={busy}/></>:<main className="welcome"><div className="welcome-content"><span className="welcome-eyebrow"><span className="status-dot"/>从一个想法，到一份清晰的计划</span><h1>计划看得见，<br/><span>每一步由你掌握。</span></h1><p className="welcome-description">描述你想完成的事，把 AI 的思路展开成任务图。<br/>调整目标、依赖与交付结构，再确认并运行。</p><div className="request-card"><div className="request-card-heading"><span><Sparkles size={16}/>从需求开始</span><span className="meta-text">尽可能说明目标与边界</span></div><textarea aria-label="描述任务需求" rows={5} value={request} onChange={event=>setRequest(event.target.value)} disabled={disabled} placeholder="例如：帮我制定一份科研课题计划，先梳理研究问题和已有证据，再设计实验，最后输出研究计划书…"/><div className="request-card-footer"><select aria-label="计划生成提供方" value={provider} onChange={event=>setProvider(event.target.value as ProviderId)} disabled={disabled}>{providers.map(item=><option key={item.id} value={item.id} disabled={!item.available} title={item.reason??undefined}>{item.label}{!item.available?'（不可用）':''}</option>)}{!providers.length&&<option value="mock">等待本地服务…</option>}</select><button className="btn btn-primary" onClick={()=>void generate()} disabled={disabled||!request.trim()||!providerAvailable}>{busy==='generating'?<Loader2 className="spin" size={15}/>:<Sparkles size={15}/>}生成可视化计划<ArrowRight size={14}/></button></div></div><div className="demo-row"><span>想先体验一下？</span><button className="text-button" disabled={disabled||!providers.some(item=>item.id==='mock'&&item.available)} onClick={()=>void generate(true)}>加载演示<ArrowRight size={13}/></button><span className="demo-tag">无需 API Key · Mock</span></div><div className="provider-notes">{providers.filter(item=>!item.available).map(item=><p key={item.id}>{item.label}：{item.reason??'当前不可用'}</p>)}</div><div className="feature-row"><div><span className="feature-icon"><GitBranch size={20}/></span><h3>拆解与连接</h3><p>把任务变成可调整的流程</p></div><div><span className="feature-icon"><ShieldCheck size={20}/></span><h3>校验与确认</h3><p>明确假设和每一步的标准</p></div><div><span className="feature-icon"><FileJson2 size={20}/></span><h3>保存与追溯</h3><p>计划、版本与结果留在本地</p></div></div></div><div className="welcome-decoration"><div className="decor-node"><span>01</span><Workflow size={18}/><b>想法</b></div><div className="decor-line"/><div className="decor-node middle"><span>02</span><GitBranch size={18}/><b>计划</b></div><div className="decor-line"/><div className="decor-node"><span>03</span><Check size={18}/><b>成果</b></div></div></main>}
    <footer className="statusbar"><span><span className="status-dot"/>LOCAL WORKSPACE</span><span>{document?document.nodes.length+' 个任务 · '+document.edges.length+' 条依赖 · '+document.output_outline.length+' 个章节':'清晰的意图，是好计划的开始。'}</span><span>{busy==='running'?'整个计划正在执行…':busy==='generating'?'正在生成任务图…':saved?'保存于 '+readableTime(saved.updated_at):'PLANFORM / 01'}</span></footer>
    {notice&&<div className="toast" role="status"><Check size={15}/>{notice}<button aria-label="关闭通知" onClick={()=>setNotice(null)}><X size={12}/></button></div>}
    {busy==='generating'&&<div className="progress-overlay"><div className="progress-card"><span className="progress-icon"><Sparkles size={26}/></span><h2>正在展开你的计划</h2><p>整理任务、依赖关系与输出结构。<br/>Codex 生成可能需要一至两分钟。</p><span className="progress-loading"><Loader2 className="spin" size={14}/>生成中</span></div></div>}
    {historyOpen&&document&&<><div className="drawer-backdrop" onClick={()=>setHistoryOpen(false)}/><aside className="history-drawer" aria-label="版本历史"><div className="history-header"><div><span className="eyebrow">PLAN HISTORY</span><h2>版本历史</h2></div><button className="icon-button" aria-label="关闭版本历史" onClick={()=>setHistoryOpen(false)}><X size={18}/></button></div><p>每次业务修改保存为一个版本。已确认版本可独立运行。</p><div className="history-list">{versions.map(version=><button className={'history-item '+(version.id===comparisonId?'selected':'')} key={version.id} onClick={()=>{setComparisonId(version.id);if(version.confirmed)setRunVersionId(version.id===saved?.version_id?'':version.id);setBottomTab('diff');setHistoryOpen(false);}}><div><span className="history-version">v{version.version}</span><span className={'version-badge '+(version.confirmed?'confirmed':'')}>{version.confirmed?'已确认':'草稿'}</span>{version.id===saved?.version_id&&<span className="meta-text">当前</span>}</div><h3>{version.document.title}</h3><span className="history-time"><Clock3 size={12}/>{readableTime(version.created_at)}<span className="mono">{version.semantic_hash.slice(0,8)}</span></span><span className="history-action">查看差异与运行<ArrowRight size={13}/></span></button>)}</div><button className="btn" onClick={()=>void refreshPlans()} disabled={disabled}><RotateCcw size={13}/>刷新计划列表</button></aside></>}
  </div>;
}

