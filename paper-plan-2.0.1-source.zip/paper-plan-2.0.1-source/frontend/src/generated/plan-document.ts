/* Generated from backend Pydantic schema. Run pnpm generate:types; do not hand edit. */

export type SchemaVersion = 1 | 2;
export type Id = string;
export type Title = string;
export type OriginalRequest = string;
export type Goal = string;
export type Provenance = 'mock' | 'codex' | 'import' | 'conversation';
export type Id1 = string;
export type Text = string;
export type Locked = boolean;
export type Constraints = Constraint[];
export type Id2 = string;
export type Text1 = string;
export type Status = 'pending' | 'accepted' | 'rejected';
export type Assumptions = Assumption[];
export type Id3 = string;
export type Title1 = string;
export type Goal1 = string;
export type Inputs = string[];
export type Requirements = string;
export type OutputFormat = string;
export type AcceptanceCriteria = string[];
export type LockedFields = string[];
export type Nodes = PlanNode[];
export type Id4 = string;
export type Source = string;
export type Target = string;
export type Edges = PlanEdge[];
export type Id5 = string;
export type Title2 = string;
export type NodeIds = string[];
export type OutputOutline = OutlineSection[];
export type X = number;
export type Y = number;
export type Id6 = string;
export type ParentId = string | null;
export type Order = number;
export type Title3 = string;
export type Details = string;
export type Output = string;
export type AcceptanceCriteria1 = string[];
export type DependsOn = string[];
export type Tree = TreeNode[];

export interface PlanDocument {
  schema_version: SchemaVersion;
  id: Id;
  title: Title;
  original_request: OriginalRequest;
  goal: Goal;
  provenance: Provenance;
  constraints: Constraints;
  assumptions: Assumptions;
  nodes: Nodes;
  edges: Edges;
  output_outline: OutputOutline;
  layout: Layout;
  tree: Tree;
}
export interface Constraint {
  id: Id1;
  text: Text;
  locked: Locked;
}
export interface Assumption {
  id: Id2;
  text: Text1;
  status: Status;
}
export interface PlanNode {
  id: Id3;
  title: Title1;
  goal: Goal1;
  inputs: Inputs;
  requirements: Requirements;
  output_format: OutputFormat;
  acceptance_criteria: AcceptanceCriteria;
  locked_fields: LockedFields;
}
export interface PlanEdge {
  id: Id4;
  source: Source;
  target: Target;
}
export interface OutlineSection {
  id: Id5;
  title: Title2;
  node_ids: NodeIds;
}
export interface Layout {
  [k: string]: Position;
}
export interface Position {
  x: X;
  y: Y;
}
export interface TreeNode {
  id: Id6;
  parent_id: ParentId;
  order: Order;
  title: Title3;
  details: Details;
  output: Output;
  acceptance_criteria: AcceptanceCriteria1;
  depends_on: DependsOn;
}
