import { ArrowDown, ArrowUp, Check, ChevronRight, CircleHelp, FileText, Link2, LockKeyhole, Plus, Trash2, Unlock, Workflow, X } from 'lucide-react';
import type { PlanDocument, PlanNode } from './types';

const fields=[{key:'title',label:'任务名称',rows:1},{key:'goal',label:'任务目标',rows:3},{key:'inputs',label:'输入信息',rows:3,list:true},{key:'requirements',label:'具体要求',rows:5},{key:'output_format',label:'输出形式',rows:2},{key:'acceptance_criteria',label:'验收标准',rows:3,list:true}] as const;
export function NodeInspector({document,selected,onChange,onDelete,disabled}:{document:PlanDocument;selected:string|null;onChange:(document:PlanDocument)=>void;onDelete:(id:string)=>void;disabled:boolean}){
  const node=document.nodes.find(item=>item.id===selected);
  const update=(patch:Partial<PlanNode>)=>node&&onChange({...document,nodes:document.nodes.map(item=>item.id===node.id?{...item,...patch}:item)});
  return <aside className="inspector">
    <div className="panel-heading"><span className="panel-label"><span className="step-dot">03</span>任务属性</span><span className="meta-text">细化每一步</span></div>
    {node?<div className="inspector-content" data-testid="node-editor">
      <div className="inspector-node-title"><span className="task-number">{String(document.nodes.indexOf(node)+1).padStart(2,'0')}</span><div><h2>{node.title||'未命名任务'}</h2><span className="mono meta-text">{node.id}</span></div></div>
      <p className="field-note" id="node-field-locked_fields" tabIndex={-1}><LockKeyhole size={12}/>锁定字段可防止模型改写，仍可由你编辑。</p>
      <fieldset disabled={disabled}>
        {fields.map(field=>{
          const value=node[field.key];const locked=node.locked_fields.includes(field.key);
          return <div className="form-field" key={field.key}>
            <div className="label-row"><label htmlFor={`node-field-${field.key}`}>{field.label}{'list' in field&&<span className="label-hint">每行一项</span>}</label><button type="button" className={`lock-btn ${locked?'locked':''}`} aria-label={`${locked?'解锁':'锁定'}${field.label}`} title={`${locked?'解锁':'锁定'}${field.label}`} onClick={()=>update({locked_fields:locked?node.locked_fields.filter(key=>key!==field.key):[...node.locked_fields,field.key]})}>{locked?<LockKeyhole size={13}/>:<Unlock size={13}/>}</button></div>
            {field.rows===1?<input id={`node-field-${field.key}`} data-testid={`node-field-${field.key}`} value={String(value)} onChange={event=>update({[field.key]:event.target.value})}/>:<textarea id={`node-field-${field.key}`} data-testid={`node-field-${field.key}`} rows={field.rows} value={Array.isArray(value)?value.join('\n'):value} onChange={event=>update({[field.key]:'list' in field?(event.target.value?event.target.value.split('\n'):[]):event.target.value})}/>}
          </div>;
        })}
        <div className="form-field" id="node-field-dependencies" tabIndex={-1}><div className="label-row"><label><Link2 size={12}/>前置任务</label><span className="label-hint">输入依赖</span></div><div className="dependency-list">
          {document.nodes.filter(item=>item.id!==node.id).map(item=><label className="checkbox-row" key={item.id}><input type="checkbox" checked={document.edges.some(edge=>edge.source===item.id&&edge.target===node.id)} onChange={event=>onChange({...document,edges:event.target.checked?[...document.edges,{id:`edge_${crypto.randomUUID().slice(0,8)}`,source:item.id,target:node.id}]:document.edges.filter(edge=>!(edge.source===item.id&&edge.target===node.id))})}/><span>{item.title||item.id}</span></label>)}
          {document.nodes.length<2&&<p className="meta-text">添加更多任务后设置依赖。</p>}
        </div></div>
        <button className="danger-text delete-task" onClick={()=>onDelete(node.id)}><Trash2 size={13}/>删除此任务</button>
      </fieldset>
    </div>:<div className="inspector-placeholder"><div className="placeholder-orbit"><Workflow size={23}/><span><ChevronRight size={13}/></span></div><h3>让每一步更明确</h3><p>选择画布中的任务，编辑目标、输入、输出与验收标准。</p><div className="hint-card"><CircleHelp size={15}/><span>任务之间的连线决定执行顺序。细节会自动同步到提示词。</span></div></div>}
  </aside>;
}
export function GlobalPanel({document,onChange,disabled}:{document:PlanDocument;onChange:(document:PlanDocument)=>void;disabled:boolean}){
  return <aside className="global-panel">
    <div className="panel-heading"><span className="panel-label"><span className="step-dot">01</span>任务背景</span><span className="meta-text">从意图开始</span></div>
    <div className="global-content"><div className="global-origin" id="global-provenance" tabIndex={-1}><span className="status-dot"/>{document.provenance==='mock'?'MOCK · 规则生成演示':document.provenance==='codex'?'CODEX · 模型生成计划':document.provenance==='conversation'?'CONVERSATION · 原对话计划':'IMPORT · 用户导入计划'}</div><fieldset disabled={disabled}>
      <div className="form-field"><label htmlFor="global-title">计划名称</label><input id="global-title" value={document.title} onChange={event=>onChange({...document,title:event.target.value})}/></div>
      <div className="form-field"><label htmlFor="global-original_request">原始需求</label><textarea id="global-original_request" rows={5} value={document.original_request} onChange={event=>onChange({...document,original_request:event.target.value})}/></div>
      <div className="form-field"><label htmlFor="global-goal">最终目标</label><textarea id="global-goal" rows={3} value={document.goal} onChange={event=>onChange({...document,goal:event.target.value})}/></div>
      <section className="global-section" id="global-constraints" tabIndex={-1}><div className="section-label"><h3>全局约束<span>{document.constraints.length}</span></h3><button className="icon-button" aria-label="添加约束" onClick={()=>onChange({...document,constraints:[...document.constraints,{id:`c_${crypto.randomUUID().slice(0,8)}`,text:'',locked:false}]})}><Plus size={14}/></button></div>
        {document.constraints.map((item,index)=><div className="constraint-row" key={item.id}><textarea rows={2} aria-label={`约束 ${index+1}`} value={item.text} onChange={event=>onChange({...document,constraints:document.constraints.map(value=>value.id===item.id?{...value,text:event.target.value}:value)})}/><div className="row-actions"><button className={`lock-btn ${item.locked?'locked':''}`} aria-label={`${item.locked?'解锁':'锁定'}约束 ${index+1}`} onClick={()=>onChange({...document,constraints:document.constraints.map(value=>value.id===item.id?{...value,locked:!value.locked}:value)})}>{item.locked?<LockKeyhole size={12}/>:<Unlock size={12}/>}</button><button className="icon-button" aria-label={`删除约束 ${index+1}`} onClick={()=>onChange({...document,constraints:document.constraints.filter(value=>value.id!==item.id)})}><X size={13}/></button></div></div>)}
        {!document.constraints.length&&<p className="meta-text">添加边界、风格或交付要求。</p>}
      </section>
      <section className="global-section" id="global-assumptions" tabIndex={-1}><div className="section-label"><h3>待确认假设<span>{document.assumptions.filter(item=>item.status==='pending').length}</span></h3><button className="icon-button" aria-label="添加假设" onClick={()=>onChange({...document,assumptions:[...document.assumptions,{id:`a_${crypto.randomUUID().slice(0,8)}`,text:'',status:'pending'}]})}><Plus size={14}/></button></div>
        {document.assumptions.map((item,index)=><div className={`assumption-card ${item.status}`} key={item.id}>
          <div className="assumption-title"><span>{item.status==='pending'?'需要你的判断':item.status==='accepted'?'已接受':'已拒绝'}</span><button className="icon-button" aria-label={`删除假设 ${index+1}`} onClick={()=>onChange({...document,assumptions:document.assumptions.filter(value=>value.id!==item.id)})}><X size={12}/></button></div>
          <textarea rows={2} aria-label={`假设 ${index+1}`} value={item.text} onChange={event=>onChange({...document,assumptions:document.assumptions.map(value=>value.id===item.id?{...value,text:event.target.value}:value)})}/>
          <div className="decision-actions">{(['accepted','rejected','pending'] as const).map(status=><button key={status} data-testid={`assumption-${item.id}-${status}`} className={item.status===status?'active':''} aria-pressed={item.status===status} onClick={()=>onChange({...document,assumptions:document.assumptions.map(value=>value.id===item.id?{...value,status}:value)})}>{status==='accepted'?<><Check size={12}/>接受</>:status==='rejected'?<><X size={12}/>拒绝</>:'待确认'}</button>)}</div>
        </div>)}
        {!document.assumptions.length&&<p className="meta-text">没有需要确认的假设。</p>}
      </section>
    </fieldset></div>
    <div className="local-note"><span className="status-dot"/>本地工作区<span>数据保存在此电脑</span></div>
  </aside>;
}
export function OutlineEditor({document,onChange,disabled}:{document:PlanDocument;onChange:(document:PlanDocument)=>void;disabled:boolean}){
  function move(index:number,offset:number){const next=[...document.output_outline];[next[index],next[index+offset]]=[next[index+offset],next[index]];onChange({...document,output_outline:next});}
  return <div className="outline-editor"><div className="outline-intro"><div className="small-icon"><FileText size={20}/></div><div><h2>设计最终交付结构</h2><p>排列章节，为每一部分关联提供内容的任务。</p></div><button className="btn btn-small" disabled={disabled} onClick={()=>onChange({...document,output_outline:[...document.output_outline,{id:`o_${crypto.randomUUID().slice(0,8)}`,title:'新章节',node_ids:[]}]})}><Plus size={14}/>添加章节</button></div>
    <fieldset disabled={disabled}><div className="outline-list">{document.output_outline.map((item,index)=><article className="outline-item" id={`outline-${item.id}`} key={item.id}><div className="outline-item-header"><span className="outline-number">{String(index+1).padStart(2,'0')}</span><input aria-label={`章节 ${index+1} 名称`} value={item.title} onChange={event=>onChange({...document,output_outline:document.output_outline.map(value=>value.id===item.id?{...value,title:event.target.value}:value)})}/><button className="icon-button" aria-label={`上移章节 ${index+1}`} disabled={index===0} onClick={()=>move(index,-1)}><ArrowUp size={14}/></button><button className="icon-button" aria-label={`下移章节 ${index+1}`} disabled={index===document.output_outline.length-1} onClick={()=>move(index,1)}><ArrowDown size={14}/></button><button className="icon-button" aria-label={`删除章节 ${index+1}`} onClick={()=>onChange({...document,output_outline:document.output_outline.filter(value=>value.id!==item.id)})}><Trash2 size={14}/></button></div><div className="outline-links"><span>内容来自</span>{document.nodes.map(node=><label className={`node-chip ${item.node_ids.includes(node.id)?'checked':''}`} key={node.id}><input type="checkbox" checked={item.node_ids.includes(node.id)} onChange={event=>onChange({...document,output_outline:document.output_outline.map(value=>value.id===item.id?{...value,node_ids:event.target.checked?[...value.node_ids,node.id]:value.node_ids.filter(id=>id!==node.id)}:value)})}/>{item.node_ids.includes(node.id)&&<Check size={11}/>} {node.title||node.id}</label>)}</div></article>)}</div></fieldset>
    {!document.output_outline.length&&<div className="empty-message">添加章节，将任务产出组织成完整结果。</div>}
  </div>;
}

