import { useEffect, useRef, useState } from 'react';

type Props={level:number;number:string;disabled:boolean;onCommit:(level:number)=>void};

export default function HeadingLevelInput({level,number,disabled,onCommit}:Props){
  const [draft,setDraft]=useState(String(level));
  const [error,setError]=useState('');
  const cancelBlur=useRef(false);
  useEffect(()=>{setDraft(String(level));setError('');},[level]);
  function commit(value:string){
    if(cancelBlur.current){cancelBlur.current=false;return;}
    if(disabled){setDraft(String(level));return;}
    try{
      const next=Number(value);
      if(!/^\d+$/.test(value)||!Number.isSafeInteger(next)||next<1)throw new Error('请输入大于等于 1 的整数。');
      if(next!==level)onCommit(next);
      setDraft(String(next));setError('');
    }catch(e){setDraft(String(level));setError(e instanceof Error?e.message:'无法修改标题级别。');}
  }
  return <label className="paper-level" title="输入 1、2、3…；按 Enter 或离开输入框应用，Esc 取消。子标题会随整组移动。">
    <span>级别</span><input type="number" min={1} step={1} inputMode="numeric" aria-label={`标题 ${number} 的级别`} aria-invalid={!!error} disabled={disabled} value={draft}
      onFocus={e=>{e.currentTarget.select();setError('');}}
      onChange={e=>{setDraft(e.target.value);setError('');}}
      onBlur={e=>commit(e.currentTarget.value)}
      onKeyDown={e=>{
        if(e.key==='Enter'){e.preventDefault();e.currentTarget.blur();}
        if(e.key==='Escape'){e.preventDefault();cancelBlur.current=true;setDraft(String(level));setError('');e.currentTarget.blur();}
      }}/>
    {error&&<span className="paper-level-error" role="alert">{error}</span>}
  </label>;
}
