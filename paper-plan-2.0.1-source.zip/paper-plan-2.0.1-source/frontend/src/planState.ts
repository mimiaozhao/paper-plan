import { ApiError } from './api';
import type { Issue, PlanDocument } from './types';
function canonical(value:unknown):unknown{if(Array.isArray(value))return value.map(canonical);if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).sort(([a],[b])=>a<b?-1:a>b?1:0).map(([key,item])=>[key,canonical(item)]));return value;}
export function semanticKey(document:PlanDocument){const byId=<T extends {id:string}>(items:T[])=>[...items].sort((a,b)=>a.id<b.id?-1:a.id>b.id?1:0);return JSON.stringify(canonical({...document,layout:undefined,nodes:byId(document.nodes).map(node=>({...node,locked_fields:[...new Set(node.locked_fields)].sort()})),edges:byId(document.edges),constraints:byId(document.constraints),assumptions:byId(document.assumptions)}));}
export const messageOf=(error:unknown)=>error instanceof Error?error.message:'发生了未知错误，请重试。';
export function issuesOf(error:unknown):Issue[]{if(error instanceof ApiError&&error.detail&&typeof error.detail==='object'&&'issues' in error.detail&&Array.isArray(error.detail.issues))return error.detail.issues as Issue[];return [];}
export function stateFingerprint(state:{version_id:string;version:number;semantic_hash:string;confirmed:boolean;updated_at:string;binding?:{context_revision:string}|null}){return [state.version_id,state.version,state.semantic_hash,state.confirmed,state.updated_at,state.binding?.context_revision].join('|');}

