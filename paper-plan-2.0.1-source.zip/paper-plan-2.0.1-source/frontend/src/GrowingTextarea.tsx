import { useLayoutEffect, useRef } from 'react';
import type { TextareaHTMLAttributes } from 'react';

type Props = Omit<TextareaHTMLAttributes<HTMLTextAreaElement>, 'value'> & { value: string };

function fitContent(element: HTMLTextAreaElement) {
  // A collapsed details section has no measurable width. ResizeObserver will
  // measure again when it opens, including read-only execution views.
  if (!element.clientWidth) return;
  const style = getComputedStyle(element);
  const border = parseFloat(style.borderTopWidth) + parseFloat(style.borderBottomWidth);
  element.style.height = 'auto';
  element.style.height = `${element.scrollHeight + border}px`;
}

export default function GrowingTextarea({ value, className = '', ...props }: Props) {
  const ref = useRef<HTMLTextAreaElement>(null);
  useLayoutEffect(() => {
    if (ref.current) fitContent(ref.current);
  }, [value]);
  useLayoutEffect(() => {
    const element = ref.current;
    if (!element) return;
    let previousWidth = -1;
    const observer = new ResizeObserver(([entry]) => {
      const width = entry.contentRect.width;
      if (width === previousWidth) return;
      previousWidth = width;
      fitContent(element);
    });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);
  return <textarea {...props} ref={ref} value={value} className={`paper-growing-textarea ${className}`} />;
}
