import type { TreeNode } from './generated/plan-document';

export type FlatNode = {node:TreeNode; depth:number; number:string};
export function flatten(tree:TreeNode[]):FlatNode[]{
  const result:FlatNode[]=[];
  const walk=(parent:string|null,prefix:string,depth:number,seen:Set<string>)=>{
    tree.filter(n=>n.parent_id===parent).sort((a,b)=>a.order-b.order||a.id.localeCompare(b.id)).forEach((node,i)=>{
      if(seen.has(node.id))return;
      seen.add(node.id);
      const number=prefix?`${prefix}.${i+1}`:String(i+1);
      result.push({node,number,depth});walk(node.id,number,depth+1,seen);
    });
  };
  walk(null,'',0,new Set());return result;
}
export function descendants(tree:TreeNode[],id:string):Set<string>{
  const found=new Set([id]);let changed=true;
  while(changed){changed=false;for(const n of tree)if(n.parent_id&&found.has(n.parent_id)&&!found.has(n.id)){found.add(n.id);changed=true;}}
  return found;
}
export function normalize(tree:TreeNode[]):TreeNode[]{
  const orders=new Map<string|null,number>();
  return flatten(tree).map(({node})=>{const order=orders.get(node.parent_id)??0;orders.set(node.parent_id,order+1);return {...node,order};});
}
export function moveNode(tree:TreeNode[],id:string,target:string,placement:'before'|'after'|'inside'):TreeNode[]{
  const source=tree.find(n=>n.id===id),destination=tree.find(n=>n.id===target);
  if(!source||!destination||descendants(tree,id).has(target))throw new Error('不能将标题移入自身或它的子标题。');
  const parent=placement==='inside'?target:destination.parent_id;
  const siblings=tree.filter(n=>n.parent_id===parent&&n.id!==id).sort((a,b)=>a.order-b.order);
  const index=placement==='inside'?siblings.length:siblings.findIndex(n=>n.id===target)+(placement==='after'?1:0);
  siblings.splice(index,0,{...source,parent_id:parent});
  const replacements=new Map(siblings.map((n,order)=>[n.id,{...n,order}]));
  return normalize(tree.map(n=>replacements.get(n.id)??n));
}
export function keyboardMove(tree:TreeNode[],id:string,action:'up'|'down'|'indent'|'outdent'):TreeNode[]{
  const node=tree.find(n=>n.id===id);if(!node)return tree;
  const siblings=tree.filter(n=>n.parent_id===node.parent_id).sort((a,b)=>a.order-b.order);
  const index=siblings.findIndex(n=>n.id===id);
  if(action==='up'&&index>0)return moveNode(tree,id,siblings[index-1].id,'before');
  if(action==='down'&&index<siblings.length-1)return moveNode(tree,id,siblings[index+1].id,'after');
  if(action==='indent'&&index>0)return moveNode(tree,id,siblings[index-1].id,'inside');
  if(action==='outdent'&&node.parent_id)return moveNode(tree,id,node.parent_id,'after');
  return tree;
}
export function setHeadingLevel(tree:TreeNode[],id:string,level:number):TreeNode[]{
  if(!Number.isSafeInteger(level)||level<1)throw new Error('标题级别须为大于等于 1 的整数。');
  const rows=flatten(tree);
  const index=rows.findIndex(row=>row.node.id===id);
  if(index<0)throw new Error('标题已不存在，请重新加载目录。');
  const current=rows[index];
  if(level===current.depth+1)return tree;
  if(level<current.depth+1){
    const byId=new Map(tree.map(node=>[node.id,node]));
    let ancestor=current.node;
    for(let depth=current.depth+1;depth>level;depth--){
      const parent=ancestor.parent_id?byId.get(ancestor.parent_id):undefined;
      if(!parent)throw new Error('找不到对应的上级标题，请重新加载目录。');
      ancestor=parent;
    }
    return moveNode(tree,id,ancestor.id,'after');
  }
  const parent=rows.slice(0,index).reverse().find(row=>row.depth===level-2)?.node;
  if(!parent)throw new Error(`前方没有 ${level-1} 级标题，无法设为 ${level} 级。请先添加或调整上级标题。`);
  if(parent.depends_on.length||tree.some(node=>node.depends_on.includes(parent.id)))
    throw new Error(`“${parent.title}”参与了前置依赖，需先调整其依赖才能成为父标题。`);
  return moveNode(tree,id,parent.id,'inside');
}
export function newNode(parent:string|null,order:number):TreeNode{return {id:`n_${crypto.randomUUID().replaceAll('-','')}`,parent_id:parent,order,title:'新标题',details:'',output:'',acceptance_criteria:[],depends_on:[]};}
export function removeNode(tree:TreeNode[],id:string):TreeNode[]{const ids=descendants(tree,id);return normalize(tree.filter(n=>!ids.has(n.id)).map(n=>({...n,depends_on:n.depends_on.filter(d=>!ids.has(d))})));}
export function toMarkdown(title:string,tree:TreeNode[]):string{return '# '+title+'\n\n'+flatten(tree).map(({node,number,depth})=>`${'#'.repeat(Math.min(depth+2,6))} ${number} ${node.title}\n\n${node.details}${node.output?'\n\n预期产出：'+node.output:''}${node.acceptance_criteria.length?'\n\n验收条件：\n'+node.acceptance_criteria.map(c=>'- '+c).join('\n'):''}`).join('\n\n');}
