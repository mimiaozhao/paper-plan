import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BookOpen, Check, Copy, Download, GitBranch, History, Loader2, Maximize2, MessageSquare, Plus, RefreshCw, Save, Send, ShieldCheck, Workflow, X } from 'lucide-react';
import { ReactFlowProvider } from '@xyflow/react';
import { api, download, json } from './api';
import type { CompileResult, Continuation, Issue, PlanDocument, PlanState, PlanVersion, Segment } from './types';
import { semanticKey, messageOf, issuesOf, stateFingerprint } from './planState';
import { FlowCanvas, layoutDocument } from './FlowCanvas';
import { GlobalPanel, NodeInspector, OutlineEditor } from './Editors';
import { Workbench, type BottomTab } from './Workbench';
import { BindingContext, ContinuationPanel, nativeHost } from './ThreadBridgePanel';

export default function ThreadApp({threadId}:{threadId:string}){
  const validThread=/^[A-Za-z0-9_-]{1,128}$/.test(threadId);
  const threadPath='/threads/'+encodeURIComponent(threadId);
  const [saved,setSaved]=useState<PlanState|null>(null);
  const [document,setDocument]=useState<PlanDocument|null>(null);
  const [selected,setSelected]=useState<string|null>(null);
  const [canvasTab,setCanvasTab]=useState<'graph'|'outline'>('graph');
  const [bottomTab,setBottomTab]=useState<BottomTab>('prompt');
  const [compile,setCompile]=useState<CompileResult|null>(null);
  const [compiledKey,setCompiledKey]=useState('');
  const [compileError,setCompileError]=useState<string|null>(null);
  const [compilePending,setCompilePending]=useState(false);
  const [validation,setValidation]=useState<{key:string;issues:Issue[]}|null>(null);
  const [versions,setVersions]=useState<PlanVersion[]>([]);
  const [comparisonId,setComparisonId]=useState('');
  const [continuations,setContinuations]=useState<Continuation[]>([]);
  const [selectedContinuation,setSelectedContinuation]=useState('');
  const [external,setExternal]=useState<PlanState|null>(null);
  const [busy,setBusy]=useState<string|null>('initializing');
  const [error,setError]=useState<string|null>(null);
  const [pollError,setPollError]=useState<string|null>(null);
  const [notice,setNotice]=useState<string|null>(null);
  const operation=useRef(false);
  const mutationEpoch=useRef(0);
  const refreshSequence=useRef(0);
  const latestSaved=useRef(saved);latestSaved.current=saved;
  const latestDocument=useRef(document);latestDocument.current=document;
  const dirtyRef=useRef(false);
  const key=useMemo(()=>document?semanticKey(document):'',[document]);
  const semanticDirty=!!document&&!!saved&&key!==semanticKey(saved.document);
  const layoutDirty=!!document&&!!saved&&JSON.stringify(document.layout)!==JSON.stringify(saved.document.layout);
  const dirty=semanticDirty||layoutDirty;dirtyRef.current=dirty;
  const confirmed=!!saved?.confirmed&&!semanticDirty;
  const currentCompile=key===compiledKey;
  const issues=validation?.key===key?validation.issues:currentCompile?compile?.issues??[]:[];
  const disabled=!!busy;
  const threadTitle=saved?.binding?.thread_title||'原 Codex 对话';
  const creationMessage='请使用 plan-panel，依据本对话中已确认的目标、约束和决定，为此对话创建可视化计划。thread_id='+threadId+'。提取任务摘要与已确认决定，写入绑定计划；不要另建独立任务或读取其他对话。';

  useEffect(()=>{if(!notice)return;const timer=setTimeout(()=>setNotice(null),4500);return()=>clearTimeout(timer);},[notice]);
  useEffect(()=>{const onLeave=(event:BeforeUnloadEvent)=>{if(dirty){event.preventDefault();event.returnValue='';}};window.addEventListener('beforeunload',onLeave);return()=>window.removeEventListener('beforeunload',onLeave);},[dirty]);

  const refreshVersions=useCallback(async(id:string)=>{
    try{const result=await api<{versions:PlanVersion[]}>('/plans/'+id+'/versions');if(latestSaved.current?.document.id===id)setVersions(result.versions.sort((a,b)=>b.version-a.version));}
    catch(error){setNotice('版本记录读取失败：'+messageOf(error));}
  },[]);
  const adopt=useCallback((state:PlanState,reset=false)=>{
    if(state.binding?.thread_id!==threadId)throw new Error('服务返回的计划与此对话不一致，已停止载入。');
    const previous=latestDocument.current;
    const next=Object.keys(state.document.layout).length<state.document.nodes.length?layoutDocument(state.document):state.document;
    latestSaved.current=state;latestDocument.current=next;setSaved(state);setDocument(next);setExternal(null);
    if(!previous||semanticKey(previous)!==semanticKey(next)){setValidation(null);setCompileError(null);}
    setSelected(current=>next.nodes.some(node=>node.id===current)?current:next.nodes[0]?.id??null);
    if(reset){setCanvasTab('graph');setComparisonId('');}
    void refreshVersions(state.document.id);
  },[threadId,refreshVersions]);

  const refresh=useCallback(async(signal?:AbortSignal)=>{
    const epoch=mutationEpoch.current;const sequence=++refreshSequence.current;
    const results=await Promise.allSettled([api<{state:PlanState|null}>(threadPath+'/plan',{signal}),api<{continuations:Continuation[]}>(threadPath+'/continuations',{signal})]);
    if(signal?.aborted||epoch!==mutationEpoch.current||sequence!==refreshSequence.current||operation.current)return;
    if(results[1].status==='fulfilled')setContinuations(results[1].value.continuations);
    if(results[0].status==='rejected'){if(!(results[0].reason instanceof DOMException&&results[0].reason.name==='AbortError'))setPollError(messageOf(results[0].reason));return;}
    if(results[1].status==='rejected')setPollError('执行记录同步失败：'+messageOf(results[1].reason));else setPollError(null);
    if(operation.current)return;
    const state=results[0].value.state;
    if(!state){if(latestSaved.current)setPollError('此对话的绑定计划暂时不可用，已保留当前编辑。');return;}
    if(state.binding?.thread_id!==threadId){setPollError('计划绑定与当前对话不一致，未载入返回数据。');return;}
    const previous=latestSaved.current;
    if(!previous){adopt(state,true);return;}
    if(state.version<previous.version||(state.version===previous.version&&Date.parse(state.updated_at)<Date.parse(previous.updated_at)))return;
    if(stateFingerprint(state)===stateFingerprint(previous))return;
    if(dirtyRef.current){
      if(semanticKey(state.document)===semanticKey(previous.document)&&JSON.stringify(state.document.layout)===JSON.stringify(previous.document.layout)){latestSaved.current=state;setSaved(state);}
      else setExternal(state);
    }else adopt(state);
  },[threadId,threadPath,adopt]);

  useEffect(()=>{
    if(!validThread){setBusy(null);return;}
    let stopped=false;let timer:ReturnType<typeof setTimeout>;const controller=new AbortController();
    const poll=async()=>{
      if(!operation.current){try{await refresh(controller.signal);}catch(error){if(!stopped)setPollError(messageOf(error));}}
      if(!stopped){setBusy(current=>current==='initializing'?null:current);timer=setTimeout(()=>void poll(),3000);}
    };
    void poll();
    return()=>{stopped=true;controller.abort();clearTimeout(timer);};
  },[validThread,refresh]);

  useEffect(()=>{
    if(!key){setCompile(null);setCompiledKey('');setCompilePending(false);return;}
    const controller=new AbortController();let stale=false;setCompilePending(true);setCompileError(null);
    const timer=setTimeout(async()=>{
      const doc=latestDocument.current;if(!doc)return;
      try{const result=await api<CompileResult>('/compile',{...json({document:doc}),signal:controller.signal});if(!stale){setCompile(result);setCompiledKey(key);}}
      catch(error){if(stale||(error instanceof DOMException&&error.name==='AbortError'))return;setCompile(null);setCompiledKey(key);setCompileError(messageOf(error));setValidation({key,issues:issuesOf(error)});}
      finally{if(!stale)setCompilePending(false);}
    },350);
    return()=>{stale=true;clearTimeout(timer);controller.abort();};
  },[key]);

  function update(next:PlanDocument){if(operation.current)return;latestDocument.current=next;setDocument(next);setError(null);if(!document||semanticKey(next)!==semanticKey(document))setValidation(null);}
  async function copy(text:string){try{await navigator.clipboard.writeText(text);setNotice('指令已复制，请发送到本面板绑定的同一个 Codex 对话。');}catch{setError('剪贴板不可用，请手动选中下面的指令复制。');}}
  async function hostSend(message:string){
    const host=nativeHost();if(!host){setError('当前浏览器没有对话宿主接口，请复制指令并发到同一对话。');return;}
    if(operation.current)return;operation.current=true;mutationEpoch.current+=1;setBusy('host-sending');setError(null);
    try{await host.sendFollowUpMessage({prompt:message});setNotice('指令已交给当前对话宿主。接手状态将由原对话的执行记录确认。');}
    catch(error){setError('宿主发送失败：'+messageOf(error));}
    finally{operation.current=false;setBusy(null);}
  }
  async function saveDocument():Promise<PlanState>{
    if(!document||!saved)throw new Error('此对话尚未创建计划。');
    if(external)throw new Error('原对话计划已有更新。请先导出当前修改，再载入最新版本。');
    if(!dirty)return saved;
    const state=await api<PlanState>('/plans/'+document.id,{method:'PUT',body:JSON.stringify({document,expected_version:saved.version})});
    if(state.binding?.thread_id!==threadId)throw new Error('保存返回的对话绑定不一致。');
    latestSaved.current=state;latestDocument.current=state.document;setSaved(state);setDocument(state.document);await refreshVersions(state.document.id);return state;
  }
  async function save(){
    if(operation.current||!document)return;operation.current=true;mutationEpoch.current+=1;setBusy('saving');setError(null);
    try{await saveDocument();setNotice('原对话计划草稿已保存。');}
    catch(error){setError(messageOf(error));const found=issuesOf(error);if(found.length){setValidation({key,issues:found});setBottomTab('validation');}}
    finally{operation.current=false;setBusy(null);void refresh();}
  }
  async function dispatchRequest(continuation:Continuation){
    if(continuation.status!=='pending'||continuation.delivery_status==='sending'||continuation.delivery_status==='queued')return continuation;
    const delivered=await api<Continuation>(threadPath+'/continuations/'+encodeURIComponent(continuation.id)+'/dispatch',json({}));
    setContinuations(current=>[delivered,...current.filter(item=>item.id!==delivered.id)]);setSelectedContinuation(delivered.id);
    setNotice(delivered.delivery_status==='queued'?'继续指令已实际送回原对话，等待 Codex 接手。':delivered.delivery_status==='sending'?'继续指令正在投递，请等待。':'自动投递未完成，请复制继续指令并发到同一对话。');return delivered;
  }
  async function retryDispatch(continuation:Continuation){
    if(operation.current)return;operation.current=true;mutationEpoch.current+=1;setBusy('dispatching');setError(null);
    try{await dispatchRequest(continuation);}catch(error){setError('投递失败：'+messageOf(error));}
    finally{operation.current=false;setBusy(null);void refresh();}
  }
  async function continueConversation(){
    if(operation.current||!document)return;operation.current=true;mutationEpoch.current+=1;setBusy('continuing');setError(null);
    try{
      let state=await saveDocument();
      if(!state.confirmed){
        const checked=await api<{valid:boolean;issues:Issue[]}>('/validate',json({document:state.document,mode:'confirm'}));setValidation({key:semanticKey(state.document),issues:checked.issues});
        if(!checked.valid){setBottomTab('validation');setNotice('请先处理校验问题，再确认并继续对话。');return;}
        state=await api<PlanState>('/plans/'+state.document.id+'/confirm',json({expected_version:state.version}));latestSaved.current=state;setSaved(state);setDocument(state.document);await refreshVersions(state.document.id);
      }
      const continuation=await api<Continuation>(threadPath+'/continuations',json({expected_version:state.version,version_id:state.version_id}));
      setContinuations(current=>[continuation,...current.filter(item=>item.id!==continuation.id)]);setSelectedContinuation(continuation.id);setBottomTab('result');
      await dispatchRequest(continuation);
    }catch(error){setError(messageOf(error));const found=issuesOf(error);if(found.length){setValidation({key,issues:found});setBottomTab('validation');}}
    finally{operation.current=false;setBusy(null);void refresh();}
  }
  async function validate(){
    if(operation.current||!document)return;operation.current=true;mutationEpoch.current+=1;setBusy('validating');setError(null);
    try{const result=await api<{valid:boolean;issues:Issue[]}>('/validate',json({document,mode:'confirm'}));setValidation({key,issues:result.issues});}
    catch(error){setError(messageOf(error));}finally{operation.current=false;setBusy(null);}
  }
  function loadExternal(){
    if(!external||operation.current)return;
    if(dirty&&!window.confirm('载入原对话的最新版本会丢弃当前未保存修改。需要保留时请先导出当前修改。'))return;
    adopt(external);setError(null);setNotice('已载入原对话的最新计划。');
  }
  function addNode(){if(!document)return;const id='task_'+crypto.randomUUID().slice(0,8);update({...document,nodes:[...document.nodes,{id,title:'新任务',goal:'',inputs:[],requirements:'',output_format:'',acceptance_criteria:[],locked_fields:[]}],layout:{...document.layout,[id]:{x:80+(document.nodes.length%3)*330,y:80+Math.floor(document.nodes.length/3)*220}}});setSelected(id);setCanvasTab('graph');}
  function deleteNode(id:string){if(!document)return;update({...document,nodes:document.nodes.filter(node=>node.id!==id),edges:document.edges.filter(edge=>edge.source!==id&&edge.target!==id),output_outline:document.output_outline.map(item=>({...item,node_ids:item.node_ids.filter(nodeId=>nodeId!==id)})),layout:Object.fromEntries(Object.entries(document.layout).filter(([nodeId])=>nodeId!==id))});setSelected(null);}
  function locate(source:Segment|Issue){
    const focus=(id:string)=>{const target=window.document.getElementById(id);target?.scrollIntoView({block:'nearest',behavior:'smooth'});target?.focus({preventScroll:true});};
    if('source_type' in source){
      if(source.source_type==='node'){setSelected(source.source_id);setCanvasTab('graph');setTimeout(()=>focus('node-field-'+source.field),0);}
      else if(source.source_type==='outline'){setCanvasTab('outline');setTimeout(()=>{const target=window.document.getElementById('outline-'+source.source_id);target?.scrollIntoView({block:'nearest',behavior:'smooth'});target?.querySelector('input')?.focus({preventScroll:true});},0);}
      else if(source.field==='instructions'){setNotice('此段是固定执行规则，由编译模板提供。');focus('global-provenance');}else focus('global-'+source.field);
    }else if(source.field==='output_outline'){setCanvasTab('outline');setTimeout(()=>window.document.querySelector<HTMLInputElement>('.outline-item-header input')?.focus(),0);}
    else if(source.node_id&&document?.nodes.some(node=>node.id===source.node_id)){setSelected(source.node_id);setCanvasTab('graph');setTimeout(()=>focus('node-field-'+(source.field==='edges'?'dependencies':source.field??'title')),0);}
    else if(source.field==='edges'||source.field==='nodes'||source.field==='layout'){setCanvasTab('graph');setTimeout(()=>window.document.querySelector<HTMLElement>('[data-testid=flow-canvas]')?.focus(),0);}
    else focus('global-'+(source.field??'goal'));
  }
  const resultPanel=<ContinuationPanel continuations={continuations} selectedId={selectedContinuation} onSelect={setSelectedContinuation} onRequest={()=>void continueConversation()} onDispatch={item=>void retryDispatch(item)} onCopy={message=>void copy(message)} onHostSend={message=>void hostSend(message)} disabled={disabled||!!external} busy={busy} confirmed={confirmed} version={saved?.version??0} threadTitle={threadTitle}/>;

  return <div className="app bound-app">
    <header className="app-header"><div className="brand"><span className="brand-mark"><Workflow size={22}/></span><span>planform<span className="brand-dot">.</span></span></div><div className="header-divider"/><span className="product-label"><MessageSquare size={12}/>原对话计划面板</span><div className="header-spacer"/>
      {document&&<><div className="save-status" data-testid="plan-status"><span className={'status-dot '+(confirmed?'':'draft')}/>{confirmed?'已确认':semanticDirty?'草稿 · 已修改':'草稿'}<span className="mono">v{saved?.version}</span>{layoutDirty&&!semanticDirty&&<span className="layout-status">布局未保存</span>}</div><button className="btn header-save" disabled={disabled||!dirty||!!external} onClick={()=>void save()}>{busy==='saving'?<Loader2 className="spin" size={14}/>:<Save size={14}/>}保存草稿</button><button className="btn btn-primary" data-testid="confirm-and-continue" disabled={disabled||!!external} onClick={()=>void continueConversation()}>{busy==='continuing'?<Loader2 className="spin" size={14}/>:confirmed?<Send size={14}/>:<ShieldCheck size={14}/>} {confirmed?'继续此对话':'确认并继续对话'}</button></>}
      {!document&&<span className="header-local"><span className="status-dot"/>绑定原对话</span>}
    </header>
    <div className="workspace-nav bound-nav"><div className="workspace-nav-left"><MessageSquare size={14}/><span data-testid="bound-thread-title" className="bound-thread-title" title={threadTitle}>{threadTitle}</span><span className="bound-thread-short mono" title={threadId}>{threadId.slice(0,12)}</span></div><div className="workspace-nav-right"><span className={'thread-sync-status '+(pollError?'failed':'')} data-testid="thread-sync-status"><span className="status-dot"/>{pollError?'同步暂不可用':'对话记录持续同步'}</span>{document&&<><button className="text-button" onClick={()=>download((document.title||'plan')+'.json',JSON.stringify(document,null,2),'application/json;charset=utf-8')}><Download size={13}/>导出计划</button><button className="text-button" disabled={disabled} onClick={()=>{setComparisonId(versions.find(version=>version.confirmed)?.id??versions[0]?.id??'');setBottomTab('diff');}}><History size={13}/>版本比较</button></>}<button className="icon-button" aria-label="刷新原对话计划" disabled={disabled||!validThread} onClick={()=>void refresh()}><RefreshCw size={14}/></button></div></div>
    {(error||pollError)&&<div className="error-banner" role="alert"><span>{error??pollError}</span><div><button className="text-button" onClick={()=>void refresh()} disabled={disabled||!validThread}><RefreshCw size={12}/>重试同步</button>{error&&<button className="icon-button" aria-label="关闭错误提示" onClick={()=>setError(null)}><X size={15}/></button>}</div></div>}
    {external&&<div className="external-update-banner" role="alert" data-testid="external-plan-update"><div><strong>原对话计划已有新版本</strong><p>你未保存的修改已保留，新内容不会自动覆盖。导出修改后可载入对话的最新版本。</p></div><div><button className="btn btn-small" onClick={()=>document&&download((document.title||'plan')+'-local-edits.json',JSON.stringify(document,null,2),'application/json;charset=utf-8')}><Download size={12}/>导出当前修改</button><button className="btn btn-small" onClick={loadExternal} disabled={disabled}><RefreshCw size={12}/>载入最新版本</button></div></div>}
    {document?<><BindingContext binding={saved?.binding} threadId={threadId}/><div className="workspace-grid"><GlobalPanel document={document} onChange={update} disabled={disabled}/><main className="plan-panel"><div className="panel-heading center-heading"><span className="panel-label"><span className="step-dot">02</span>原对话计划</span><div className="view-tabs"><button className={canvasTab==='graph'?'active':''} onClick={()=>setCanvasTab('graph')}><GitBranch size={13}/>任务流程<span>{document.nodes.length}</span></button><button className={canvasTab==='outline'?'active':''} onClick={()=>setCanvasTab('outline')}><BookOpen size={13}/>输出大纲</button></div><div className="canvas-tools"><button className="icon-button" aria-label="自动布局" title="自动布局" disabled={disabled} onClick={()=>update(layoutDocument(document))}><Maximize2 size={15}/></button><button className="btn btn-small" disabled={disabled} onClick={addNode}><Plus size={13}/>添加任务</button></div></div>{canvasTab==='graph'?<ReactFlowProvider key={document.id}><FlowCanvas document={document} selected={selected} onSelect={setSelected} onChange={update} onAdd={addNode} disabled={disabled}/></ReactFlowProvider>:<OutlineEditor document={document} onChange={update} disabled={disabled}/>}</main><NodeInspector document={document} selected={selected} onChange={update} onDelete={deleteNode} disabled={disabled}/></div>
      <Workbench tab={bottomTab} onTab={tab=>{setBottomTab(tab);if(tab==='diff'&&!comparisonId)setComparisonId(versions.find(version=>version.confirmed)?.id??versions[0]?.id??'');}} document={document} compile={currentCompile?compile:null} compilePending={compilePending||!currentCompile} compileError={currentCompile?compileError:null} issues={issues} onValidate={()=>void validate()} onLocate={locate} onCopy={()=>{if(compile&&currentCompile)void navigator.clipboard.writeText(compile.text).then(()=>setNotice('提示词已复制。')).catch(()=>setError('剪贴板不可用，请导出提示词。'));}} onDownload={()=>compile&&download((document.title||'plan')+'-prompt.txt',compile.text)} versions={versions} comparisonId={comparisonId} onComparison={setComparisonId} runVersionId="" onRunVersion={()=>{}} runs={[]} selectedRun="" onSelectedRun={()=>{}} providers={[]} runProvider="mock" onProvider={()=>{}} onRun={()=>{}} disabled={disabled} confirmed={confirmed} currentVersionId={saved?.version_id??''} currentVersion={saved?.version??0} busy={busy} resultPanel={resultPanel} resultCount={continuations.length}/></>:<main className="bound-empty" data-testid="bound-empty"><div className="bound-empty-icon"><MessageSquare size={33}/></div><span className="eyebrow">CONVERSATION PLAN</span><h1>{validThread?'此对话尚未创建计划':'对话链接无效'}</h1><p>{validThread?'请在此面板绑定的同一个 Codex 对话中创建计划。完成后，面板会自动载入该对话的任务图。':'链接必须包含有效的 thread 标识。请从原 Codex 对话重新打开计划面板。'}</p>{validThread&&<><div className="bound-empty-instruction"><span className="eyebrow">SEND IN THE SAME CHAT</span><pre>{creationMessage}</pre><div><button className="btn btn-primary" disabled={disabled} onClick={()=>void copy(creationMessage)}><Copy size={14}/>复制创建计划指令</button>{nativeHost()&&<button className="btn" disabled={disabled} onClick={()=>void hostSend(creationMessage)}><Send size={14}/>请当前对话宿主创建</button>}</div></div><span className="bound-empty-wait">{busy==='initializing'?<><Loader2 className="spin" size={12}/>正在读取绑定计划…</>:<><span className="status-dot"/>正在等待原对话写入计划</>}</span></>}</main>}
    <footer className="statusbar"><span><span className="status-dot"/>BOUND CONVERSATION</span><span>{document?document.nodes.length+' 个任务 · '+document.edges.length+' 条依赖 · '+document.output_outline.length+' 个章节':'仅载入此链接绑定的原对话计划'}</span><span>{saved?'context '+saved.binding?.context_revision.slice(0,8):threadId.slice(0,20)}</span></footer>
    {notice&&<div className="toast" role="status"><Check size={15}/>{notice}<button aria-label="关闭通知" onClick={()=>setNotice(null)}><X size={12}/></button></div>}
  </div>;
}

