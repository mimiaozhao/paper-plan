import type { PlanDocument } from './generated/plan-document';
export type { PlanDocument, Constraint, Assumption, PlanNode } from './generated/plan-document';
export type ProviderId = 'mock' | 'codex';
export type PlanState = {document:PlanDocument;version:number;semantic_hash:string;confirmed:boolean;version_id:string;updated_at:string;binding:ThreadBinding|null};
export type PlanSummary = {id:string;title:string;version:number;confirmed:boolean;updated_at:string};
export type Provider = {id:ProviderId;label:string;available:boolean;reason:string|null};
export type Issue = {severity:'error'|'warning';code:string;message:string;node_id?:string;field?:string};
export type Segment = {id:string;source_type:'global'|'node'|'outline';source_id:string;field:string;text:string};
export type CompileResult = {text:string;semantic_hash:string;template_version:string;segments:Segment[];issues:Issue[]};
export type PlanVersion = {id:string;version:number;confirmed:boolean;created_at:string;semantic_hash:string;document:PlanDocument};
export type Run = {id:string;plan_id:string;version_id:string;version:number;provider:ProviderId;is_mock:boolean;status:'completed'|'failed';output:string;error:string|null;created_at:string};

export type ThreadBinding={thread_id:string;thread_title:string;task_brief:string;confirmed_decisions:string[];context_revision:string;updated_at:string};
export type NodeProgress={status:'pending'|'running'|'completed'|'failed'|'interrupted';output:string;evidence:string;adjustment_reason:string;updated_at:string};
export type Continuation={id:string;thread_id:string;plan_id:string;version_id:string;version:number;semantic_hash:string;status:'pending'|'running'|'completed'|'failed'|'superseded'|'cancelled'|'interrupted';delivery_status:'not_sent'|'sending'|'queued'|'manual';delivery_error:string|null;message:string;output:string;error:string|null;created_at:string;updated_at:string;progress:Record<string,NodeProgress>;waiting_for_mode:boolean;waiting_for_context:boolean;blocked_reason:string|null};
export type PlanRevision={id:string;thread_id:string;plan_id:string;version_id:string;version:number;notes:string;status:'pending'|'discussing'|'completed'|'candidate'|'cancelled'|'superseded';delivery_status:'not_sent'|'sending'|'queued'|'manual';delivery_error:string|null;message:string;result_turn_id:string|null;result_version_id:string|null;created_at:string;updated_at:string};
