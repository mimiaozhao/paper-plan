"""Simulated CLI adapter tests. These never launch Codex or contact a provider."""
from __future__ import annotations

import os
from pathlib import Path
import subprocess

import pytest

from backend import providers


@pytest.mark.parametrize("configured,expected", [(None, 300), ("1", 1), ("57", 57), ("900", 900)])
def test_fake_cli_happy_path_uses_bounded_timeout_and_final_output(monkeypatch, configured, expected):
    if configured is None:
        monkeypatch.delenv("PLAN_EDITOR_CODEX_TIMEOUT", raising=False)
    else:
        monkeypatch.setenv("PLAN_EDITOR_CODEX_TIMEOUT", configured)
    monkeypatch.setattr(providers, "codex_executable", lambda: "fake-codex-for-test")
    calls = []

    class FakeProcess:
        pid = 24680
        returncode = 0

        def __init__(self, command, **kwargs):
            self.command = command
            calls.append(("popen", command, kwargs))
            output_path = Path(command[command.index("--output-last-message") + 1])
            output_path.write_text("Simulated final output.\n", encoding="utf-8")

        def communicate(self, content=None, timeout=None):
            calls.append(("communicate", content, timeout))
            return "events are not final content", ""

    monkeypatch.setattr(providers.subprocess, "Popen", FakeProcess)
    output = providers.CodexProvider().execute("CONFIRMED TEST PROMPT")
    assert output == "Simulated final output."
    process_calls = [call for call in calls if call[0] == "popen"]
    assert len(process_calls) == 1
    command = process_calls[0][1]
    assert command[0] == "fake-codex-for-test"
    assert command[command.index("--sandbox") + 1] == "read-only"
    assert "--ephemeral" in command and "--ignore-user-config" in command
    assert command[-1] == "-"
    communicate = next(call for call in calls if call[0] == "communicate")
    assert "CONFIRMED TEST PROMPT" in communicate[1]
    assert communicate[2] == expected


@pytest.mark.parametrize("configured", ["", "nonsense", "0", "-1", "901", "1.5"])
def test_invalid_timeout_is_readable_and_does_not_start_a_process(monkeypatch, configured):
    monkeypatch.setenv("PLAN_EDITOR_CODEX_TIMEOUT", configured)
    monkeypatch.setattr(providers, "codex_executable", lambda: "fake-codex-for-test")

    def forbidden_process(*args, **kwargs):
        pytest.fail("An invalid timeout must be rejected before launching a process.")

    monkeypatch.setattr(providers.subprocess, "Popen", forbidden_process)
    with pytest.raises(providers.ProviderError) as caught:
        providers.CodexProvider().execute("A prompt")
    assert "PLAN_EDITOR_CODEX_TIMEOUT" in str(caught.value)
    assert "900" in str(caught.value)


def test_cli_timeout_terminates_process_tree_then_drains_without_fallback(monkeypatch):
    monkeypatch.setenv("PLAN_EDITOR_CODEX_TIMEOUT", "11")
    monkeypatch.setattr(providers, "codex_executable", lambda: "fake-codex-for-test")
    process_calls = []
    cleanup_calls = []

    class TimedOutProcess:
        pid = 35791
        returncode = -1

        def __init__(self, command, **kwargs):
            self.command = command
            self.communications = 0
            process_calls.append(command)

        def communicate(self, content=None, timeout=None):
            self.communications += 1
            cleanup_calls.append(("communicate", content, timeout))
            if self.communications == 1:
                raise subprocess.TimeoutExpired(self.command, timeout)
            return "", ""

        def kill(self):
            cleanup_calls.append(("kill",))

    def fake_cleanup(command, **kwargs):
        cleanup_calls.append(("taskkill", command, kwargs))
        return subprocess.CompletedProcess(command, 0, "", "")

    monkeypatch.setattr(providers.subprocess, "Popen", TimedOutProcess)
    monkeypatch.setattr(providers.subprocess, "run", fake_cleanup)
    with pytest.raises(providers.ProviderError) as caught:
        providers.CodexProvider().execute("TIMEOUT TEST PROMPT")
    assert "11" in str(caught.value)
    assert len(process_calls) == 1, "Timeout must not start a fallback process"
    communications = [call for call in cleanup_calls if call[0] == "communicate"]
    assert len(communications) == 2
    assert communications[0][2] == 11
    assert communications[1][1] is None and communications[1][2] == 10
    if os.name == "nt":
        kill = next(call for call in cleanup_calls if call[0] == "taskkill")
        assert kill[1] == ["taskkill", "/PID", "35791", "/T", "/F"]
        assert kill[2]["timeout"] == 10
        assert kill[2]["creationflags"] == subprocess.CREATE_NO_WINDOW
    else:
        assert ("kill",) in cleanup_calls


@pytest.mark.parametrize("returncode,stderr,write_output", [
    (0, "", False),
    (9, "not logged in", False),
    (9, "rate limit", False),
])
def test_cli_error_and_missing_final_output_are_explicit_provider_failures(monkeypatch, returncode, stderr, write_output):
    monkeypatch.setenv("PLAN_EDITOR_CODEX_TIMEOUT", "20")
    monkeypatch.setattr(providers, "codex_executable", lambda: "fake-codex-for-test")

    class FailedProcess:
        pid = 1

        def __init__(self, command, **kwargs):
            self.returncode = returncode
            if write_output:
                Path(command[command.index("--output-last-message") + 1]).write_text("result", encoding="utf-8")

        def communicate(self, content=None, timeout=None):
            return '{"type":"event"}', stderr

    monkeypatch.setattr(providers.subprocess, "Popen", FailedProcess)
    with pytest.raises(providers.ProviderError) as caught:
        providers.CodexProvider().execute("A prompt")
    assert str(caught.value)

