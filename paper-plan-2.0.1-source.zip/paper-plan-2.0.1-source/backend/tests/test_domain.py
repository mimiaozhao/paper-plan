"""Compiler and validation contracts, independent of browser rendering."""
from __future__ import annotations

from copy import deepcopy

import pytest

from backend.domain import compile_document, semantic_hash, validate_document
from backend.models import PlanDocument


def model(data):
    return PlanDocument.model_validate(data)


def error_codes(document, mode="draft"):
    return {i.code for i in validate_document(document, mode=mode) if i.severity == "error"}


def test_compiler_is_byte_deterministic_with_traceable_sources(document):
    first = compile_document(document)
    second = compile_document(document.model_copy(deep=True))
    assert first.text.encode("utf-8") == second.text.encode("utf-8")
    assert first.semantic_hash == second.semantic_hash == semantic_hash(document)
    assert first.template_version == second.template_version
    assert first.segments
    for node in document.nodes:
        segments = [s for s in first.segments if s.source_type == "node" and s.source_id == node.id]
        assert segments, f"No prompt source mapping for {node.id}"
        assert node.goal in first.text
        assert node.requirements in first.text
        assert node.output_format in first.text
        assert all(criterion in first.text for criterion in node.acceptance_criteria)
    assert document.constraints[0].text in first.text
    assert document.output_outline[0].title in first.text


def test_business_edit_changes_prompt_and_hash(document):
    edited = document.model_copy(deep=True)
    edited.nodes[0].requirements = "必须提出两个可以推翻初始解释的反例。"
    before = compile_document(document)
    after = compile_document(edited)
    assert before.text != after.text
    assert before.semantic_hash != after.semantic_hash
    assert edited.nodes[0].requirements in after.text


def test_layout_change_does_not_change_prompt_or_hash(document):
    edited = document.model_copy(deep=True)
    edited.layout["N1"].x = 931.25
    edited.layout["N1"].y = -102.5
    assert semantic_hash(document) == semantic_hash(edited)
    assert compile_document(document).text == compile_document(edited).text


def test_node_and_edge_storage_order_is_not_execution_order(document):
    reordered = document.model_copy(deep=True)
    reordered.nodes.reverse()
    reordered.edges.reverse()
    assert semantic_hash(document) == semantic_hash(reordered)
    assert compile_document(document).text == compile_document(reordered).text


def test_output_outline_order_is_meaningful(document):
    reordered = document.model_copy(deep=True)
    reordered.output_outline.reverse()
    assert semantic_hash(document) != semantic_hash(reordered)
    assert compile_document(document).text != compile_document(reordered).text


def test_edge_change_changes_dependency_prompt(document):
    edited = document.model_copy(deep=True)
    edited.edges[1].target = "N1"
    before = compile_document(document)
    after = compile_document(edited)
    assert before.semantic_hash != after.semantic_hash
    assert before.text != after.text
    assert not error_codes(edited)
    before_dependencies = {s.source_id: s.text for s in before.segments if s.source_type == "node" and s.field == "dependencies"}
    after_dependencies = {s.source_id: s.text for s in after.segments if s.source_type == "node" and s.field == "dependencies"}
    assert "N1" in before_dependencies["N3"] and "N2" in before_dependencies["N3"]
    assert "N2" in after_dependencies["N1"]
    assert "N1" in after_dependencies["N3"] and "N2" not in after_dependencies["N3"]


@pytest.mark.parametrize("mutation,expected", [
    (lambda d: d["edges"].append({"id": "E3", "source": "N3", "target": "N1"}), "cycle"),
    (lambda d: d["edges"][0].update(target="missing"), "dangling_edge"),
    (lambda d: d["edges"][0].update(target="N1"), "self_edge"),
    (lambda d: d["edges"].append({"id": "E3", "source": "N1", "target": "N3"}), "duplicate_edge"),
    (lambda d: d["nodes"].append(deepcopy(d["nodes"][0])), "duplicate_id"),
    (lambda d: d["edges"][1].update(id="E1"), "duplicate_id"),
    (lambda d: d["output_outline"][0]["node_ids"].append("missing"), "invalid_outline_ref"),
    (lambda d: d["nodes"][0]["locked_fields"].append("invented_field"), "invalid_locked_field"),
    (lambda d: d["output_outline"][0]["node_ids"].append("N1"), "invalid_outline_ref"),
    (lambda d: d["constraints"].append(deepcopy(d["constraints"][0])), "duplicate_id"),
    (lambda d: d["assumptions"].append(deepcopy(d["assumptions"][0])), "duplicate_id"),
])
def test_structural_errors_are_rejected(document_dict, mutation, expected):
    mutation(document_dict)
    invalid = model(document_dict)
    assert expected in error_codes(invalid)
    with pytest.raises(Exception) as caught:
        compile_document(invalid)
    assert getattr(caught.value, "issues", None), "Compiler errors must expose actionable issues"


@pytest.mark.parametrize("field,empty", [
    ("title", ""), ("goal", ""), ("inputs", []), ("requirements", ""),
    ("output_format", ""), ("acceptance_criteria", []),
])
def test_incomplete_node_is_savable_draft_but_not_compilable(document_dict, field, empty):
    document_dict["nodes"][0][field] = empty
    invalid = model(document_dict)
    assert "missing_field" in error_codes(invalid, mode="confirm")
    with pytest.raises(Exception):
        compile_document(invalid)


def test_pending_assumption_is_visible_warning_and_blocks_confirmation(document):
    document.assumptions[0].status = "pending"
    preview = compile_document(document)
    assert any(i.code == "pending_assumption" and i.severity == "warning" for i in preview.issues)
    assert "pending_assumption" in error_codes(document, mode="confirm")
    for decision in ("accepted", "rejected"):
        decided = document.model_copy(deep=True)
        decided.assumptions[0].status = decision
        assert "pending_assumption" not in error_codes(decided, mode="confirm")


