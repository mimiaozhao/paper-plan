"""Storage, approval, concurrency and run version binding through the public API."""
from __future__ import annotations

from copy import deepcopy

import pytest


def confirm(client, state):
    response = client.post(f"/api/plans/{state['document']['id']}/confirm", json={"expected_version": state["version"]})
    assert response.status_code == 200, response.text
    return response.json()


def save(client, state, document):
    response = client.put(f"/api/plans/{state['document']['id']}", json={"document": document, "expected_version": state["version"]})
    assert response.status_code == 200, response.text
    return response.json()


def test_import_creates_new_identity_and_persists_business_content(client, document_dict):
    first = client.post("/api/plans", json={"document": document_dict})
    second = client.post("/api/plans", json={"document": document_dict})
    assert first.status_code == second.status_code == 200
    state = first.json()
    assert state["document"]["id"] != document_dict["id"]
    assert state["document"]["id"] != second.json()["document"]["id"]
    assert state["document"]["provenance"] == "import"
    assert state["document"]["nodes"] == document_dict["nodes"]
    assert state["document"]["edges"] == document_dict["edges"]
    assert state["document"]["output_outline"] == document_dict["output_outline"]
    assert not state["confirmed"]
    fetched = client.get(f"/api/plans/{state['document']['id']}")
    assert fetched.status_code == 200
    assert fetched.json() == state
    listed = client.get("/api/plans").json()["plans"]
    assert state["document"]["id"] in {item["id"] for item in listed}


def test_layout_only_save_preserves_approval_version_hash_and_prompt(client, saved_plan):
    approved = confirm(client, saved_plan)
    prompt_before = client.post("/api/compile", json={"document": approved["document"]}).json()["text"]
    moved = deepcopy(approved["document"])
    moved["layout"]["N1"] = {"x": 777, "y": -222}
    after = save(client, approved, moved)
    assert after["confirmed"] is True
    assert after["version"] == approved["version"]
    assert after["version_id"] == approved["version_id"]
    assert after["semantic_hash"] == approved["semantic_hash"]
    assert after["document"]["layout"]["N1"] == moved["layout"]["N1"]
    prompt_after = client.post("/api/compile", json={"document": after["document"]}).json()["text"]
    assert prompt_after == prompt_before


def test_business_edit_invalidates_confirmation_and_keeps_snapshot_immutable(client, saved_plan):
    approved = confirm(client, saved_plan)
    before_versions = client.get(f"/api/plans/{approved['document']['id']}/versions").json()["versions"]
    snapshot = next(item for item in before_versions if item["id"] == approved["version_id"])
    edited = deepcopy(approved["document"])
    edited["nodes"][0]["goal"] = "NEW UNIQUE GOAL: identify competing hypotheses."
    after = save(client, approved, edited)
    assert after["version"] == approved["version"] + 1
    assert after["version_id"] != approved["version_id"]
    assert after["semantic_hash"] != approved["semantic_hash"]
    assert after["confirmed"] is False
    versions = client.get(f"/api/plans/{approved['document']['id']}/versions").json()["versions"]
    old_snapshot = next(item for item in versions if item["id"] == approved["version_id"])
    assert old_snapshot == snapshot
    assert old_snapshot["document"]["nodes"][0]["goal"] == approved["document"]["nodes"][0]["goal"]


def test_stale_save_and_confirmation_are_conflicts(client, saved_plan):
    edited = deepcopy(saved_plan["document"])
    edited["goal"] += " 仅报告证据支持的结论。"
    updated = save(client, saved_plan, edited)
    stale = client.put(f"/api/plans/{saved_plan['document']['id']}", json={"document": saved_plan["document"], "expected_version": saved_plan["version"]})
    assert stale.status_code == 409
    stale_confirm = client.post(f"/api/plans/{saved_plan['document']['id']}/confirm", json={"expected_version": saved_plan["version"]})
    assert stale_confirm.status_code == 409
    latest = client.get(f"/api/plans/{saved_plan['document']['id']}").json()
    assert latest["document"] == updated["document"]
    assert latest["version"] == updated["version"]


def test_pending_assumptions_block_confirmation_until_decided(client, saved_plan):
    pending = deepcopy(saved_plan["document"])
    pending["assumptions"][0]["status"] = "pending"
    state = save(client, saved_plan, pending)
    preview = client.post("/api/compile", json={"document": state["document"]})
    assert preview.status_code == 200
    assert any(i["code"] == "pending_assumption" for i in preview.json()["issues"])
    failed = client.post(f"/api/plans/{state['document']['id']}/confirm", json={"expected_version": state["version"]})
    assert failed.status_code == 422
    assert client.get(f"/api/plans/{state['document']['id']}").json()["confirmed"] is False
    pending["assumptions"][0]["status"] = "accepted"
    decided = save(client, state, pending)
    assert confirm(client, decided)["confirmed"] is True


def test_incomplete_draft_is_saved_but_compile_and_confirmation_reject(client, saved_plan):
    incomplete = deepcopy(saved_plan["document"])
    incomplete["nodes"][0]["acceptance_criteria"] = []
    state = save(client, saved_plan, incomplete)
    compiled = client.post("/api/compile", json={"document": state["document"]})
    assert compiled.status_code == 422
    assert compiled.json()["detail"]["issues"]
    confirmed = client.post(f"/api/plans/{state['document']['id']}/confirm", json={"expected_version": state["version"]})
    assert confirmed.status_code == 422


def test_invalid_graph_is_not_saved(client, saved_plan):
    invalid = deepcopy(saved_plan["document"])
    invalid["edges"].append({"id": "E3", "source": "N3", "target": "N1"})
    response = client.put(f"/api/plans/{saved_plan['document']['id']}", json={"document": invalid, "expected_version": saved_plan["version"]})
    assert response.status_code == 422
    assert client.get(f"/api/plans/{saved_plan['document']['id']}").json()["document"] == saved_plan["document"]


def test_mock_run_binds_frozen_confirmed_version_after_new_draft(client, saved_plan):
    approved = confirm(client, saved_plan)
    edited = deepcopy(approved["document"])
    edited["goal"] = "AFTER APPROVAL: a different output purpose."
    draft = save(client, approved, edited)
    response = client.post(f"/api/plans/{approved['document']['id']}/runs", json={"provider": "mock", "version_id": approved["version_id"]})
    assert response.status_code == 200, response.text
    run = response.json()
    assert run["version_id"] == approved["version_id"]
    assert run["version"] == approved["version"]
    assert run["provider"] == "mock" and run["is_mock"] is True
    assert run["status"] == "completed" and run["output"]
    assert run["error"] is None
    runs = client.get(f"/api/plans/{approved['document']['id']}/runs").json()["runs"]
    assert next(item for item in runs if item["id"] == run["id"]) == run
    assert client.get(f"/api/plans/{approved['document']['id']}").json()["version_id"] == draft["version_id"]


def test_unconfirmed_and_foreign_versions_cannot_run(client, saved_plan, document_dict):
    rejected = client.post(f"/api/plans/{saved_plan['document']['id']}/runs", json={"provider": "mock", "version_id": saved_plan["version_id"]})
    assert rejected.status_code in (409, 422)
    other = client.post("/api/plans", json={"document": document_dict}).json()
    other = confirm(client, other)
    foreign = client.post(f"/api/plans/{saved_plan['document']['id']}/runs", json={"provider": "mock", "version_id": other["version_id"]})
    assert foreign.status_code in (404, 409, 422)


def test_app_restart_restores_saved_plan_and_confirmation(tmp_path, document_dict):
    from backend.app import create_app
    from fastapi.testclient import TestClient
    database = tmp_path / "restart.sqlite3"
    with TestClient(create_app(db_path=database)) as client:
        state = client.post("/api/plans", json={"document": document_dict}).json()
        approved = confirm(client, state)
    with TestClient(create_app(db_path=database)) as restarted:
        loaded = restarted.get(f"/api/plans/{approved['document']['id']}")
        assert loaded.status_code == 200
        assert loaded.json() == approved
        snapshots = restarted.get(f"/api/plans/{approved['document']['id']}/versions").json()["versions"]
        assert any(item["id"] == approved["version_id"] and item["confirmed"] for item in snapshots)


def test_mock_generation_is_explicit_and_does_not_claim_real_provider(client):
    request = "帮我评估候选方向并提出最小验证方案"
    response = client.post("/api/plans/generate", json={"request": request, "provider": "mock"})
    assert response.status_code == 200, response.text
    state = response.json()
    assert state["document"]["provenance"] == "mock"
    assert state["confirmed"] is False
    assert state["document"]["original_request"] == request
    assert state["document"]["nodes"]


@pytest.mark.parametrize("error_kind", ["provider_error", "runtime_error"])
def test_provider_execution_failure_is_recorded_without_mock_fallback(client, saved_plan, monkeypatch, error_kind):
    from backend import providers
    approved = confirm(client, saved_plan)
    calls = []

    class FailingProvider:
        def execute(self, prompt):
            calls.append(("execute", prompt))
            if error_kind == "provider_error":
                raise providers.ProviderError("SIMULATED REAL PROVIDER FAILURE")
            raise RuntimeError("SIMULATED UNEXPECTED PROVIDER FAILURE")

    def select_provider(name):
        calls.append(("provider", name))
        assert name == "codex", "Failure must not fall back to mock provider"
        return FailingProvider()

    monkeypatch.setattr(providers, "get_provider", select_provider)
    response = client.post(f"/api/plans/{approved['document']['id']}/runs", json={"provider": "codex", "version_id": approved["version_id"]})
    assert response.status_code == 200, response.text
    run = response.json()
    assert run["status"] == "failed"
    assert run["provider"] == "codex" and run["is_mock"] is False
    assert run["output"] == ""
    assert run["error"]
    if error_kind == "provider_error":
        assert "FAILURE" in run["error"]
    assert calls[0] == ("provider", "codex")
    assert sum(call[0] == "execute" for call in calls) == 1
    assert run["version_id"] == approved["version_id"]
    saved_runs = client.get(f"/api/plans/{approved['document']['id']}/runs").json()["runs"]
    assert next(item for item in saved_runs if item["id"] == run["id"]) == run


@pytest.mark.parametrize("error_kind", ["provider_error", "runtime_error"])
def test_plan_generation_failure_does_not_fallback_to_mock(client, monkeypatch, error_kind):
    from backend import providers
    calls = []

    class FailingProvider:
        def generate(self, request):
            calls.append(("generate", request))
            if error_kind == "provider_error":
                raise providers.ProviderError("SIMULATED GENERATION FAILURE")
            raise RuntimeError("SIMULATED GENERATION FAILURE")

    def select_provider(name):
        calls.append(("provider", name))
        assert name == "codex"
        return FailingProvider()

    monkeypatch.setattr(providers, "get_provider", select_provider)
    response = client.post("/api/plans/generate", json={"request": "a meaningful new request", "provider": "codex"})
    assert response.status_code >= 400, response.text
    assert response.json()["detail"]
    if error_kind == "provider_error":
        assert "FAILURE" in response.text
    assert calls[0] == ("provider", "codex")
    assert sum(call[0] == "generate" for call in calls) == 1
    assert client.get("/api/plans").json()["plans"] == []




def test_execution_prompt_comes_from_confirmed_snapshot_not_latest_draft(client, saved_plan, monkeypatch):
    from backend import providers
    approved = confirm(client, saved_plan)
    edited = deepcopy(approved["document"])
    edited["goal"] = "UNCONFIRMED GOAL MUST NOT REACH EXECUTION"
    save(client, approved, edited)
    executed_prompts = []

    class RecordingProvider:
        def execute(self, prompt):
            executed_prompts.append(prompt)
            return "Recorded snapshot execution."

    monkeypatch.setattr(providers, "get_provider", lambda name: RecordingProvider())
    response = client.post(f"/api/plans/{approved['document']['id']}/runs", json={"provider": "mock", "version_id": approved["version_id"]})
    assert response.status_code == 200, response.text
    expected_prompt = client.post("/api/compile", json={"document": approved["document"]}).json()["text"]
    assert executed_prompts == [expected_prompt]
    assert approved["document"]["goal"] in executed_prompts[0]
    assert edited["goal"] not in executed_prompts[0]
    assert response.json()["version_id"] == approved["version_id"]

