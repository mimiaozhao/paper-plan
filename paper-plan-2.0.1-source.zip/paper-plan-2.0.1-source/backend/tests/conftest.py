"""Independent fixtures; API tests use isolated, temporary SQLite databases."""
from __future__ import annotations

import sys
from copy import deepcopy
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


@pytest.fixture
def document_dict():
    def node(node_id, title, goal):
        return {
            "id": node_id, "title": title, "goal": goal,
            "inputs": ["用户提供的需求与材料"],
            "requirements": "给出证据及尚待验证的信息。",
            "output_format": "Markdown 表格",
            "acceptance_criteria": ["每项结论均有可追溯依据。"],
            "locked_fields": [],
        }

    return {
        "schema_version": 1, "id": "test-plan", "title": "研究论证方案",
        "original_request": "比较候选研究方向，形成可验证的研究方案。",
        "goal": "形成有明确证据边界的研究报告。", "provenance": "mock",
        "constraints": [{"id": "C1", "text": "禁止编造数据或引用。", "locked": True}],
        "assumptions": [{"id": "A1", "text": "面向研究组内部讨论。", "status": "accepted"}],
        "nodes": [
            node("N1", "整理证据", "整理输入材料和可靠证据。"),
            node("N2", "竞争解释", "比较至少两种竞争解释。"),
            node("N3", "形成方案", "根据证据与竞争解释形成最小验证方案。"),
        ],
        "edges": [
            {"id": "E1", "source": "N1", "target": "N3"},
            {"id": "E2", "source": "N2", "target": "N3"},
        ],
        "output_outline": [
            {"id": "O1", "title": "问题与证据", "node_ids": ["N1", "N2"]},
            {"id": "O2", "title": "验证方案", "node_ids": ["N3"]},
        ],
        "layout": {"N1": {"x": 20, "y": 40}, "N2": {"x": 20, "y": 240}, "N3": {"x": 400, "y": 140}},
    }


@pytest.fixture
def document(document_dict):
    from backend.models import PlanDocument
    return PlanDocument.model_validate(document_dict)


@pytest.fixture(autouse=True)
def isolate_default_app_database(tmp_path, monkeypatch):
    # backend.app also exports an ASGI app at import time; isolate that database too.
    monkeypatch.setenv("PLAN_EDITOR_DB", str(tmp_path / "module-default.sqlite3"))


@pytest.fixture
def app(tmp_path):
    from backend.app import create_app
    return create_app(db_path=tmp_path / "isolated-plans.sqlite3")


@pytest.fixture
def client(app):
    from fastapi.testclient import TestClient
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture
def saved_plan(client, document_dict):
    response = client.post("/api/plans", json={"document": deepcopy(document_dict)})
    assert response.status_code == 200, response.text
    return response.json()


