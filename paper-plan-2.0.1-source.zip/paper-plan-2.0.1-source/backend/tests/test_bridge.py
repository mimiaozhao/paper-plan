"""Bridge regression checks use temporary DBs and simulated dispatch only."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from threading import Barrier, Event
import sys
from types import ModuleType
import pytest
from backend.models import PlanDocument
from backend.storage import Store, VersionConflict, identifier, make_binding

THREAD = "test-thread-001"

def payload(document, **overrides):
    body = {"document": document, "thread_title": "当前研究任务", "task_brief": "比较候选研究并形成可验证的方案。", "confirmed_decisions": ["最终报告采用中文", "不编造证据"]}
    body.update(overrides)
    return body

def bind(client, document):
    response = client.post(f"/api/threads/{THREAD}/plan", json=payload(document))
    assert response.status_code == 200, response.text
    return response.json()

def confirm(client, state):
    response = client.post(f"/api/plans/{state['document']['id']}/confirm", json={"expected_version": state["version"]})
    assert response.status_code == 200, response.text
    return response.json()

def request(client, state):
    response = client.post(f"/api/threads/{THREAD}/continuations", json={"expected_version": state["version"], "version_id": state["version_id"]})
    assert response.status_code == 200, response.text
    return response.json()

def fake_dispatcher(monkeypatch, function):
    import backend
    module = ModuleType("backend.dispatcher")
    module.dispatch_to_codex = function
    monkeypatch.setitem(sys.modules, "backend.dispatcher", module)
    monkeypatch.setattr(backend, "dispatcher", module, raising=False)

def test_empty_binding_and_creation_is_not_raw_transcript(client, document_dict):
    assert client.get(f"/api/threads/{THREAD}/plan").json() == {"state": None}
    assert client.get(f"/api/threads/{THREAD}/continuations").json() == {"continuations": []}
    state = bind(client, document_dict)
    assert state["document"]["id"] != document_dict["id"]
    assert state["document"]["provenance"] == "conversation"
    assert state["binding"]["thread_id"] == THREAD
    assert len(state["binding"]["context_revision"]) == 64
    assert "transcript" not in state["binding"]
    assert client.get(f"/api/threads/{THREAD}/plan").json()["state"] == state
    assert client.get(f"/api/plans/{state['document']['id']}").json()["binding"] == state["binding"]
    duplicate = client.post(f"/api/threads/{THREAD}/plan", json=payload(document_dict))
    assert duplicate.status_code == 409
    assert len(client.get('/api/plans').json()['plans']) == 1

@pytest.mark.parametrize("thread_id", ["with spaces", "中文", "x" * 129])
def test_thread_identifier_validation(client, document_dict, thread_id):
    assert client.post(f"/api/threads/{thread_id}/plan", json=payload(document_dict)).status_code == 422

@pytest.mark.parametrize("field", ["thread_title", "task_brief"])
def test_empty_extracted_context_is_rejected(client, document_dict, field):
    assert client.post(f"/api/threads/{THREAD}/plan", json=payload(document_dict, **{field: ""})).status_code == 422

def test_metadata_only_update_preserves_confirmation_snapshot_and_prompt(client, document_dict):
    state = confirm(client, bind(client, document_dict))
    original = client.get(f"/api/threads/{THREAD}/confirmed-plan").json()
    updated = client.put(f"/api/threads/{THREAD}/plan", json=payload(state["document"], expected_version=state["version"], thread_title="新的标题", task_brief="更新后的任务上下文", confirmed_decisions=["保留原确认计划"])).json()
    assert updated["confirmed"] is True
    assert updated["version_id"] == state["version_id"]
    assert updated["version"] == state["version"]
    assert updated["semantic_hash"] == state["semantic_hash"]
    assert updated["binding"]["context_revision"] != state["binding"]["context_revision"]
    current = client.get(f"/api/threads/{THREAD}/confirmed-plan").json()
    assert current["compiled"] == original["compiled"]
    assert current["document"] == original["document"]
    assert len(client.get(f"/api/plans/{state['document']['id']}/versions").json()["versions"]) == 1

def test_thread_title_only_keeps_context_revision(client, document_dict):
    state = bind(client, document_dict)
    updated = client.put(f"/api/threads/{THREAD}/plan", json=payload(state["document"], expected_version=state["version"], thread_title="换标题")).json()
    assert updated["binding"]["context_revision"] == state["binding"]["context_revision"]

@pytest.mark.parametrize("change", ["constraint_text", "constraint_delete", "constraint_unlock", "node_value", "node_unlock", "node_delete"])
def test_agent_cannot_change_or_remove_existing_locks(client, document_dict, change):
    document_dict["nodes"][0]["locked_fields"] = ["goal"]
    state = bind(client, document_dict)
    proposed = deepcopy(state["document"])
    if change == "constraint_text": proposed["constraints"][0]["text"] = "代理改动"
    if change == "constraint_delete": proposed["constraints"] = []
    if change == "constraint_unlock": proposed["constraints"][0]["locked"] = False
    if change == "node_value": proposed["nodes"][0]["goal"] = "代理改动"
    if change == "node_unlock": proposed["nodes"][0]["locked_fields"] = []
    if change == "node_delete":
        proposed["nodes"] = proposed["nodes"][1:]
        proposed["edges"] = [edge for edge in proposed["edges"] if edge["source"] != "N1"]
        proposed["output_outline"][0]["node_ids"] = ["N2"]
        proposed["layout"].pop("N1")
    response = client.put(f"/api/threads/{THREAD}/plan", json=payload(proposed, expected_version=state["version"]))
    assert response.status_code == 409, response.text
    assert client.get(f"/api/threads/{THREAD}/plan").json()["state"] == state

def test_user_save_can_override_locks_and_agent_version_conflicts(client, document_dict):
    state = bind(client, document_dict)
    proposed = deepcopy(state["document"])
    proposed["constraints"][0]["text"] = "用户主动修改锁定约束"
    response = client.put(f"/api/plans/{proposed['id']}", json={"document": proposed, "expected_version": state["version"]})
    assert response.status_code == 200
    assert response.json()["version"] == 2
    assert response.json()["binding"] == state["binding"]
    assert client.put(f"/api/threads/{THREAD}/plan", json=payload(state["document"], expected_version=state["version"])).status_code == 409

def test_confirmed_get_uses_frozen_layout_and_rejects_old_version(client, document_dict):
    state = bind(client, document_dict)
    assert client.get(f"/api/threads/{THREAD}/confirmed-plan").status_code == 409
    state = confirm(client, state)
    moved = deepcopy(state["document"])
    moved["layout"]["N1"] = {"x": 999, "y": 999}
    updated = client.put(f"/api/plans/{moved['id']}", json={"document": moved, "expected_version": state["version"]}).json()
    frozen = client.get(f"/api/threads/{THREAD}/confirmed-plan", params={"version_id": state["version_id"]}).json()
    assert frozen["document"]["layout"] == state["document"]["layout"]
    assert frozen["state"]["document"]["layout"] == moved["layout"]
    assert updated["confirmed"] is True
    assert client.get(f"/api/threads/{THREAD}/confirmed-plan", params={"version_id": "old"}).status_code == 409

def test_request_claim_complete_are_idempotent_and_never_model_call(client, document_dict, monkeypatch):
    from backend import providers
    monkeypatch.setattr(providers, "get_provider", lambda *_: pytest.fail("Bridge must not launch standalone model"))
    fake_dispatcher(monkeypatch, lambda *_: pytest.fail("Request or claim must not dispatch automatically"))
    state = confirm(client, bind(client, document_dict))
    continuation = request(client, state)
    assert continuation["status"] == "pending" and continuation["delivery_status"] == "not_sent"
    assert state["version_id"] in continuation["message"] and THREAD in continuation["message"]
    assert request(client, state) == continuation
    path = f"/api/threads/{THREAD}/continuations/{continuation['id']}"
    claimed = client.post(path + "/claim", json={"claimant_id": "current-codex"}).json()
    assert claimed["continuation"]["status"] == "running"
    assert claimed["compiled"]["semantic_hash"] == state["semantic_hash"]
    assert claimed["document"] == state["document"]
    assert client.post(path + "/claim", json={"claimant_id": "current-codex"}).json() == claimed
    assert client.post(path + "/claim", json={"claimant_id": "different-agent"}).status_code == 409
    assert client.post(path + "/complete", json={"claim_token": "wrong", "status": "completed", "output": "fake", "error": None}).status_code == 409
    result = {"claim_token": claimed["claim_token"], "status": "completed", "output": "当前对话真实完成的成果", "error": None}
    completed = client.post(path + "/complete", json=result)
    assert completed.status_code == 200
    assert completed.json()["output"] == result["output"]
    assert client.post(path + "/complete", json=result).json() == completed.json()
    assert client.post(path + "/complete", json={**result, "output": "不同结果"}).status_code == 409
    assert client.get(f"/api/threads/{THREAD}/continuations").json()["continuations"][0] == completed.json()

def test_pending_superseded_by_semantic_edit_but_running_can_finish(client, document_dict):
    state = confirm(client, bind(client, document_dict))
    pending = request(client, state)
    moved = deepcopy(state["document"])
    moved["layout"]["N1"]["x"] += 10
    state = client.put(f"/api/plans/{moved['id']}", json={"document": moved, "expected_version": state["version"]}).json()
    assert client.get(f"/api/threads/{THREAD}/continuations").json()["continuations"][0]["status"] == "pending"
    changed = deepcopy(state["document"])
    changed["goal"] += " 新目标"
    new = client.put(f"/api/plans/{changed['id']}", json={"document": changed, "expected_version": state["version"]}).json()
    assert client.get(f"/api/threads/{THREAD}/continuations").json()["continuations"][0]["status"] == "superseded"
    old_path = f"/api/threads/{THREAD}/continuations/{pending['id']}"
    assert client.post(old_path + "/claim", json={"claimant_id": "agent"}).status_code == 409
    assert client.post(f"/api/threads/{THREAD}/continuations", json={"expected_version": state["version"], "version_id": state["version_id"]}).status_code == 409
    new = confirm(client, new)
    active = request(client, new)
    path = f"/api/threads/{THREAD}/continuations/{active['id']}"
    claimed = client.post(path + "/claim", json={"claimant_id": "agent"}).json()
    changed["goal"] += " 再次编辑"
    client.put(f"/api/plans/{changed['id']}", json={"document": changed, "expected_version": new["version"]})
    complete = client.post(path + "/complete", json={"claim_token": claimed["claim_token"], "status": "failed", "output": "", "error": "原确认快照缺少资料"})
    assert complete.status_code == 200 and complete.json()["status"] == "failed"

def test_cross_thread_claim_and_document_id_are_rejected(client, document_dict):
    state = confirm(client, bind(client, document_dict))
    continuation = request(client, state)
    assert client.post(f"/api/threads/other-thread/continuations/{continuation['id']}/claim", json={"claimant_id": "agent"}).status_code == 409
    proposed = deepcopy(state["document"])
    proposed["id"] = "wrong-plan"
    assert client.put(f"/api/threads/{THREAD}/plan", json=payload(proposed, expected_version=state["version"])).status_code == 409

@pytest.mark.parametrize("delivery", ["queued", "manual", "exception"])
def test_dispatch_is_explicit_and_records_truthful_delivery(client, document_dict, monkeypatch, delivery):
    calls=[]
    def deliver(thread_id, message):
        calls.append((thread_id,message))
        if delivery == "exception": raise RuntimeError("Do not expose this exception")
        return {"status": delivery, "error": "未找到原对话" if delivery == "manual" else None}
    fake_dispatcher(monkeypatch,deliver)
    state = confirm(client, bind(client, document_dict))
    continuation = request(client,state)
    assert calls == []
    path=f"/api/threads/{THREAD}/continuations/{continuation['id']}"
    response=client.post(path + '/dispatch')
    assert response.status_code == 200, response.text
    assert response.json()['status'] == 'pending'
    assert response.json()['delivery_status'] == ('manual' if delivery == 'exception' else delivery)
    assert len(calls)==1
    if delivery=='queued':
        assert client.post(path + '/dispatch').json()==response.json()
        assert len(calls)==1
    else:
        assert response.json()['delivery_error']
        assert 'Do not expose' not in response.json()['delivery_error']

def test_concurrent_dispatch_sending_state_prevents_duplicate(client, document_dict, monkeypatch):
    entered,release=Event(),Event()
    calls=[]
    def deliver(thread_id,message):
        calls.append(thread_id)
        entered.set()
        assert release.wait(5)
        return {'status':'queued','error':None}
    fake_dispatcher(monkeypatch,deliver)
    state=confirm(client,bind(client,document_dict))
    continuation=request(client,state)
    path=f"/api/threads/{THREAD}/continuations/{continuation['id']}/dispatch"
    with ThreadPoolExecutor(max_workers=2) as pool:
        first=pool.submit(client.post,path)
        assert entered.wait(5)
        second=client.post(path)
        assert second.status_code==200 and second.json()['delivery_status']=='sending'
        release.set()
        assert first.result().json()['delivery_status']=='queued'
    assert len(calls)==1

def test_bound_creation_atomic_across_connections(tmp_path, document):
    path=tmp_path/'bridge-race.sqlite3'
    stores=[Store(path),Store(path)]
    barrier=Barrier(2)
    def create(index):
        barrier.wait()
        candidate=document.model_copy(deep=True,update={'id':identifier('plan'),'provenance':'conversation'})
        try:
            return stores[index].create_bound(candidate,make_binding(THREAD,'当前任务','已提取任务',[]))
        except VersionConflict:
            return None
    try:
        with ThreadPoolExecutor(max_workers=2) as pool:
            results=list(pool.map(create,[0,1]))
        assert sum(result is not None for result in results)==1
        assert len(stores[0].list())==1
        assert stores[0].thread_plan(THREAD).document.id==stores[1].thread_plan(THREAD).document.id
    finally:
        for store in stores: store.close()

def test_claim_atomic_across_connections(tmp_path, document):
    path=tmp_path/'claim-race.sqlite3'
    stores=[Store(path),Store(path)]
    state=stores[0].create_bound(document.model_copy(deep=True,update={'id':identifier('plan'),'provenance':'conversation'}),make_binding(THREAD,'当前任务','已提取任务',[]))
    state=stores[0].confirm(state.document.id,state.version)
    continuation=stores[0].request_continuation(THREAD,state.version,state.version_id)
    barrier=Barrier(2)
    def claim(index):
        barrier.wait()
        try:
            return stores[index].claim_continuation(THREAD,continuation.id,f'agent-{index}')
        except VersionConflict:
            return None
    try:
        with ThreadPoolExecutor(max_workers=2) as pool:
            results=list(pool.map(claim,[0,1]))
        assert sum(result is not None for result in results)==1
        winner=next(index for index,result in enumerate(results) if result is not None)
        assert stores[1-winner].claim_continuation(THREAD,continuation.id,f'agent-{winner}')['claim_token']==results[winner]['claim_token']
    finally:
        for store in stores: store.close()

def test_bound_plan_cannot_launch_standalone_model(client, document_dict, monkeypatch):
    from backend import providers
    monkeypatch.setattr(providers, 'get_provider', lambda *_: pytest.fail('Bound plan must not start standalone CLI'))
    state=confirm(client,bind(client,document_dict))
    response=client.post(f"/api/plans/{state['document']['id']}/runs",json={'provider':'codex','version_id':state['version_id']})
    assert response.status_code==409
    assert client.get(f"/api/plans/{state['document']['id']}/runs").json()['runs']==[]
    continuation=request(client,state)
    assert '/skills/plan-panel/SKILL.md' in continuation['message']
    assert '/scripts/bridge.py' in continuation['message']

def test_dispatch_rejects_stale_and_already_running_requests(client, document_dict, monkeypatch):
    fake_dispatcher(monkeypatch, lambda *_: pytest.fail('Invalid request must not dispatch'))
    state=confirm(client,bind(client,document_dict))
    continuation=request(client,state)
    path=f"/api/threads/{THREAD}/continuations/{continuation['id']}"
    claim=client.post(path+'/claim',json={'claimant_id':'agent'})
    assert claim.status_code==200
    assert client.post(path+'/dispatch').status_code==409
    document=deepcopy(state['document'])
    document['goal']+=' 新任务'
    client.put(f"/api/plans/{document['id']}",json={'document':document,'expected_version':state['version']})
    assert client.post(path+'/dispatch').status_code==409

def test_continuation_request_atomic_across_connections(tmp_path, document):
    path=tmp_path/'request-race.sqlite3'
    stores=[Store(path),Store(path)]
    state=stores[0].create_bound(document.model_copy(deep=True,update={'id':identifier('plan'),'provenance':'conversation'}),make_binding(THREAD,'当前任务','已提取任务',[]))
    state=stores[0].confirm(state.document.id,state.version)
    barrier=Barrier(2)
    def request_same(index):
        barrier.wait()
        return stores[index].request_continuation(THREAD,state.version,state.version_id)
    try:
        with ThreadPoolExecutor(max_workers=2) as pool:
            results=list(pool.map(request_same,[0,1]))
        assert results[0].id==results[1].id
        assert len(stores[0].continuations(THREAD))==1
    finally:
        for store in stores: store.close()

@pytest.mark.parametrize('origin', ['https://unrelated.example', 'http://127.0.0.1:9999', 'null', ''])
def test_dispatch_rejects_cross_origin_without_changing_request(client, document_dict, monkeypatch, origin):
    fake_dispatcher(monkeypatch, lambda *_: pytest.fail('Cross-origin dispatch must not send a message'))
    state=confirm(client,bind(client,document_dict))
    continuation=request(client,state)
    path=f"/api/threads/{THREAD}/continuations/{continuation['id']}/dispatch"
    response=client.post(path,headers={'Origin':origin})
    assert response.status_code==403
    unchanged=client.get(f"/api/threads/{THREAD}/continuations").json()['continuations'][0]
    assert unchanged['delivery_status']=='not_sent' and unchanged['status']=='pending'

@pytest.mark.parametrize('origin', ['http://testserver', 'http://localhost:5173', 'http://127.0.0.1:5173'])
def test_dispatch_accepts_same_origin_and_explicit_local_development_origins(client, document_dict, monkeypatch, origin):
    calls=[]
    fake_dispatcher(monkeypatch, lambda tid,message: calls.append(tid) or {'status':'queued','error':None})
    state=confirm(client,bind(client,document_dict))
    continuation=request(client,state)
    response=client.post(f"/api/threads/{THREAD}/continuations/{continuation['id']}/dispatch",headers={'Origin':origin})
    assert response.status_code==200 and response.json()['delivery_status']=='queued'
    assert calls==[THREAD]

def test_same_claimant_can_recover_running_snapshot_after_newer_semantic_draft(client, document_dict):
    state=confirm(client,bind(client,document_dict))
    continuation=request(client,state)
    path=f"/api/threads/{THREAD}/continuations/{continuation['id']}"
    original=client.post(path+'/claim',json={'claimant_id':'current-agent'}).json()
    changed=deepcopy(state['document'])
    changed['goal']='用户正在编辑的全新目标，不可进入原运行快照。'
    changed['nodes'][0]['requirements']='全新的草稿要求，原执行继续使用旧要求。'
    updated=client.put(f"/api/plans/{changed['id']}",json={'document':changed,'expected_version':state['version']}).json()
    assert updated['confirmed'] is False and updated['version']==state['version']+1
    retried=client.post(path+'/claim',json={'claimant_id':'current-agent'})
    assert retried.status_code==200,retried.text
    assert retried.json()==original
    assert retried.json()['document']==state['document']
    assert retried.json()['compiled']['text']==original['compiled']['text']
    assert changed['goal'] not in retried.json()['compiled']['text']
    assert client.post(path+'/claim',json={'claimant_id':'different-agent'}).status_code==409
    result={'claim_token':retried.json()['claim_token'],'status':'completed','output':'完成原确认版本的任务','error':None}
    completed=client.post(path+'/complete',json=result)
    assert completed.status_code==200 and completed.json()['output']==result['output']
    assert client.post(path+'/complete',json=result).json()==completed.json()
    assert client.post(path+'/claim',json={'claimant_id':'current-agent'}).status_code==409

def test_same_claimant_retry_preserves_old_snapshot_when_new_version_is_confirmed(client, document_dict):
    state=confirm(client,bind(client,document_dict))
    continuation=request(client,state)
    path=f"/api/threads/{THREAD}/continuations/{continuation['id']}"
    original=client.post(path+'/claim',json={'claimant_id':'agent'}).json()
    changed=deepcopy(state['document'])
    changed['goal']+=' 新确认版本的额外目标'
    updated=client.put(f"/api/plans/{changed['id']}",json={'document':changed,'expected_version':state['version']}).json()
    newer=confirm(client,updated)
    assert newer['version_id']!=state['version_id']
    retried=client.post(path+'/claim',json={'claimant_id':'agent'})
    assert retried.status_code==200 and retried.json()==original
    assert retried.json()['continuation']['version_id']==state['version_id']
