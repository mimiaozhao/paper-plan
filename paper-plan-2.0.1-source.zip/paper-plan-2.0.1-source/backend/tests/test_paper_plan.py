"""Behavioral contracts for automatic outlines and snapshot-bound execution."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys

import pytest

from backend.domain import compile_document, semantic_hash, validate_document
from backend.models import PlanDocument, ProgressRequest
from backend.storage import Store, VersionConflict, make_binding
from backend.tree_domain import leaf_ids, ordered_tree, parse_proposed_plan

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "scripts"))
from paper_hook import handle
import paper_hook

PLAN = """<proposed_plan>
# 验证研究假设

整理材料并验证假设。

## 1 整理材料
要求保留原始数据。
### 1.1 检查来源
核对每份输入。
### 1.2 整理证据
列出证据与不足。
## 2 验证假设
形成可复现的结论。
</proposed_plan>"""


@pytest.fixture
def store(tmp_path):
    value = Store(tmp_path / "paper.sqlite3")
    yield value
    value.close()


@pytest.fixture(autouse=True)
def no_live_history_in_unit_tests(monkeypatch):
    monkeypatch.setattr(paper_hook,"read_native_plan",lambda thread,turn:None)


def event(name, turn="t1", mode="plan", thread="thread-a", **extra):
    return {"hook_event_name":name,"session_id":thread,"turn_id":turn,"permission_mode":mode,**extra}


def create(store):
    handle(event("UserPromptSubmit",prompt="请规划验证实验"),store)
    handle(event("Stop",last_assistant_message=PLAN),store)
    return store.thread_plan("thread-a")


def ready(store):
    state=create(store)
    state=store.confirm(state.document.id,state.version)
    request=store.request_continuation("thread-a",state.version,state.version_id)
    return state,request


def claimed(store):
    state,request=ready(store)
    handle(event("UserPromptSubmit",turn="exec",mode="default",prompt=request.message),store)
    claim=store.claim_continuation("thread-a",request.id,"worker")
    return state,request,claim


def report(store,request,claim,node,status,**kwargs):
    return store.report_progress("thread-a",request.id,node,ProgressRequest(claim_token=claim["claim_token"],version_id=request.version_id,status=status,**kwargs))


def test_markdown_tree_preserves_body_numbers_and_parent_requirements():
    d=parse_proposed_plan(PLAN)
    rows=ordered_tree(d)
    assert [(n.title,number,depth) for n,number,depth in rows]==[("整理材料","1",0),("检查来源","1.1",1),("整理证据","1.2",1),("验证假设","2",0)]
    assert len(leaf_ids(d))==3
    prompt=compile_document(d)
    assert "要求保留原始数据" in prompt.text
    assert "父标题" in prompt.text
    assert prompt.text.index("1.1 检查来源") < prompt.text.index("1.2 整理证据")
    assert compile_document(d).text==prompt.text


@pytest.mark.parametrize("text",["请补充材料", "```xml\n"+PLAN+"\n```", "<proposed_plan>\n# 没有闭合"])
def test_ordinary_discussion_and_fenced_examples_are_not_plans(text):
    assert parse_proposed_plan(text) is None


def test_code_fences_do_not_create_headings():
    d=parse_proposed_plan(PLAN.replace("核对每份输入。","```python\n# a comment\n## not a heading\n```"))
    assert len(d.tree)==4
    assert "## not a heading" in d.tree[1].details


def test_semantic_hash_tracks_hierarchy_order_and_not_storage_order():
    d=parse_proposed_plan(PLAN);other=d.model_copy(deep=True)
    other.tree.reverse()
    assert semantic_hash(d)==semantic_hash(other)
    other.tree[1].order=8
    assert semantic_hash(d)!=semantic_hash(other)
    other=d.model_copy(deep=True);other.tree[1].parent_id=None;other.tree[1].order=3
    assert semantic_hash(d)!=semantic_hash(other)


def test_v1_snapshot_hash_stays_byte_compatible(document):
    data=document.model_dump(mode="json",exclude={"layout","tree"})
    for field in ("nodes","edges","constraints","assumptions"):
        data[field]=sorted(data[field],key=lambda x:x["id"])
    for node in data["nodes"]:node["locked_fields"]=sorted(set(node["locked_fields"]))
    old=hashlib.sha256(json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()).hexdigest()
    assert semantic_hash(document)==old


@pytest.mark.parametrize("mutation",["self","descendant","missing","duplicate_order","dependency_cycle","parent_dependency"])
def test_invalid_structure_rejected(mutation):
    d=parse_proposed_plan(PLAN)
    if mutation=="self":d.tree[0].parent_id=d.tree[0].id
    if mutation=="descendant":d.tree[0].parent_id=d.tree[1].id
    if mutation=="missing":d.tree[1].parent_id="unknown"
    if mutation=="duplicate_order":d.tree[2].order=d.tree[1].order
    if mutation=="dependency_cycle":d.tree[1].depends_on=[d.tree[2].id];d.tree[2].depends_on=[d.tree[1].id]
    if mutation=="parent_dependency":d.tree[3].depends_on=[d.tree[0].id]
    assert any(i.severity=="error" for i in validate_document(d))


def test_hook_ignores_discussion_and_subagents_even_with_default_permissions(store):
    context=handle(event("UserPromptSubmit",mode="default",prompt="普通工作"),store)
    assert "普通回复、澄清与讨论" in context["hookSpecificOutput"]["additionalContext"]
    handle(event("Stop",mode="default",last_assistant_message="你希望面向谁？"),store)
    assert store.thread_plan("thread-a") is None
    assert handle(event("UserPromptSubmit",agent_id="child",prompt="规划"),store)=={}
    assert handle(event("Stop",agent_id="child",last_assistant_message=PLAN),store)=={}
    output=handle(event("UserPromptSubmit",thread="thread-b",prompt="计划"),store)
    assert "thread-b" in output["hookSpecificOutput"]["additionalContext"]
    handle(event("Stop",thread="thread-b",last_assistant_message=PLAN),store)
    assert store.thread_plan("thread-b")
    assert store.thread_plan("thread-a") is None


def test_desktop_plan_with_default_permission_mode_is_captured(store):
    handle(event("UserPromptSubmit",mode="default",prompt="先问清楚，再给正式计划"),store)
    assert store.thread_plan("thread-a") is None
    handle(event("Stop",mode="default",last_assistant_message=PLAN),store)
    state=store.thread_plan("thread-a")
    assert state.document.title=="验证研究假设"
    handle(event("Stop",mode="default",last_assistant_message=PLAN),store)
    assert store.thread_plan("thread-a").version_id==state.version_id


@pytest.mark.parametrize("last_text",[None,"","已整理完整计划。"])
def test_native_plan_card_is_captured_when_final_message_omits_it(store,monkeypatch,last_text):
    calls=[]
    def read(thread,turn):
        calls.append((thread,turn))
        return {"item_id":"native-plan-item","text":PLAN.removeprefix('<proposed_plan>\n').removesuffix('\n</proposed_plan>')}
    monkeypatch.setattr(paper_hook,"read_native_plan",read)
    handle(event("UserPromptSubmit",mode="default",prompt="制定计划"),store)
    handle(event("Stop",mode="default",last_assistant_message=last_text),store)
    state=store.thread_plan("thread-a")
    assert state.document.title=="验证研究假设"
    assert calls==[("thread-a","t1")]
    assert store.capture_status("thread-a","t1")["source_item_id"]=="native-plan-item"
    assert store.capture_status("thread-a","t1")["source_kind"]=="native_plan"
    handle(event("Stop",mode="default",last_assistant_message=last_text),store)
    assert len(calls)==1 and store.thread_plan("thread-a").version_id==state.version_id
    assert store.continuations("thread-a")==[]


def test_native_capture_keeps_generation_conflict_as_candidate(store,monkeypatch):
    state=create(store)
    handle(event("UserPromptSubmit",turn="native",mode="default",prompt="修改计划"),store)
    changed=state.document.model_copy(deep=True);changed.title="用户的修改"
    store.save(changed.id,changed,state.version)
    monkeypatch.setattr(paper_hook,"read_native_plan",lambda *_:{"item_id":"p","text":PLAN})
    handle(event("Stop",turn="native",mode="default",last_assistant_message=None),store)
    assert store.thread_plan("thread-a").document.title=="用户的修改"
    assert len(store.candidates("thread-a"))==1


def test_reader_failure_still_finishes_incomplete_execution(store,monkeypatch):
    state,request,claim=claimed(store)
    def unavailable(*args):raise ValueError("只读接口不可用")
    monkeypatch.setattr(paper_hook,"read_native_plan",unavailable)
    with pytest.raises(ValueError,match="只读接口"):
        handle(event("Stop",turn="exec",mode="default",last_assistant_message=None),store)
    assert store.continuations("thread-a")[0].status=="interrupted"


def test_plain_reply_sets_ignored_diagnostic_without_a_plan(store):
    handle(event("UserPromptSubmit",mode="default",prompt="澄清问题"),store)
    handle(event("Stop",mode="default",last_assistant_message="请描述使用场景。"),store)
    assert store.thread_plan("thread-a") is None
    assert store.capture_status("thread-a","t1")["status"]=="ignored"


def test_default_permission_capture_preserves_edits_and_never_executes(store):
    state=create(store)
    handle(event("UserPromptSubmit",turn="desktop-plan",mode="default",prompt="新计划"),store)
    edited=state.document.model_copy(deep=True);edited.title="人工改名"
    store.save(edited.id,edited,state.version)
    handle(event("Stop",turn="desktop-plan",mode="default",last_assistant_message=PLAN),store)
    assert store.thread_plan("thread-a").document.title=="人工改名"
    assert len(store.candidates("thread-a"))==1
    assert store.continuations("thread-a")==[]


def test_stop_cannot_capture_for_missing_or_stale_turn(store):
    handle(event("Stop",mode="default",last_assistant_message=PLAN),store)
    assert store.thread_plan("thread-a") is None
    handle(event("UserPromptSubmit",mode="default",prompt="讨论"),store)
    handle(event("UserPromptSubmit",turn="t2",mode="default",prompt="新讨论"),store)
    handle(event("Stop",mode="default",last_assistant_message=PLAN),store)
    assert store.thread_plan("thread-a") is None


def test_explicit_recovery_is_candidate_and_keeps_runtime_and_snapshot(store):
    state,request=ready(store)
    before=store.runtime("thread-a")
    result=store.recover_plan_candidate("thread-a","visible-final",PLAN,state.version)
    assert result["status"]=="candidate"
    assert store.thread_plan("thread-a").version_id==state.version_id
    assert store.runtime("thread-a")==before
    assert store.continuations("thread-a")[0].status=="pending"
    assert "恢复" in store.candidates("thread-a")[0]["reason"]
    assert store.recover_plan_candidate("thread-a","visible-final",PLAN,state.version)["duplicate"]
    with pytest.raises(VersionConflict):
        store.recover_plan_candidate("thread-a","visible-final",PLAN.replace("验证研究假设","另一个计划"),state.version)
    with pytest.raises(VersionConflict):
        store.resolve_candidate("thread-a",result["turn_id"],state.version,True)
    store.cancel_continuation("thread-a",request.id)
    store.resolve_candidate("thread-a",result["turn_id"],state.version,True)
    assert not store.thread_plan("thread-a").confirmed


def test_duplicate_stop_does_not_generate_another_version(store):
    state=create(store)
    handle(event("Stop",last_assistant_message=PLAN),store)
    assert store.thread_plan("thread-a").version_id==state.version_id
    assert len(store.versions(state.document.id))==1


def test_generation_conflict_is_saved_as_candidate(store):
    state=create(store)
    handle(event("UserPromptSubmit",turn="t2",prompt="调整方案"),store)
    changed=state.document.model_copy(deep=True);changed.tree[0].title="用户的标题"
    changed_state=store.save(changed.id,changed,state.version)
    handle(event("Stop",turn="t2",last_assistant_message=PLAN.replace("整理材料","新的方案")),store)
    assert store.thread_plan("thread-a").document.tree[0].title=="用户的标题"
    candidate=store.candidates("thread-a")[0]
    assert candidate["document"]["tree"][0]["title"]=="新的方案"
    with pytest.raises(VersionConflict):store.resolve_candidate("thread-a","t2",state.version,True)
    store.resolve_candidate("thread-a","t2",changed_state.version,True)
    assert not store.candidates("thread-a")


def test_exact_snapshot_mode_guard_and_edit_lock(store):
    state,request=ready(store)
    with pytest.raises(VersionConflict,match="执行模式"):store.claim_continuation("thread-a",request.id,"worker")
    changed=state.document.model_copy(deep=True);changed.tree[0].title="不能修改"
    with pytest.raises(VersionConflict,match="锁定"):store.save(changed.id,changed,state.version)
    handle(event("UserPromptSubmit",turn="exec",mode="default",prompt=request.message),store)
    claim=store.claim_continuation("thread-a",request.id,"worker")
    assert claim["document"]==state.document
    assert claim["compiled"].semantic_hash==state.semantic_hash
    assert store.claim_continuation("thread-a",request.id,"worker")["claim_token"]==claim["claim_token"]
    with pytest.raises(VersionConflict):store.claim_continuation("thread-a",request.id,"other")
    with pytest.raises(VersionConflict,match="锁定"):store.save(changed.id,changed,state.version)


def test_plan_mode_delivery_can_be_retried_after_switch(store):
    state,request=ready(store)
    store.begin_dispatch("thread-a",request.id)
    store.finish_dispatch("thread-a",request.id,"queued",None)
    response=handle(event("UserPromptSubmit",turn="still-plan",prompt=request.message),store)
    assert "不要领取" in response["hookSpecificOutput"]["additionalContext"]
    item=store.continuations("thread-a")[0]
    assert item.waiting_for_mode and item.status=="pending" and item.delivery_status=="not_sent"
    assert store.begin_dispatch("thread-a",request.id)[1] is True
    handle(event("UserPromptSubmit",turn="exec",mode="default",prompt=request.message),store)
    assert store.claim_continuation("thread-a",request.id,"worker")["continuation"].status=="running"


def test_progress_order_dependencies_evidence_and_completion(store):
    state,request,claim=claimed(store)
    leaves=leaf_ids(state.document)
    with pytest.raises(VersionConflict,match="调序"):report(store,request,claim,leaves[-1],"running")
    report(store,request,claim,leaves[-1],"running",adjustment_reason="先验证资料可用性，减少返工")
    with pytest.raises(VersionConflict,match="依据"):report(store,request,claim,leaves[-1],"completed",output="结果")
    report(store,request,claim,leaves[-1],"completed",output="已验证",evidence="检查记录")
    retry=report(store,request,claim,leaves[-1],"completed",output="已验证",evidence="检查记录")
    assert retry.progress[leaves[-1]].status=="completed"
    with pytest.raises(VersionConflict,match="没有实际完成"):store.complete_continuation("thread-a",request.id,claim["claim_token"],"completed","完成",None)
    for leaf in leaves[:-1]:
        report(store,request,claim,leaf,"running")
        report(store,request,claim,leaf,"completed",output="实际产物",evidence="通过验证")
    completed=store.complete_continuation("thread-a",request.id,claim["claim_token"],"completed","目录结果",None)
    assert completed.status=="completed"
    assert completed.progress[leaves[-1]].adjustment_reason
    changed=state.document.model_copy(deep=True);changed.title="现在可编辑"
    assert store.save(changed.id,changed,state.version).document.title=="现在可编辑"


def test_progress_requires_snapshot_token_and_leaf_identity(store):
    state,request,claim=claimed(store)
    with pytest.raises(VersionConflict):report(store,request,{**claim,"claim_token":"wrong"},leaf_ids(state.document)[0],"running")
    with pytest.raises(VersionConflict):report(store,request,claim,state.document.tree[0].id,"running")
    with pytest.raises(VersionConflict):store.report_progress("thread-a",request.id,leaf_ids(state.document)[0],ProgressRequest(claim_token=claim["claim_token"],version_id="wrong",status="running"))


def test_stop_interrupt_and_cancel_unlock_without_fabricating_completion(store):
    state,request,claim=claimed(store)
    report(store,request,claim,leaf_ids(state.document)[0],"running")
    handle(event("Interrupt",turn="other",mode="default"),store)
    assert store.continuations("thread-a")[0].status=="running"
    handle(event("Interrupt",turn="exec",mode="default"),store)
    item=store.continuations("thread-a")[0]
    assert item.status=="interrupted"
    assert item.progress[leaf_ids(state.document)[0]].status=="interrupted"
    next_request=store.request_continuation("thread-a",state.version,state.version_id)
    store.cancel_continuation("thread-a",next_request.id)
    with pytest.raises(VersionConflict):store.claim_continuation("thread-a",next_request.id,"worker")
    store.save(state.document.id,state.document,state.version)


def test_tree_api_enforces_locks_and_scopes(client):
    store=client.app.state.store
    state,request=ready(store)
    view=client.get('/api/threads/thread-a/outline').json()
    assert view['state']['document']['schema_version']==2
    assert client.get('/api/threads/thread-b/outline').json()['state'] is None
    response=client.put('/api/plans/'+state.document.id,json={'document':state.document.model_dump(),'expected_version':state.version})
    assert response.status_code==409
    assert client.post('/api/threads/thread-b/continuations/'+request.id+'/cancel',json={}).status_code==409
    assert client.post('/api/threads/thread-a/continuations/'+request.id+'/cancel',json={},headers={'Origin':'https://evil.example'}).status_code==403
    assert client.post('/api/threads/thread-a/continuations/'+request.id+'/cancel',json={}).status_code==200


def test_unknown_mode_cannot_claim_even_with_a_confirmed_plan(store):
    state,request=ready(store)
    handle(event('UserPromptSubmit',turn='unknown',mode='future-mode',prompt=request.message),store)
    with pytest.raises(VersionConflict,match='可信'):store.claim_continuation('thread-a',request.id,'worker')


def test_old_or_unrelated_execution_mode_cannot_authorize_a_new_claim(store):
    state,request=ready(store)
    handle(event('UserPromptSubmit',turn='unrelated',mode='default',prompt='查看状态'),store)
    with pytest.raises(VersionConflict,match='可信'):store.claim_continuation('thread-a',request.id,'worker')
    handle(event('UserPromptSubmit',turn='fresh-execution',mode='default',prompt=request.message),store)
    assert store.claim_continuation('thread-a',request.id,'worker')['continuation'].status=='running'


def test_missing_hook_claim_is_truthfully_retryable_without_starting_execution(client):
    store=client.app.state.store
    state,request=ready(store)
    store.begin_dispatch('thread-a',request.id)
    store.finish_dispatch('thread-a',request.id,'queued',None)
    handle(event('UserPromptSubmit',turn='unrelated',mode='default',prompt='查看状态'),store)
    response=client.post(f'/api/threads/thread-a/continuations/{request.id}/claim',json={'claimant_id':'worker'})
    assert response.status_code==409
    assert response.json()['detail']['code']=='hook_event_missing'
    item=store.continuations('thread-a')[0]
    assert item.status=='pending' and item.waiting_for_context and not item.waiting_for_mode
    assert item.delivery_status=='not_sent' and item.progress=={}
    assert store.thread_plan('thread-a').version_id==state.version_id
    assert store.begin_dispatch('thread-a',request.id)[1] is True
    assert store.begin_dispatch('thread-a',request.id)[1] is False
    handle(event('UserPromptSubmit',turn='fresh',mode='default',prompt=request.message),store)
    claim=client.post(f'/api/threads/thread-a/continuations/{request.id}/claim',json={'claimant_id':'worker'})
    assert claim.status_code==200
    assert claim.json()['continuation']['status']=='running'
    assert not claim.json()['continuation']['waiting_for_context']
    assert claim.json()['document']==state.document.model_dump()


def test_plan_mode_failure_is_distinct_from_missing_hook(client):
    store=client.app.state.store
    state,request=ready(store)
    response=client.post(f'/api/threads/thread-a/continuations/{request.id}/claim',json={'claimant_id':'worker'})
    assert response.status_code==409
    assert response.json()['detail']['code']=='plan_mode'
    item=store.continuations('thread-a')[0]
    assert item.waiting_for_mode and not item.waiting_for_context and item.status=='pending'
