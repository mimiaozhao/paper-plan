"""Same-chat question-first revision requests, separate from execution."""
from pathlib import Path
import sys
import pytest
from backend.storage import Store,VersionConflict,make_binding
from backend.tree_domain import parse_proposed_plan

sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'scripts'))
import paper_hook

PLAN='<proposed_plan>\n# 用户目录\n## 梳理研究问题\n保留用户的具体要求。\n## 核对证据\n列出依据。\n</proposed_plan>'

@pytest.fixture(autouse=True)
def isolated_reader(monkeypatch):
    monkeypatch.setattr(paper_hook,'read_native_plan',lambda *_:None)

@pytest.fixture
def store(tmp_path):
    s=Store(tmp_path/'revisions.sqlite3')
    yield s
    s.close()

def seed(s,thread='t'):
    d=parse_proposed_plan(PLAN)
    return s.create_bound(d,make_binding(thread,'讨论','用户调整后的目录',[]))

def event(name,turn,prompt='',text=None):
    return {'hook_event_name':name,'session_id':'t','turn_id':turn,'permission_mode':'default','prompt':prompt,'last_assistant_message':text}

def begin(s,state,notes='检查结构'):
    item=s.request_revision('t',state.version,state.version_id,notes)
    paper_hook.handle(event('UserPromptSubmit','ask',item.message),s)
    return item

def test_revision_uses_unconfirmed_immutable_snapshot_and_does_not_lock_edits(store):
    state=seed(store)
    item=store.request_revision('t',state.version,state.version_id,'我希望先讨论')
    assert not state.confirmed and store.continuations('t')==[]
    changed=state.document.model_copy(deep=True);changed.tree[0].details='新的人工补充'
    store.save(changed.id,changed,state.version)
    result=store.revision_snapshot('t',item.id)
    assert result['document']==state.document and result['draft_changed']
    assert result['revision'].notes=='我希望先讨论'
    assert '先检查宿主协作模式' in item.message and '等待我回答' in item.message
    assert 'continuation_id=' not in item.message

def test_double_click_is_idempotent_and_delivery_is_serialized(store):
    state=seed(store)
    first=store.request_revision('t',state.version,state.version_id,'重点')
    assert store.request_revision('t',state.version,state.version_id,'重点').id==first.id
    assert store.begin_revision_dispatch('t',first.id)[1]
    assert not store.begin_revision_dispatch('t',first.id)[1]
    store.finish_revision_dispatch('t',first.id,'queued',None)
    assert not store.begin_revision_dispatch('t',first.id)[1]
    assert store.continuations('t')==[] and store.thread_plan('t').version==1

def test_stale_and_foreign_snapshots_are_rejected(store):
    state=seed(store)
    with pytest.raises(VersionConflict):store.request_revision('t',2,state.version_id)
    with pytest.raises(VersionConflict):store.request_revision('t',1,'different')
    item=store.request_revision('t',1,state.version_id)
    with pytest.raises(VersionConflict):store.revision_snapshot('other',item.id)
    changed=state.document.model_copy(deep=True);changed.title='已修改'
    store.save(changed.id,changed,1)
    with pytest.raises(VersionConflict):store.begin_revision_dispatch('t',item.id)

def test_discussion_replies_never_make_plan_versions(store):
    state=seed(store);item=begin(store,state)
    output=paper_hook.handle(event('UserPromptSubmit','answer','面向首次使用者'),store)
    assert item.id in output['hookSpecificOutput']['additionalContext']
    paper_hook.handle(event('Stop','answer',text='需要包含安装步骤吗？'),store)
    assert store.thread_plan('t').version==1
    assert store.active_revision('t').status=='discussing'
    assert store.continuations('t')==[]

def test_multi_turn_revision_protects_edits_since_initial_request(store):
    state=seed(store);item=begin(store,state)
    paper_hook.handle(event('Stop','ask',text='先确认用途？'),store)
    changed=state.document.model_copy(deep=True);changed.tree[0].title='用户后来修改'
    store.save(changed.id,changed,1)
    paper_hook.handle(event('UserPromptSubmit','answer','用途已明确'),store)
    assert store.capture_status('t','answer')['base_version']==1
    paper_hook.handle(event('Stop','answer',text=PLAN.replace('用户目录','梳理后的目录')),store)
    assert store.thread_plan('t').document.tree[0].title=='用户后来修改'
    assert store.revisions('t')[0].status=='candidate'
    assert store.active_revision('t') is None
    candidate=store.candidates('t')[0]
    store.resolve_candidate('t',candidate['turn_id'],2,True)
    assert store.revisions('t')[0].status=='completed'
    assert store.thread_plan('t').version==3 and not store.thread_plan('t').confirmed

def test_final_plan_without_intervening_edits_requires_new_confirmation(store):
    state=seed(store);store.confirm(state.document.id,1);item=begin(store,state)
    paper_hook.handle(event('Stop','ask',text='请明确重点'),store)
    paper_hook.handle(event('UserPromptSubmit','answer','补充验证'),store)
    paper_hook.handle(event('Stop','answer',text=PLAN.replace('核对证据','验证结论')),store)
    revised=store.thread_plan('t')
    assert revised.version==2 and not revised.confirmed
    assert store.revisions('t')[0].result_version_id==revised.version_id
    assert store.snapshot(state.document.id,state.version_id)['document']==state.document
    assert store.continuations('t')==[]

def test_cancelled_or_superseded_request_cannot_overwrite_later_plan(store):
    state=seed(store);first=begin(store,state)
    second=store.request_revision('t',1,state.version_id,'新的重点')
    with pytest.raises(VersionConflict):store.revision_snapshot('t',first.id)
    paper_hook.handle(event('Stop','ask',text=PLAN),store)
    assert store.thread_plan('t').version==1
    output=paper_hook.handle(event('UserPromptSubmit','stale',first.message),store)
    assert '已取消或被替代' in output['hookSpecificOutput']['additionalContext']
    paper_hook.handle(event('Stop','stale',text=PLAN),store)
    assert store.thread_plan('t').version==1
    paper_hook.handle(event('UserPromptSubmit','second',second.message),store)
    store.cancel_revision('t',second.id)
    paper_hook.handle(event('Stop','second',text=PLAN),store)
    assert store.thread_plan('t').version==1 and store.active_revision('t') is None

def test_revision_and_execution_requests_do_not_overlap(store):
    state=seed(store);state=store.confirm(state.document.id,1)
    item=store.request_revision('t',1,state.version_id)
    with pytest.raises(VersionConflict,match='再修改'):store.request_continuation('t',1,state.version_id)
    store.cancel_revision('t',item.id)
    request=store.request_continuation('t',1,state.version_id)
    with pytest.raises(VersionConflict,match='锁定'):store.request_revision('t',1,state.version_id)
    assert request.status=='pending'

def test_api_delivery_failure_retry_and_origin_guard(client,monkeypatch):
    state=seed(client.app.state.store)
    payload={'expected_version':1,'version_id':state.version_id,'notes':'先问问题'}
    assert client.post('/api/threads/t/revisions',json=payload,headers={'Origin':'https://evil.example'}).status_code==403
    response=client.post('/api/threads/t/revisions',json=payload)
    assert response.status_code==200
    item=response.json();calls=[]
    def send(thread,message):
        calls.append((thread,message))
        return {'status':'manual','error':'QA 投递失败'} if len(calls)==1 else {'status':'queued','error':None}
    monkeypatch.setattr('backend.dispatcher.dispatch_to_codex',send)
    path=f"/api/threads/t/revisions/{item['id']}"
    assert client.get(path).json()['document']==state.document.model_dump()
    assert client.post(path+'/dispatch',json={}).json()['delivery_status']=='manual'
    assert client.post(path+'/dispatch',json={}).json()['delivery_status']=='queued'
    assert client.post(path+'/dispatch',json={}).json()['delivery_status']=='queued'
    assert len(calls)==2 and all(call[0]=='t' for call in calls)
    assert client.get('/api/threads/t/continuations').json()['continuations']==[]
    assert client.post(path+'/cancel',json={}).json()['status']=='cancelled'
    assert client.get(path).status_code==409
    assert client.post(path+'/dispatch',json={}).status_code==409
