param([switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$runtimePython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $runtimePython)) { throw 'Run Install.cmd first.' }
$env:PYTHONUTF8 = '1'
$env:PLAN_PANEL_API_URL = 'http://127.0.0.1:8765'
& $runtimePython -c "import sys; sys.path.insert(0,'scripts'); from service_runtime import ensure_service; ensure_service()"
if ($LASTEXITCODE -ne 0) { throw 'The plan panel could not be started.' }
if (-not $NoBrowser) { & $runtimePython -m webbrowser 'http://127.0.0.1:8765' }
Write-Host 'Plan panel is running at http://127.0.0.1:8765'
