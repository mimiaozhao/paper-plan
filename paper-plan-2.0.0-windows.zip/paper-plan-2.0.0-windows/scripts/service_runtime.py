"""Start only this project's local service; no installs or browser automation."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from urllib.request import build_opener, ProxyHandler
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]


def ensure_service() -> None:
    if os.environ.get("PAPER_PLAN_NO_AUTOSTART") == "1":
        return
    from bridge_api import api_base
    base = api_base()
    opener = build_opener(ProxyHandler({}))
    data_dir = ROOT / "data"
    data_dir.mkdir(exist_ok=True)
    def ready():
        try:
            with opener.open(base + "/api/health", timeout=.4) as response:
                data = json.load(response)
        except (OSError, ValueError):
            return False
        if data.get("service") != "paper-plan" or data.get("version") != "2.0.0" or data.get("bridge_protocol") != 3 or data.get("project_root") != str(ROOT) or not isinstance(data.get("pid"), int):
            raise RuntimeError("计划面板端口被旧服务占用，请在项目中执行 stop.ps1，然后重试。")
        if data.get("execution_context") == "restricted" and os.environ.get("PLAN_PANEL_DISPATCH", "1") != "0":
            raise RuntimeError("现有计划服务运行在隔离账户，无法向桌面对话投递。请以桌面用户重启计划服务。")
        (data_dir / "app.pid").write_text(str(data["pid"]), encoding="ascii")
        return True
    if ready():
        return
    from backend.runtime_context import require_dispatch_account
    require_dispatch_account()
    with (data_dir / "paper-service.log").open("ab") as log:
        process = subprocess.Popen([sys.executable, str(ROOT / "scripts" / "run_server.py"), "--port", str(urlparse(base).port or 8765)], cwd=ROOT, stdin=subprocess.DEVNULL, stdout=log, stderr=log, env={**os.environ,"PYTHONUTF8":"1"}, creationflags=(subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP) if os.name == "nt" else 0, start_new_session=os.name != "nt")
    for _ in range(25):
        if ready():
            return
        if process.poll() is not None:
            break
        time.sleep(.2)
    raise RuntimeError("论文式计划服务启动失败；请查看 data/paper-service.log。")
