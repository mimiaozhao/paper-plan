"""Identifiable service entrypoint (Windows venv launchers create a second PID)."""
import argparse
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

if __name__=='__main__':
    from backend.runtime_context import require_dispatch_account
    require_dispatch_account()
    import uvicorn
    parser=argparse.ArgumentParser()
    parser.add_argument('--port',type=int,default=8765)
    args=parser.parse_args()
    if not 1024<=args.port<=65535:parser.error('port must be between 1024 and 65535')
    uvicorn.run('backend.app:app',host='127.0.0.1',port=args.port)
