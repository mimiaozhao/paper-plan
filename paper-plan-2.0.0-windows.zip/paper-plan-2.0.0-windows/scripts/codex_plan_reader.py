"""Read one completed native plan through the documented local app-server API.

This client never starts/resumes a conversation, invokes a model, lists threads,
or reads transcript files. Every history request is scoped to the hook's exact
thread and turn. Non-plan items are discarded, not persisted or logged.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import queue
import re
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from backend.providers import codex_executable


class PlanReadError(ValueError):
    pass


class ReadOnlyAppServer:
    def __init__(self, timeout: float = 8):
        executable = codex_executable()
        if not executable:
            raise PlanReadError("找不到用于读取正式计划的 Codex CLI。")
        self.deadline = time.monotonic() + timeout
        self.process = subprocess.Popen(
            [executable, "app-server", "--stdio"], stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            text=True, encoding="utf-8", errors="strict", cwd=ROOT,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
        self.messages = queue.Queue()
        self.sequence = 0
        threading.Thread(target=self._read, daemon=True).start()

    def _read(self):
        try:
            while True:
                line = self.process.stdout.readline(8 * 1024 * 1024 + 1)
                if not line:
                    break
                if len(line) > 8 * 1024 * 1024:
                    raise PlanReadError("计划读取响应超过限制。")
                self.messages.put(json.loads(line))
        except Exception as error:
            self.messages.put(error)
        finally:
            self.messages.put(None)

    def call(self, method: str, params: dict) -> dict:
        if method not in {"initialize", "thread/items/list"}:
            raise PlanReadError("计划读取器只允许初始化及按轮次只读查询。")
        self.sequence += 1
        request_id = self.sequence
        self.process.stdin.write(json.dumps({"id": request_id, "method": method, "params": params}) + "\n")
        self.process.stdin.flush()
        while True:
            if time.monotonic() >= self.deadline:
                raise PlanReadError("读取本轮正式计划超时；原计划仍保留在聊天中。")
            try:
                response = self.messages.get(timeout=max(.01, self.deadline - time.monotonic()))
            except queue.Empty as error:
                raise PlanReadError("读取本轮正式计划超时；原计划仍保留在聊天中。") from error
            if response is None or isinstance(response, Exception):
                raise PlanReadError("本轮计划读取连接已结束。")
            if response.get("id") != request_id:
                continue
            if "error" in response:
                code = response["error"].get("code", "unknown")
                raise PlanReadError(f"宿主无法读取本轮正式计划（协议错误 {code}）。")
            if method == "initialize":
                self.process.stdin.write(json.dumps({"method": "initialized", "params": {}}) + "\n")
                self.process.stdin.flush()
            return response.get("result", {})

    def close(self):
        try:
            self.process.stdin.close()
            self.process.wait(timeout=.5)
        except (OSError, subprocess.TimeoutExpired):
            self.process.terminate()
            try:
                self.process.wait(timeout=.5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=1)


def read_native_plan(thread_id: str, turn_id: str, *, client_factory=ReadOnlyAppServer) -> dict | None:
    if any(not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", value) for value in (thread_id, turn_id)):
        raise PlanReadError("读取正式计划需要精确的对话和轮次标识。")
    client = client_factory()
    try:
        client.call("initialize", {"clientInfo": {"name": "paper_plan_reader", "title": "Paper Plan", "version": "2.0.0"}, "capabilities": {"experimentalApi": True}})
        cursor = None
        for _ in range(4):
            params = {"threadId": thread_id, "turnId": turn_id, "sortDirection": "desc", "limit": 20}
            if cursor:
                params["cursor"] = cursor
            result = client.call("thread/items/list", params)
            for entry in result.get("data", []):
                if entry.get("turnId") != turn_id:
                    raise PlanReadError("宿主返回了其他轮次的数据，已拒绝同步。")
                item = entry.get("item", {})
                if item.get("type") == "plan":
                    text = item.get("text")
                    if not isinstance(text, str) or not text.strip():
                        raise PlanReadError("本轮正式计划卡片没有正文。")
                    return {"item_id": item.get("id"), "text": text}
            cursor = result.get("nextCursor")
            if not cursor:
                return None
        raise PlanReadError("本轮末尾未找到正式计划；读取已达到限定范围。")
    finally:
        client.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--thread", required=True)
    parser.add_argument("--turn", required=True)
    args = parser.parse_args()
    value = read_native_plan(args.thread, args.turn)
    print(json.dumps({"found": value is not None, "item_id": value.get("item_id") if value else None, "text_length": len(value["text"]) if value else 0}, ensure_ascii=False))
