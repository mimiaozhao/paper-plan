"""Real MCP stdio server for per-conversation planning (MCP Python SDK 2.x)."""
from __future__ import annotations
import sys
from collections.abc import Mapping
from urllib.parse import quote
from pathlib import Path
from typing import Literal

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from mcp.server.mcpserver import Context, MCPServer
from mcp.types import ToolAnnotations
from mcp.server.mcpserver.exceptions import ToolError
import logging
logging.getLogger("httpx").setLevel(logging.WARNING)
from backend.models import PlanDocument
import bridge_api as bridge

server = MCPServer(
    "plan-panel", version="3.0.0", log_level="WARNING",
    instructions="Use these tools for a plan belonging to one explicit Codex conversation. Extract only relevant task requirements and user-confirmed decisions from your visible context; never request whole chat logs. Obtain the exact current thread ID from trusted host metadata. Create or update a draft, then open panel_url in the current conversation's right browser panel. On an explicit continuation, claim that exact confirmed version, execute in the same conversation, and report actual results. Never start an independent codex exec session or fabricate execution status. A stale version or protected field conflict must be resolved with the current user, not overwritten.",
)
READ = ToolAnnotations(read_only_hint=True, destructive_hint=False, open_world_hint=False, idempotent_hint=True)
WRITE = ToolAnnotations(read_only_hint=False, destructive_hint=False, open_world_hint=False)
UPDATE = ToolAnnotations(read_only_hint=False, destructive_hint=True, open_world_hint=False)


def invoke(function, *args):
    try:
        return function(*args)
    except ValueError as error:
        raise ToolError(str(error)) from error


@server.tool(annotations=READ)
def get_thread_plan(thread_id: str) -> dict:
    """Read the draft and task-specific source metadata for one explicitly identified conversation; returns its panel URL."""
    return invoke(bridge.get_thread_plan, thread_id)


@server.tool(annotations=READ)
def get_plan_panel_url(thread_id: str, ctx: Context) -> dict:
    """Get the current thread's outline panel URL even before a plan exists. Open it in the same chat's right browser panel."""
    import json
    from service_runtime import ensure_service
    try:
        ensure_service()
    except RuntimeError as error:
        raise ToolError(str(error)) from error
    metadata = ctx.request_context.meta
    values = dict(metadata) if isinstance(metadata, Mapping) else metadata.model_dump(exclude_none=True) if metadata and hasattr(metadata, "model_dump") else {}
    nested = values.get("x-codex-turn-metadata", {})
    if isinstance(nested, str):
        try:
            nested = json.loads(nested)
        except ValueError:
            nested = {}
    if not isinstance(nested, dict):
        nested = {}
    allowed = {"thread_id", "threadId", "turn_id", "turnId", "permission_mode", "collaboration_mode", "collaborationMode", "mode"}
    context = {key: value for key, value in nested.items() if key in allowed and isinstance(value, (str, bool, int))}
    return bridge.with_panel({"transport_context": context, "metadata_keys": sorted(values), "context_keys": sorted(nested)}, thread_id)


@server.tool(annotations=WRITE)
def report_node_progress(thread_id: str, continuation_id: str, version_id: str, claim_token: str, node_id: str, status: Literal["running", "completed", "failed", "interrupted"], output: str = "", evidence: str = "", adjustment_reason: str = "") -> dict:
    """Report one leaf task's actual progress on the claimed snapshot. Completion requires output and verification evidence; out-of-order starts require an explained adjustment_reason."""
    return invoke(bridge.request, "POST", bridge.thread_path(thread_id) + "/continuations/" + quote(continuation_id,safe="") + "/nodes/" + quote(node_id,safe=""), {"version_id":version_id,"claim_token":claim_token,"status":status,"output":output,"evidence":evidence,"adjustment_reason":adjustment_reason})


@server.tool(annotations=WRITE)
def create_thread_plan(thread_id: str, thread_title: str, task_brief: str, confirmed_decisions: list[str], document: PlanDocument) -> dict:
    """Create the first editable structured plan for this conversation from relevant requirements you extracted; never pass raw transcripts. Existing plans are not overwritten."""
    return invoke(bridge.create_thread_plan, thread_id, {"document": document.model_dump(), "thread_title": thread_title, "task_brief": task_brief, "confirmed_decisions": confirmed_decisions})


@server.tool(annotations=UPDATE)
def update_thread_plan(thread_id: str, expected_version: int, thread_title: str, task_brief: str, confirmed_decisions: list[str], document: PlanDocument) -> dict:
    """Update this conversation's draft at the exact expected version, respecting user-locked fields and constraints. Business edits invalidate confirmation."""
    return invoke(bridge.update_thread_plan, thread_id, {"document": document.model_dump(), "expected_version": expected_version, "thread_title": thread_title, "task_brief": task_brief, "confirmed_decisions": confirmed_decisions})


@server.tool(annotations=READ)
def get_confirmed_thread_plan(thread_id: str, version_id: str | None = None) -> dict:
    """Read the immutable current confirmed document and exact compiled prompt; unconfirmed or stale versions fail. This does not start execution."""
    return invoke(bridge.get_confirmed_thread_plan, thread_id, version_id)


@server.tool(annotations=READ)
def get_plan_revision(thread_id: str, revision_id: str) -> dict:
    """Read the immutable user-edited snapshot and notes for an explicit revision request. Ask substantive questions in the host's Plan mode before drafting a replacement; never execute this snapshot. Cancelled/superseded requests fail."""
    return invoke(bridge.get_plan_revision,thread_id,revision_id)


@server.tool(annotations=READ)
def list_thread_continuations(thread_id: str) -> dict:
    """Read pending, running and finished continuation requests for this conversation only."""
    return invoke(bridge.list_thread_continuations, thread_id)


@server.tool(annotations=WRITE)
def request_thread_continuation(thread_id: str, expected_version: int, version_id: str) -> dict:
    """Create an idempotent continuation request for an exact confirmed version after user authorization; no independent model call or message delivery."""
    return invoke(bridge.request_thread_continuation, thread_id, expected_version, version_id)


@server.tool(annotations=WRITE)
def dispatch_thread_continuation(thread_id: str, continuation_id: str) -> dict:
    """On the user's explicit continue action, queue this pending confirmed request as a message to its original local Codex chat. Delivery is not execution; failures return a manual path."""
    return invoke(bridge.dispatch_thread_continuation, thread_id, continuation_id)


@server.tool(annotations=WRITE)
def claim_thread_continuation(thread_id: str, continuation_id: str, claimant_id: str) -> dict:
    """Atomically claim an authorized request and receive its immutable document, prompt and completion token. Use a stable claimant identity for retries; stale requests fail."""
    return invoke(bridge.claim_thread_continuation, thread_id, continuation_id, claimant_id)


@server.tool(annotations=WRITE)
def complete_thread_continuation(thread_id: str, continuation_id: str, claim_token: str, status: Literal["completed", "failed"], output: str, error: str | None = None) -> dict:
    """Report the actual outcome after executing the claimed plan in its original conversation. Only the matching claim token may complete it; never claim unperformed work."""
    return invoke(bridge.complete_thread_continuation, thread_id, continuation_id, {"claim_token": claim_token, "status": status, "output": output, "error": error})


@server.resource("plan-panel://schema/plan-document")
def plan_document_schema() -> str:
    """Backend-authoritative structure for creating a plan."""
    import json
    return json.dumps(PlanDocument.model_json_schema(), ensure_ascii=False)


if __name__ == "__main__":
    from service_runtime import ensure_service
    ensure_service()
    server.run(transport="stdio")
