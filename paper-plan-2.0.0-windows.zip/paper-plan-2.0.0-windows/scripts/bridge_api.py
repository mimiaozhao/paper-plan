"""Loopback-only HTTP client shared by the MCP tools and skill fallback."""
from __future__ import annotations
import os
from urllib.parse import quote, urlparse
import httpx


def api_base() -> str:
    value = os.environ.get("PLAN_PANEL_API_URL", "http://127.0.0.1:8765").rstrip("/")
    parsed = urlparse(value)
    if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost", "::1"} or parsed.username or parsed.password or parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
        raise ValueError("PLAN_PANEL_API_URL 必须是本机 loopback HTTP 地址。")
    return value


def request(method: str, path: str, payload: dict | None = None) -> dict:
    try:
        with httpx.Client(timeout=25, trust_env=False) as client:
            try:
                response = client.request(method, api_base() + "/api" + path, json=payload)
            except httpx.ConnectError:
                # A refused connection sent no request. Recover the local viewer
                # once, but never retry a read timeout or an ambiguous mutation.
                from service_runtime import ensure_service
                ensure_service()
                response = client.request(method, api_base() + "/api" + path, json=payload)
    except RuntimeError as error:
        raise ValueError(str(error)) from error
    except httpx.HTTPError as error:
        raise ValueError("计划面板服务不可用。请启动 visual-plan-editor/start.cmd 后重试。") from error
    if not response.is_success:
        detail = response.json().get("detail", "请求失败")
        message = detail if isinstance(detail, str) else detail.get("message", "输入无效") if isinstance(detail, dict) else "输入无效"
        raise ValueError(f"计划面板 HTTP {response.status_code}：{message}")
    return response.json()


def thread_path(thread_id: str) -> str:
    return "/threads/" + quote(thread_id, safe="")


def with_panel(value: dict, thread_id: str) -> dict:
    return {**value, "panel_url": api_base() + "/?thread=" + quote(thread_id, safe="")}


def get_thread_plan(thread_id: str) -> dict:
    return with_panel(request("GET", thread_path(thread_id) + "/plan"), thread_id)


def create_thread_plan(thread_id: str, payload: dict) -> dict:
    return with_panel(request("POST", thread_path(thread_id) + "/plan", payload), thread_id)


def update_thread_plan(thread_id: str, payload: dict) -> dict:
    return with_panel(request("PUT", thread_path(thread_id) + "/plan", payload), thread_id)


def get_confirmed_thread_plan(thread_id: str, version_id: str | None = None) -> dict:
    suffix = "?version_id=" + quote(version_id, safe="") if version_id else ""
    return request("GET", thread_path(thread_id) + "/confirmed-plan" + suffix)


def list_thread_continuations(thread_id: str) -> dict:
    return request("GET", thread_path(thread_id) + "/continuations")


def get_plan_revision(thread_id: str, revision_id: str) -> dict:
    return request("GET",thread_path(thread_id)+"/revisions/"+quote(revision_id,safe=""))


def request_thread_continuation(thread_id: str, expected_version: int, version_id: str) -> dict:
    return request("POST", thread_path(thread_id) + "/continuations", {"expected_version": expected_version, "version_id": version_id})


def claim_thread_continuation(thread_id: str, continuation_id: str, claimant_id: str) -> dict:
    return request("POST", thread_path(thread_id) + "/continuations/" + quote(continuation_id, safe="") + "/claim", {"claimant_id": claimant_id})


def complete_thread_continuation(thread_id: str, continuation_id: str, payload: dict) -> dict:
    return request("POST", thread_path(thread_id) + "/continuations/" + quote(continuation_id, safe="") + "/complete", payload)


def dispatch_thread_continuation(thread_id: str, continuation_id: str) -> dict:
    return request("POST", thread_path(thread_id) + "/continuations/" + quote(continuation_id, safe="") + "/dispatch", {})
