"""Build/install the personal Windows plugin; preserve unrelated configuration."""
from __future__ import annotations
import argparse
import base64
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tomllib

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
MARKETPLACE = ROOT / "marketplace"
PLUGIN = MARKETPLACE / "plugins" / "paper-plan"


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")


def windows_hook_command(script_path: Path) -> str:
    # A single ASCII argument survives both cmd.exe and PowerShell forwarding.
    # The decoded command only invokes the fixed local script, including paths
    # containing spaces or apostrophes; event data still arrives on stdin.
    literal=str(script_path).replace("'", "''")
    encoded=base64.b64encode(("& '"+literal+"'").encode('utf-16-le')).decode('ascii')
    return 'powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+encoded


def prepare():
    python = ROOT / ".venv/Scripts/python.exe"
    if not python.exists() or not (ROOT/"frontend/dist/index.html").exists():
        raise RuntimeError("先准备项目 Python 环境与前端构建。")
    digest = hashlib.sha256()
    for relative in ["backend", "scripts", "frontend/dist", "schema", "skills/plan-panel"]:
        source = ROOT / relative
        package_directory = (PLUGIN / relative).resolve()
        if not package_directory.is_relative_to(PLUGIN.resolve()):
            raise RuntimeError("插件打包路径超出预定目录。")
        if package_directory.exists():
            for previous in package_directory.rglob("*"):
                if previous.is_file() and not (source / previous.relative_to(package_directory)).exists():
                    if not previous.resolve().is_relative_to(package_directory):
                        raise RuntimeError("插件目录中有指向外部的链接，未清理。")
                    previous.unlink()
        for file in sorted(source.rglob("*")):
            if file.is_file() and "__pycache__" not in file.parts and "tests" not in file.parts and file.suffix != ".pyc":
                target = PLUGIN / relative / file.relative_to(source)
                target.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(file,target)
                digest.update(file.read_bytes())
    version="2.0.0+"+digest.hexdigest()[:12]
    write_json(PLUGIN/"runtime.json",{"project":str(ROOT),"python":str(python)})
    common="""$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$runtime = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'runtime.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$env:PYTHONUTF8 = '1'
$env:PLAN_EDITOR_DB = Join-Path $runtime.project 'data/plans.sqlite3'
"""
    (PLUGIN/"start-mcp.ps1").write_text(common+"& $runtime.python (Join-Path $runtime.project 'scripts/mcp_server.py')\nexit $LASTEXITCODE\n",encoding="utf-8-sig")
    (PLUGIN/"hook.ps1").write_text(common+"$OutputEncoding = [System.Text.UTF8Encoding]::new($false)\n[Console]::In.ReadToEnd() | & $runtime.python (Join-Path $runtime.project 'scripts/paper_hook.py')\nexit $LASTEXITCODE\n",encoding="utf-8-sig")
    command=windows_hook_command(PLUGIN/'hook.ps1')
    hooks={name:[{"hooks":[{"type":"command","command":command,"commandWindows":command,"timeout":3 if name=="Interrupt" else 15,**({"additionalContextLimit":1800} if name=="UserPromptSubmit" else {})}]}] for name in ("UserPromptSubmit","Stop","Interrupt")}
    write_json(PLUGIN/"hooks/hooks.json",{"description":"正式计划自动保存为当前对话目录，并跟踪执行中断；不读取聊天历史或自动执行任务。","hooks":hooks})
    # Windows holds a process's working directory open. Keep long-lived MCP
    # processes out of the versioned plugin cache so updates can activate.
    write_json(PLUGIN/".mcp.json",{"mcpServers":{"paper-plan":{"command":str(python),"args":[str(ROOT/"scripts/mcp_server.py")],"cwd":str(ROOT),"env":{"PYTHONUTF8":"1","PLAN_EDITOR_DB":str(ROOT/"data/plans.sqlite3")},"startup_timeout_sec":30}}})
    write_json(PLUGIN/".codex-plugin/plugin.json",{"name":"paper-plan","version":version,"description":"自动生成可拖动的论文式多级计划，按确认目录在原对话执行。","skills":"./skills/","mcpServers":"./.mcp.json","hooks":"./hooks/hooks.json","interface":{"displayName":"论文式计划","shortDescription":"拖动多级标题，确认后按目录执行。","developerName":"Personal","category":"Productivity","defaultPrompt":"在计划模式中制定可编辑的多级目录计划。"}})
    write_json(MARKETPLACE/".agents/plugins/marketplace.json",{"name":"paper-plans-local","interface":{"displayName":"论文式计划 · 本机"},"plugins":[{"name":"paper-plan","source":{"source":"local","path":"./plugins/paper-plan"},"policy":{"installation":"AVAILABLE","authentication":"ON_INSTALL"},"category":"Productivity"}]})
    return version


def remove_owned_mcp(text):
    pattern=re.compile(r"(?ms)^\[mcp_servers\.plan_panel(?:\.[^\]\r\n]+)?\][ \t]*\r?\n.*?(?=^\[|\Z)")
    return pattern.sub("",text)


def install():
    version=prepare()
    from backend.providers import codex_executable
    codex=codex_executable()
    if not codex:raise RuntimeError("找不到 Codex CLI。")
    codex_dir=Path(os.environ.get("CODEX_HOME",str(Path.home()/".codex")))
    codex_dir.mkdir(parents=True,exist_ok=True)
    config_path=codex_dir/"config.toml"
    original=config_path.read_text(encoding="utf-8-sig") if config_path.exists() else ""
    legacy=tomllib.loads(original).get("mcp_servers",{}).get("plan_panel")
    if legacy:
        args=legacy.get("args",[])
        if len(args)!=1 or Path(args[0]).resolve()!=(ROOT/"scripts/mcp_server.py").resolve():
            raise RuntimeError("同名 plan_panel MCP 不属于此项目，未更改。")
    old_skill=codex_dir/"skills/plan-panel/SKILL.md"
    if old_skill.exists():
        record_path=ROOT/"data/bridge-install.json"
        record=json.loads(record_path.read_text(encoding="utf-8-sig")) if record_path.exists() else {}
        known=record.get("skill_hash","").lower()
        actual=hashlib.sha256(old_skill.read_bytes()).hexdigest()
        current=hashlib.sha256((ROOT/"skills/plan-panel/SKILL.md").read_bytes()).hexdigest()
        if actual not in {known,current}:
            raise RuntimeError("已安装 plan-panel 技能有用户改动，未覆盖。")
    backup=ROOT/"data/plugin-backups"/datetime.now().strftime("%Y%m%d-%H%M%S")
    backup.mkdir(parents=True)
    if config_path.exists():shutil.copy2(config_path,backup/"config.toml")
    if old_skill.exists():shutil.copy2(old_skill,backup/"plan-panel.SKILL.md")
    for command in ([codex,"plugin","marketplace","add",str(MARKETPLACE),"--json"],[codex,"plugin","add","paper-plan@paper-plans-local","--json"]):
        result=subprocess.run(command,capture_output=True,text=True,encoding="utf-8",errors="replace",timeout=90)
        if result.returncode:raise RuntimeError("Codex 插件安装失败："+result.stderr[-1800:]+result.stdout[-1800:])
        print(result.stdout)
    if legacy:
        # Re-read after CLI writes, and remove only the previously verified section.
        updated=config_path.read_text(encoding="utf-8-sig")
        cleaned=remove_owned_mcp(updated)
        if "plan_panel" in tomllib.loads(cleaned).get("mcp_servers",{}):
            raise RuntimeError("无法安全移除旧 MCP 条目。")
        temp=config_path.with_name("config.paper-plan.tmp")
        temp.write_text(cleaned,encoding="utf-8")
        os.replace(temp,config_path)
    if old_skill.exists():
        # The user profile and project can be on different drives.
        destination = backup/"installed-plan-panel.SKILL.md"
        shutil.copy2(old_skill, destination)
        if old_skill.read_bytes() != destination.read_bytes():
            raise RuntimeError("旧技能备份校验失败，原文件已保留。")
        old_skill.unlink()
    write_json(ROOT/"data/paper-plugin-install.json",{"version":version,"plugin":"paper-plan@paper-plans-local","marketplace":str(MARKETPLACE),"backup":str(backup),"hook_trust":"requires user review in Codex /hooks"})
    print("论文式计划已安装；旧注册已备份。首次安装或钩子定义变化时，请在 Codex /hooks 审阅并信任三个钩子；定义未变时保留已有信任。")


if __name__=="__main__":
    if hasattr(sys.stdout,"reconfigure"):sys.stdout.reconfigure(encoding="utf-8")
    parser=argparse.ArgumentParser();parser.add_argument("--prepare-only",action="store_true");args=parser.parse_args()
    if args.prepare_only:print(prepare())
    else:install()
