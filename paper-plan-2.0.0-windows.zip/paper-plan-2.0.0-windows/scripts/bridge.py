"""Skill fallback CLI when the host has not loaded the configured MCP yet."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
sys.path.insert(0, str(Path(__file__).resolve().parent))
import bridge_api as bridge


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["get", "create", "update", "confirmed", "requests", "request", "claim", "complete", "dispatch", "progress", "panel", "revision"])
    parser.add_argument("--thread", required=True)
    parser.add_argument("--payload", type=Path)
    parser.add_argument("--version-id")
    parser.add_argument("--expected-version", type=int)
    parser.add_argument("--continuation-id")
    parser.add_argument("--claimant-id")
    parser.add_argument("--node-id")
    parser.add_argument("--revision-id")
    args = parser.parse_args()
    def payload() -> dict:
        if args.payload is None:
            parser.error("create/update/complete require --payload JSON file")
        return json.loads(args.payload.read_text(encoding="utf-8-sig"))
    def required(value, name):
        if value is None:
            parser.error("missing " + name)
        return value
    try:
        if args.action == "revision":
            result = bridge.get_plan_revision(args.thread,required(args.revision_id,'--revision-id'))
        elif args.action == "panel":
            result = bridge.with_panel({}, args.thread)
        elif args.action == "progress":
            from urllib.parse import quote
            result = bridge.request("POST", bridge.thread_path(args.thread)+"/continuations/"+quote(required(args.continuation_id,"--continuation-id"),safe="")+"/nodes/"+quote(required(args.node_id,"--node-id"),safe=""), payload())
        elif args.action == "get":
            result = bridge.get_thread_plan(args.thread)
        elif args.action == "create":
            result = bridge.create_thread_plan(args.thread, payload())
        elif args.action == "update":
            result = bridge.update_thread_plan(args.thread, payload())
        elif args.action == "confirmed":
            result = bridge.get_confirmed_thread_plan(args.thread, args.version_id)
        elif args.action == "requests":
            result = bridge.list_thread_continuations(args.thread)
        elif args.action == "request":
            result = bridge.request_thread_continuation(args.thread, required(args.expected_version, "--expected-version"), required(args.version_id, "--version-id"))
        elif args.action == "claim":
            result = bridge.claim_thread_continuation(args.thread, required(args.continuation_id, "--continuation-id"), required(args.claimant_id, "--claimant-id"))
        elif args.action == "complete":
            result = bridge.complete_thread_continuation(args.thread, required(args.continuation_id, "--continuation-id"), payload())
        else:
            result = bridge.dispatch_thread_continuation(args.thread, required(args.continuation_id, "--continuation-id"))
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except (ValueError, OSError) as error:
        print(json.dumps({"error": str(error)}, ensure_ascii=False), file=sys.stderr)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
