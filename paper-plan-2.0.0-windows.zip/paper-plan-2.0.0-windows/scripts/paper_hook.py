"""Trusted Codex hook entrypoint. Consumes event stdin, never reads transcripts."""
from __future__ import annotations
import json
import os
from pathlib import Path
import re
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from backend.storage import Store
from backend.tree_domain import parse_proposed_plan
from codex_plan_reader import read_native_plan


def capture_final_plan(store: Store, thread: str, turn: str, text: str | None) -> dict:
    """Use final text, or the native plan item omitted from Stop's text field."""
    runtime = store.runtime(thread)
    capture = store.capture_status(thread, turn)
    if not runtime or runtime["turn_id"] != turn or not capture:
        return {"status": "ignored", "reason": "stale_or_missing_turn"}
    if capture["status"] in {"applied", "candidate", "dismissed"}:
        return {"status": capture["status"], "duplicate": True}
    if isinstance(text, str) and parse_proposed_plan(text) is not None:
        return store.capture_plan(thread, turn, text)
    native = read_native_plan(thread, turn)
    if native:
        body = native["text"]
        message = body if parse_proposed_plan(body) is not None else "<proposed_plan>\n" + body + "\n</proposed_plan>"
        return store.capture_plan(thread, turn, message, source_kind="native_plan", source_item_id=native["item_id"])
    store.mark_capture_result(thread, turn, "ignored")
    return {"status": "ignored", "reason": "no_formal_plan"}


def handle(event: dict, store: Store) -> dict:
    name = event.get("hook_event_name")
    thread = event.get("session_id", "")
    turn = event.get("turn_id", "")
    # Subagent payloads are not main-thread plan events.
    if event.get("agent_id") or name not in {"UserPromptSubmit", "Stop", "Interrupt"}:
        return {}
    if not isinstance(thread, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", thread):
        return {"systemMessage": "论文式计划：缺少可信对话标识，未同步。"}
    if not isinstance(turn, str) or not turn:
        return {"systemMessage": "论文式计划：缺少可信回合标识，未同步。"}
    mode = event.get("permission_mode", "unknown")
    if mode not in {"default", "acceptEdits", "plan", "dontAsk", "bypassPermissions"}:
        mode = "unknown"
    if name == "UserPromptSubmit":
        prompt = event.get("prompt", "")
        prompt = prompt if isinstance(prompt, str) else ""
        store.start_turn(thread, turn, mode, prompt)
        # Store metadata only: no prompt or transcript is persisted by this hook.
        revision_match = re.search(r"revision_id=([A-Za-z0-9_-]+)",prompt)
        if revision_match:
            try:
                revision = store.revision_snapshot(thread,revision_match[1])['revision']
            except ValueError:
                return {"hookSpecificOutput":{"hookEventName":name,"additionalContext":"该再修改请求已取消或被替代，不再提问、不生成替代计划、不执行任务。"}}
            except LookupError:
                return {"hookSpecificOutput":{"hookEventName":name,"additionalContext":"未找到当前对话的再修改请求，请用户在原面板重新发送；不要猜测版本。"}}
            return {"hookSpecificOutput":{"hookEventName":name,"additionalContext":f"论文式计划再修改：thread_id={thread}；revision_id={revision.id}；基于 v{revision.version}。先检查宿主当前协作模式；若非 Plan，只提示用户切换后继续，不能自行宣称切换。计划模式下读取技能 {(ROOT/'skills/plan-panel/SKILL.md').as_posix()}，调用 get_plan_revision 读取编辑后的不可变快照及用户重点。先提出2–3个影响方案的澄清问题，等用户回答后再梳理完整计划。不要执行任务、不要领取执行请求。"}}
        if "continuation_id=" in prompt:
            if mode == "plan":
                return {"hookSpecificOutput": {"hookEventName": name, "additionalContext": "当前仍在计划模式。不要领取或执行计划，也不要生成替代计划。告知用户手动切回执行模式后在面板重试；原确认版本已保留。"}}
            pending = next((c for c in store.continuations(thread) if c.status == "pending" and c.id in prompt), None)
            if pending:
                return {"hookSpecificOutput": {"hookEventName": name, "additionalContext": f"论文式计划续接：当前线程 {thread}。先检查宿主当前协作模式：如果仍在 Plan 模式，不领取、不执行；permission_mode=default 不代表已切回执行模式。否则读取技能 {(ROOT/'skills/plan-panel/SKILL.md').as_posix()}，领取 {pending.id} 的不可变确认版本，逐叶节点回报真实进度。不要重新规划。"}}
            return {}
        from bridge_api import api_base
        url = api_base() + "/?thread=" + thread
        context = f"""论文式计划插件已启用。可信当前 thread_id={thread}。
permission_mode 是工具权限模式，不能用它判断宿主的计划/执行协作模式。遵守宿主当前协作模式。
只有在计划协作模式形成待用户确认的完整正式计划时，才应用以下呈现规则；普通回复、澄清与讨论正常进行，不打开面板，不生成计划块。
在正式计划最终回复之前，用 open_in_codex(placement='right',target={{type:'browser',url:'{url}'}}) 打开当前对话右侧面板，不指定其他 threadId。若已显示可复用它。
正式计划仍使用一个 <proposed_plan> 块。用一个 # 总标题，以及 ##、### 等简短任务标题表达阶段和可执行子任务；标题可带 1、1.1、1.1.1 编号。每个标题下用正文保存具体要求、产出与验收，代码示例必须放代码围栏。父标题说明对子项生效，独立工作须有末级标题。保留足够实施细节，不强套论文的引言/方法/结果。
回复结束后本地 Stop 钩子会将这个块自动同步到面板；不要在计划模式调用写入计划的 MCP、写文件、确认计划或开始执行。不要输出另一个 JSON 版本或启动独立模型。用户编辑与确认在面板中完成。
若面板不可用，仍完整输出正式计划并说明面板错误。"""
        revision = store.active_revision(thread)
        if revision and revision.status == 'discussing':
            context += f"\n当前正在进行再修改问答：revision_id={revision.id}，依据用户提交的 v{revision.version}。用 get_plan_revision 核对快照及重点，吸收本轮回答；需求未明确时继续提问，明确后再给完整正式计划。当前若非 Plan 模式，只提示用户切换后继续。最终结果需要重新确认，不执行项目任务。"
        return {"hookSpecificOutput": {"hookEventName": name, "additionalContext": context}}
    if name == "Interrupt":
        store.finish_turn(thread, turn, interrupted=True)
        return {}
    text = event.get("last_assistant_message")
    try:
        result = capture_final_plan(store, thread, turn, text)
    finally:
        # An unavailable plan reader must never strand an execution lock.
        store.finish_turn(thread, turn)
    if result.get("status") == "candidate" and not result.get("duplicate"):
        return {"systemMessage": "论文式计划：检测到人工修改或未结束请求，生成结果已作为候选保留，请在面板比较。"}
    return {}


def main() -> int:
    event = {}
    store = None
    try:
        event = json.load(sys.stdin)
        if not isinstance(event,dict):
            raise ValueError("事件必须是 JSON 对象。")
        # Keep a small metadata-only receipt so host delivery can be distinguished
        # from payload/handler errors. Never record prompts or assistant messages.
        receipt_path = Path(os.environ.get("PLAN_EDITOR_DB", str(ROOT / "data" / "plans.sqlite3"))).parent / "hook-receipts.jsonl"
        receipt = {"at": datetime.now(timezone.utc).isoformat(), "event": event.get("hook_event_name"), "session_id": event.get("session_id"), "turn_id": event.get("turn_id"), "permission_mode": event.get("permission_mode"), "has_agent_id": bool(event.get("agent_id")), "fields": sorted(event)}
        if event.get("hook_event_name") == "Stop":
            message = event.get("last_assistant_message")
            receipt.update({"final_text_length": len(message) if isinstance(message, str) else 0, "has_plan_marker": isinstance(message, str) and "<proposed_plan>" in message})
        try:
            receipt_path.parent.mkdir(parents=True, exist_ok=True)
            with receipt_path.open("a", encoding="utf-8") as log:
                log.write(json.dumps(receipt, ensure_ascii=False) + "\n")
        except OSError:
            pass  # Diagnostics must not prevent normal hook handling.
        store = Store(os.environ.get("PLAN_EDITOR_DB", str(ROOT / "data" / "plans.sqlite3")))
        output = handle(event, store)
        if not event.get("agent_id") and event.get("hook_event_name") in {"UserPromptSubmit", "Stop"} and (event.get("permission_mode") == "plan" or store.thread_plan(event.get("session_id", ""))):
            try:
                from service_runtime import ensure_service
                ensure_service()
            except Exception as error:
                output["systemMessage"] = str(error)
                store.hook_error(event.get("session_id", ""), str(error))
        print(json.dumps(output, ensure_ascii=False))
        return 0
    except Exception as error:
        message = "论文式计划同步失败：" + str(error)
        if store:
            store.hook_error(event.get("session_id", ""), message)
            store.mark_capture_result(event.get("session_id", ""), event.get("turn_id", ""), "error", message)
        print(json.dumps({"systemMessage":message}, ensure_ascii=False))
        return 0  # A panel failure must not suppress the assistant's original plan.
    finally:
        if store:
            store.close()


if __name__ == "__main__":
    raise SystemExit(main())
