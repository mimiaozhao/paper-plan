param([string]$PythonExecutable, [string]$CodexHome, [switch]$PrepareOnly)
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$env:PYTHONUTF8 = '1'
if ($CodexHome) { $env:CODEX_HOME = [IO.Path]::GetFullPath($CodexHome) }
$manifestPath = Join-Path $PSScriptRoot 'PACKAGE.json'
if (Test-Path -LiteralPath $manifestPath) {
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $releaseRoot = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\') + '\'
    foreach ($entry in $manifest.files) {
        $relative = [string]$entry.path
        if ($relative -match '(^/|:|\\|(^|/)\.\.(/|$))') { throw 'Invalid package file path.' }
        $file = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot $relative))
        if (-not $file.StartsWith($releaseRoot, [StringComparison]::OrdinalIgnoreCase)) { throw 'Package path escapes its folder.' }
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw "Missing package file: $relative" }
        if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Package checksum mismatch: $relative" }
    }
}
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'frontend/dist/index.html'))) {
    throw 'Prebuilt UI is missing. Download the Windows installer ZIP from Releases, or build frontend first.'
}
$projectPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $projectPython)) {
    $candidates = @()
    if ($PythonExecutable) { $candidates += $PythonExecutable }
    $bundled = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
    if (Test-Path -LiteralPath $bundled) { $candidates += $bundled }
    foreach ($name in @('py.exe','python.exe','python3.exe')) {
        $command = Get-Command $name -ErrorAction SilentlyContinue
        if ($command -and $command.Source -notmatch '\\Microsoft\\WindowsApps\\') { $candidates += $command.Source }
    }
    $bootstrapPython = $null
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
        & $candidate -c 'import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)' 2>$null
        if ($LASTEXITCODE -eq 0) { $bootstrapPython = $candidate; break }
    }
    if (-not $bootstrapPython) { throw 'Python 3.11+ was not found. Install it from https://www.python.org/downloads/windows/ and rerun Install.cmd.' }
    & $bootstrapPython -m venv (Join-Path $PSScriptRoot '.venv')
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the Python environment.' }
}
& $projectPython -c 'import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)'
if ($LASTEXITCODE -ne 0) { throw 'The existing .venv is unusable; restore a working Python environment before retrying.' }
& $projectPython -m pip --disable-pip-version-check install --no-input -r (Join-Path $PSScriptRoot 'backend\requirements-bridge.txt')
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Check the network and rerun Install.cmd.' }
& $projectPython -c 'from mcp.server.mcpserver import MCPServer; import fastapi, pydantic, uvicorn, httpx'
if ($LASTEXITCODE -ne 0) { throw 'Dependency verification failed.' }
$arguments = @((Join-Path $PSScriptRoot 'scripts\install_paper_plugin.py'))
if ($PrepareOnly) { $arguments += '--prepare-only' }
& $projectPython @arguments
if ($LASTEXITCODE -ne 0) { throw 'Plugin registration failed; see the error above.' }
Write-Host 'Ready. Keep this installation folder in place. Review and trust the hooks in Codex on first install.'
