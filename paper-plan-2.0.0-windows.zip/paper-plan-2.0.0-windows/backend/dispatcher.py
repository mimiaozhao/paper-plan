"""Send an explicit continuation to the original local Codex session."""
from __future__ import annotations
import os
import subprocess
import uuid
from .providers import codex_executable
from .runtime_context import restricted_runtime


def dispatch_to_codex(thread_id: str, message: str) -> dict:
    if os.environ.get("PLAN_PANEL_DISPATCH", "1") == "0":
        return {"status": "manual", "error": "此环境未启用对话消息投递，请复制继续请求到原对话。"}
    if restricted_runtime():
        return {"status": "manual", "error": "投递未开始：计划服务运行在 Codex 隔离账户，无法访问你的桌面对话。请以桌面用户重启计划服务；当前请求可以取消，确认版本仍保留。"}
    try:
        uuid.UUID(thread_id)
    except ValueError:
        return {"status": "manual", "error": "当前标识不是本地 Codex 对话 UUID，请在原对话发送继续请求。"}
    executable = codex_executable()
    if not executable:
        return {"status": "manual", "error": "未检测到支持消息队列的 Codex CLI，请复制继续请求到原对话。"}
    try:
        result = subprocess.run(
            [executable, "queue", "--thread", thread_id, "--message", message],
            stdin=subprocess.DEVNULL, capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=15, shell=False,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
    except subprocess.TimeoutExpired:
        return {"status": "manual", "error": "投递响应超时；请先检查原对话是否已有排队消息，避免重复发送。"}
    except OSError:
        return {"status": "manual", "error": "本地 Codex 消息投递不可用，请复制继续请求到原对话。"}
    if result.returncode != 0:
        # Classify known transport errors without leaking arbitrary CLI output,
        # which may contain the continuation text or account configuration.
        diagnostic = (result.stderr or "").casefold()
        reason = "CLI 拒绝了投递；请在原对话手动继续或取消此请求。"
        if "10050" in diagnostic or "failed to connect" in diagnostic:
            reason = "无法连接 Codex 桌面核心，请检查核心服务及运行账户。"
        elif "thread" in diagnostic and any(word in diagnostic for word in ("not found", "unknown", "missing")):
            reason = "当前运行账户找不到目标对话，请检查计划服务是否由桌面用户启动。"
        elif "permission denied" in diagnostic or "access is denied" in diagnostic:
            reason = "当前运行账户无权访问 Codex 对话服务。"
        return {"status": "manual", "error": f"投递失败（CLI 退出码 {result.returncode}）：{reason}"}
    return {"status": "queued", "error": None}
