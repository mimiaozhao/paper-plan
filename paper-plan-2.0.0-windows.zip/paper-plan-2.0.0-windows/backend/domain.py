"""Validation and deterministic, source-mapped prompt compilation."""
from __future__ import annotations
import hashlib
import heapq
import json
import math
from collections import Counter
from typing import Any
from jinja2 import Environment, StrictUndefined
from .models import CompileResult, CompileSegment, Issue, PlanDocument

TEMPLATE_VERSION = "plan-prompt/1.0"
NODE_FIELDS = {"title", "goal", "inputs", "requirements", "output_format", "acceptance_criteria"}
STRUCTURAL_CODES = {"tree_structure", "tree_dependency", "duplicate_id", "missing_id", "dangling_edge", "self_edge", "duplicate_edge", "cycle", "invalid_outline_ref", "invalid_locked_field", "invalid_layout"}
ENVIRONMENT = Environment(undefined=StrictUndefined, autoescape=False, keep_trailing_newline=True)
FIELD_TEMPLATE = ENVIRONMENT.from_string("{{ label }}\n{{ value }}")

class PlanValidationError(ValueError):
    def __init__(self, issues: list[Issue]):
        self.issues = issues
        super().__init__("计划存在校验错误，请修复标记字段。")

def as_document(document: PlanDocument | dict[str, Any]) -> PlanDocument:
    return document if isinstance(document, PlanDocument) else PlanDocument.model_validate(document)

def semantic_hash(document: PlanDocument | dict[str, Any]) -> str:
    data = as_document(document).model_dump(mode="json", exclude={"layout"})
    if data["schema_version"] == 1:
        data.pop("tree", None)  # Preserve hashes of existing immutable v1 snapshots.
    else:
        data["tree"] = sorted(data["tree"], key=lambda item: item["id"])
        for node in data["tree"]:
            node["depends_on"] = sorted(set(node["depends_on"]))
    for field in ("nodes", "edges", "constraints", "assumptions"):
        data[field] = sorted(data[field], key=lambda item: item["id"])
    for node in data["nodes"]:
        node["locked_fields"] = sorted(set(node["locked_fields"]))
    encoded = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()

def topological_nodes(document: PlanDocument) -> list:
    nodes = {node.id: node for node in document.nodes}
    degrees = {node_id: 0 for node_id in nodes}
    children = {node_id: [] for node_id in nodes}
    seen: set[tuple[str, str]] = set()
    for edge in document.edges:
        pair = (edge.source, edge.target)
        if edge.source not in nodes or edge.target not in nodes or pair in seen:
            continue
        seen.add(pair)
        degrees[edge.target] += 1
        children[edge.source].append(edge.target)
    ready = [node_id for node_id, degree in degrees.items() if degree == 0]
    heapq.heapify(ready)
    result = []
    while ready:
        node_id = heapq.heappop(ready)
        result.append(nodes[node_id])
        for target in sorted(children[node_id]):
            degrees[target] -= 1
            if degrees[target] == 0:
                heapq.heappush(ready, target)
    return result

def validate_document(document: PlanDocument | dict[str, Any], mode: str = "draft") -> list[Issue]:
    document = as_document(document)
    if document.schema_version == 2:
        from .tree_domain import validate_tree
        return validate_tree(document, mode)
    issues: list[Issue] = []
    def issue(code: str, message: str, field: str | None = None, node_id: str | None = None, severity: str = "error") -> None:
        issues.append(Issue(severity=severity, code=code, message=message, field=field, node_id=node_id))
    def required(value: str, label: str, field: str, node_id: str | None = None) -> None:
        if not value.strip():
            issue("missing_field", f"{label}不能为空。", field, node_id)
    required(document.id, "计划 ID", "id")
    required(document.title, "计划标题", "title")
    required(document.original_request, "原始需求", "original_request")
    required(document.goal, "全局目标", "goal")
    groups = (("nodes", document.nodes), ("edges", document.edges), ("constraints", document.constraints), ("assumptions", document.assumptions), ("output_outline", document.output_outline))
    for field, items in groups:
        counts = Counter(item.id for item in items)
        for entity_id, count in sorted(counts.items()):
            if not entity_id.strip():
                issue("missing_id", f"{field} 中存在空 ID。", field)
            if count > 1:
                issue("duplicate_id", f"{field} 中 ID「{entity_id}」重复。", field, entity_id if field == "nodes" else None)
    if not document.nodes:
        issue("missing_field", "至少需要一个任务节点。", "nodes")
    node_ids = {node.id for node in document.nodes}
    for node in sorted(document.nodes, key=lambda item: item.id):
        for field, label in (("title", "节点标题"), ("goal", "节点目标"), ("requirements", "具体要求"), ("output_format", "输出格式")):
            required(getattr(node, field), f"节点「{node.title or node.id}」的{label}", field, node.id)
        for field, label in (("inputs", "输入"), ("acceptance_criteria", "验收标准")):
            values = getattr(node, field)
            if not values or any(not value.strip() for value in values):
                issue("missing_field", f"节点「{node.title or node.id}」至少需要一条非空{label}。", field, node.id)
        for field in sorted(set(node.locked_fields) - NODE_FIELDS):
            issue("invalid_locked_field", f"节点「{node.id}」不能锁定未知字段「{field}」。", "locked_fields", node.id)
    pairs: set[tuple[str, str]] = set()
    for edge in sorted(document.edges, key=lambda item: item.id):
        if edge.source not in node_ids or edge.target not in node_ids:
            issue("dangling_edge", f"连线「{edge.id}」引用了不存在的节点。", "edges", edge.target)
        if edge.source == edge.target:
            issue("self_edge", f"节点「{edge.source}」不能依赖自身。", "edges", edge.source)
        pair = (edge.source, edge.target)
        if pair in pairs:
            issue("duplicate_edge", f"「{edge.source} → {edge.target}」连线重复。", "edges", edge.target)
        pairs.add(pair)
    if len(topological_nodes(document)) != len(node_ids):
        issue("cycle", "依赖关系存在循环，请移除形成闭环的连线。", "edges")
    for constraint in sorted(document.constraints, key=lambda item: item.id):
        required(constraint.text, "约束内容", "constraints")
    for assumption in sorted(document.assumptions, key=lambda item: item.id):
        required(assumption.text, "假设内容", "assumptions")
        if assumption.status == "pending":
            issue("pending_assumption", f"假设「{assumption.text or assumption.id}」尚未确认。", "assumptions", severity="error" if mode == "confirm" else "warning")
    if not document.output_outline:
        issue("missing_field", "至少需要一个最终输出章节。", "output_outline")
    for section in document.output_outline:
        required(section.title, "输出章节标题", "output_outline")
        if not section.node_ids:
            issue("missing_field", f"章节「{section.title or section.id}」需要关联任务节点。", "output_outline")
        for node_id in section.node_ids:
            if node_id not in node_ids:
                issue("invalid_outline_ref", f"章节「{section.title or section.id}」引用未知节点「{node_id}」。", "output_outline", node_id)
        if len(set(section.node_ids)) != len(section.node_ids):
            issue("invalid_outline_ref", f"章节「{section.title or section.id}」重复引用同一节点。", "output_outline")
    for node_id, position in sorted(document.layout.items()):
        if not math.isfinite(position.x) or not math.isfinite(position.y):
            issue("invalid_layout", f"节点「{node_id}」的位置必须为有限数值。", "layout", node_id)
        elif node_id not in node_ids:
            issue("orphan_layout", f"布局中节点「{node_id}」已不存在。", "layout", node_id, "warning")
    return issues

def compile_document(document: PlanDocument | dict[str, Any]) -> CompileResult:
    document = as_document(document)
    if document.schema_version == 2:
        from .tree_domain import compile_tree
        return compile_tree(document)
    issues = validate_document(document)
    if any(issue.severity == "error" for issue in issues):
        raise PlanValidationError(issues)
    segments: list[CompileSegment] = []
    def add(source_type: str, source_id: str, field: str, label: str, value: str) -> None:
        text = FIELD_TEMPLATE.render(label=label, value=value)
        segments.append(CompileSegment(id=f"{source_type}:{source_id}:{field}", source_type=source_type, source_id=source_id, field=field, text=text))
    def numbered(values: list[str]) -> str:
        return "\n".join(f"{index}. {value}" for index, value in enumerate(values, 1))
    add("global", document.id, "instructions", "执行规则", "请依照以下经用户编辑的计划，一次性完成任务并交付最终成果。按依赖顺序使用上游任务产物；严格遵守锁定约束和字段。未确认假设必须明确标注，已拒绝假设不得作为依据。无法满足的要求应明确说明，不得编造完成情况。\n这是单次整体执行请求，节点用于表达计划，不代表独立模型调用。")
    add("global", document.id, "title", "计划标题", document.title)
    add("global", document.id, "provenance", "计划来源", {"mock": "Mock 演示计划（规则生成，非模型推理）", "codex": "Codex 生成计划", "import": "用户导入计划", "conversation": "当前对话任务计划"}[document.provenance])
    add("global", document.id, "original_request", "用户原始需求", document.original_request)
    add("global", document.id, "goal", "全局目标", document.goal)
    add("global", document.id, "constraints", "全局约束", "\n".join(f"- {'[锁定] ' if item.locked else ''}{item.text}" for item in sorted(document.constraints, key=lambda item: item.id)) or "无额外约束。")
    statuses = {"pending": "待确认", "accepted": "已接受", "rejected": "已拒绝，不得采用"}
    add("global", document.id, "assumptions", "假设与确认状态", "\n".join(f"- [{statuses[item.status]}] {item.text}" for item in sorted(document.assumptions, key=lambda item: item.id)) or "无假设。")
    for node in topological_nodes(document):
        add("node", node.id, "title", f"任务 {node.id}", node.title)
        fields = (("goal", "目标", node.goal), ("inputs", "输入", numbered(node.inputs)), ("requirements", "具体要求", node.requirements), ("output_format", "输出格式", node.output_format), ("acceptance_criteria", "验收标准", numbered(node.acceptance_criteria)))
        for field, label, value in fields:
            add("node", node.id, field, label + (" [锁定]" if field in node.locked_fields else ""), value)
        parents = sorted({edge.source for edge in document.edges if edge.target == node.id})
        add("node", node.id, "dependencies", "前置任务", ", ".join(parents) if parents else "无；可直接开始。")
        if "title" in node.locked_fields:
            add("node", node.id, "locked_fields", "锁定字段", ", ".join(sorted(set(node.locked_fields))))
    for index, section in enumerate(document.output_outline, 1):
        add("outline", section.id, "title", f"最终输出章节 {index}", section.title)
        add("outline", section.id, "node_ids", "章节内容来自任务", ", ".join(section.node_ids))
    return CompileResult(text="\n\n".join(segment.text for segment in segments) + "\n", semantic_hash=semantic_hash(document), template_version=TEMPLATE_VERSION, segments=segments, issues=issues)
