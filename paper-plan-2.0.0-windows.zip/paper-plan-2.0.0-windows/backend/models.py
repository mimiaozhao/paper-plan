"""Shared, versioned API document contract."""
from __future__ import annotations
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field

class ContractModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

class Constraint(ContractModel):
    id: str
    text: str
    locked: bool = False

class Assumption(ContractModel):
    id: str
    text: str
    status: Literal["pending", "accepted", "rejected"] = "pending"

class PlanNode(ContractModel):
    id: str
    title: str = ""
    goal: str = ""
    inputs: list[str] = Field(default_factory=list)
    requirements: str = ""
    output_format: str = ""
    acceptance_criteria: list[str] = Field(default_factory=list)
    locked_fields: list[str] = Field(default_factory=list)

class PlanEdge(ContractModel):
    id: str
    source: str
    target: str

class OutlineSection(ContractModel):
    id: str
    title: str = ""
    node_ids: list[str] = Field(default_factory=list)

class Position(ContractModel):
    x: float
    y: float

class TreeNode(ContractModel):
    id: str
    parent_id: str | None = None
    order: int = Field(default=0, ge=0)
    title: str = ""
    details: str = ""
    output: str = ""
    acceptance_criteria: list[str] = Field(default_factory=list)
    depends_on: list[str] = Field(default_factory=list)

class PlanDocument(ContractModel):
    schema_version: Literal[1, 2] = 1
    id: str
    title: str = ""
    original_request: str = ""
    goal: str = ""
    provenance: Literal["mock", "codex", "import", "conversation"] = "mock"
    constraints: list[Constraint] = Field(default_factory=list)
    assumptions: list[Assumption] = Field(default_factory=list)
    nodes: list[PlanNode] = Field(default_factory=list)
    edges: list[PlanEdge] = Field(default_factory=list)
    output_outline: list[OutlineSection] = Field(default_factory=list)
    layout: dict[str, Position] = Field(default_factory=dict)
    tree: list[TreeNode] = Field(default_factory=list)

class ThreadBinding(ContractModel):
    thread_id: str = Field(pattern=r"^[A-Za-z0-9_-]{1,128}$")
    thread_title: str
    task_brief: str
    confirmed_decisions: list[str]
    context_revision: str
    updated_at: str

class PlanState(ContractModel):
    document: PlanDocument
    version: int
    semantic_hash: str
    confirmed: bool
    version_id: str
    updated_at: str
    binding: ThreadBinding | None = None

class Issue(ContractModel):
    severity: Literal["error", "warning"]
    code: str
    message: str
    node_id: str | None = None
    field: str | None = None

class CompileSegment(ContractModel):
    id: str
    source_type: Literal["global", "node", "outline"]
    source_id: str
    field: str
    text: str

class CompileResult(ContractModel):
    text: str
    semantic_hash: str
    template_version: str
    segments: list[CompileSegment]
    issues: list[Issue]

class Run(ContractModel):
    id: str
    plan_id: str
    version_id: str
    version: int
    provider: Literal["mock", "codex"]
    is_mock: bool
    status: Literal["completed", "failed"]
    output: str
    error: str | None
    created_at: str

class GenerateRequest(ContractModel):
    request: str = Field(min_length=1, max_length=20000)
    provider: Literal["mock", "codex"] = "mock"

class DocumentRequest(ContractModel):
    document: PlanDocument

class SaveRequest(DocumentRequest):
    expected_version: int = Field(ge=1)

class ValidationRequest(DocumentRequest):
    mode: Literal["draft", "confirm"] = "draft"

class ConfirmRequest(ContractModel):
    expected_version: int = Field(ge=1)

class RunRequest(ContractModel):
    provider: Literal["mock", "codex"] = "mock"
    version_id: str


class ThreadPlanRequest(DocumentRequest):
    thread_title: str = Field(min_length=1, max_length=1000)
    task_brief: str = Field(min_length=1, max_length=50000)
    confirmed_decisions: list[str] = Field(default_factory=list)

class ThreadSaveRequest(ThreadPlanRequest):
    expected_version: int = Field(ge=1)

class ThreadPlanView(ContractModel):
    state: PlanState | None = None

class NodeProgress(ContractModel):
    status: Literal["pending", "running", "completed", "failed", "interrupted"] = "pending"
    output: str = ""
    evidence: str = ""
    adjustment_reason: str = ""
    updated_at: str = ""

class ProgressRequest(NodeProgress):
    claim_token: str = Field(min_length=1)
    version_id: str = Field(min_length=1)

class Continuation(ContractModel):
    id: str
    thread_id: str
    plan_id: str
    version_id: str
    version: int
    semantic_hash: str
    status: Literal["pending", "running", "completed", "failed", "superseded", "cancelled", "interrupted"]
    message: str
    output: str = ""
    error: str | None = None
    created_at: str
    updated_at: str
    delivery_status: Literal["not_sent", "sending", "queued", "manual"] = "not_sent"
    delivery_error: str | None = None
    progress: dict[str, NodeProgress] = Field(default_factory=dict)
    execution_turn_id: str | None = None
    waiting_for_mode: bool = False
    waiting_for_context: bool = False
    blocked_reason: str | None = None

class ContinuationRequest(ContractModel):
    expected_version: int = Field(ge=1)
    version_id: str = Field(min_length=1)

class ClaimRequest(ContractModel):
    claimant_id: str = Field(min_length=1, max_length=256)

class CompleteRequest(ContractModel):
    claim_token: str = Field(min_length=1)
    status: Literal["completed", "failed"]
    output: str = ""
    error: str | None = None

class CandidateRequest(ContractModel):
    expected_version: int = Field(ge=1)
    accept: bool


class PlanRevision(ContractModel):
    id: str
    thread_id: str
    plan_id: str
    version_id: str
    version: int
    semantic_hash: str
    notes: str = ""
    status: Literal["pending", "discussing", "completed", "candidate", "cancelled", "superseded"] = "pending"
    message: str
    delivery_status: Literal["not_sent", "sending", "queued", "manual"] = "not_sent"
    delivery_error: str | None = None
    received_turn_id: str | None = None
    result_turn_id: str | None = None
    result_version_id: str | None = None
    created_at: str
    updated_at: str


class RevisionRequest(ContractModel):
    expected_version: int = Field(ge=1)
    version_id: str = Field(min_length=1)
    notes: str = Field(default="", max_length=12000)
