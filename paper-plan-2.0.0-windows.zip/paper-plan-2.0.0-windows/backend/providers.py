"""Explicit Mock and isolated Codex CLI adapters; providers never fall back."""
from __future__ import annotations
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from .domain import validate_document
from .models import Assumption, Constraint, ContractModel, OutlineSection, PlanDocument, PlanEdge, PlanNode, Position
from .storage import identifier

TIMEOUT_SECONDS = 300
MAX_TIMEOUT_SECONDS = 900

class ProviderError(RuntimeError):
    pass

def codex_timeout_seconds() -> int:
    raw = os.environ.get("PLAN_EDITOR_CODEX_TIMEOUT", str(TIMEOUT_SECONDS))
    try:
        timeout = int(raw)
    except ValueError as error:
        raise ProviderError("PLAN_EDITOR_CODEX_TIMEOUT 必须为 1–900 之间的整数秒。") from error
    if timeout < 1 or timeout > MAX_TIMEOUT_SECONDS:
        raise ProviderError("PLAN_EDITOR_CODEX_TIMEOUT 必须为 1–900 之间的整数秒。")
    return timeout

class GeneratedPlan(ContractModel):
    title: str
    goal: str
    constraints: list[Constraint]
    assumptions: list[Assumption]
    nodes: list[PlanNode]
    edges: list[PlanEdge]
    output_outline: list[OutlineSection]

class MockProvider:
    id = "mock"
    def generate(self, request: str) -> PlanDocument:
        request = request.strip()
        labels = [
            ("澄清目标与边界", "从原始需求提取目标、受众、范围与交付要求。", "原始需求", "列出明确要求、待确认项和任务边界。保留用户的具体表述。", "目标与范围清单", "每一项都能追溯到原始需求。"),
            ("整理输入与证据", "整理完成任务所需的输入与可用证据。", "原始需求及目标范围清单", "标记现有材料、缺失信息与需核实事实，不编造数据或来源。", "输入与证据清单", "明确已有输入、缺口与核实方式。"),
            ("形成内容与方案", "围绕用户目标形成可执行内容或解决方案。", "已核实输入及目标范围清单", "给出清晰推理、执行步骤和必要的例子，并解释关键取舍。", "主体草稿或实施方案", "内容满足原始需求与全局约束。"),
            ("检查风险与替代路径", "识别依赖、风险以及可用的替代路径。", "输入与证据清单", "列出会影响交付的风险，给出具体处理方法；没有依据的推断应标注。", "风险与应对表", "关键风险均有明确处理方式。"),
            ("校验与整合", "核对主体方案并整合风险处理。", "主体草稿、风险与应对表", "按验收标准逐条核对，修复遗漏与相互矛盾之处。", "经校验的完整草稿", "全局约束、任务要求和验收标准逐项满足。"),
            ("交付最终成果", "按最终输出目录交付用户可以直接使用的成果。", "经校验的完整草稿", "组织最终内容，注明待确认信息、已知限制和必要的下一步。", "结构化最终成果", "输出结构完整、措辞清晰、没有虚构完成情况。"),
        ]
        nodes = [PlanNode(id=f"node-{index}", title=title, goal=goal, inputs=[inputs], requirements=requirements, output_format=output, acceptance_criteria=[acceptance], locked_fields=[]) for index, (title, goal, inputs, requirements, output, acceptance) in enumerate(labels, 1)]
        pairs = [(1, 2), (2, 3), (2, 4), (3, 5), (4, 5), (5, 6)]
        return PlanDocument(
            id=identifier("plan"), title="Mock 演示计划 · " + request.replace("\n", " ")[:32], original_request=request,
            goal="围绕以下原始需求交付可直接使用、可逐项验收的成果：\n" + request, provenance="mock",
            constraints=[Constraint(id="constraint-1", text="遵守用户的原始需求与编辑后的计划；不得编造事实、来源或完成情况。", locked=True)],
            assumptions=[Assumption(id="assumption-1", text="默认最终成果采用中文，面向提出需求的用户。请接受、拒绝或修改此假设。", status="pending")],
            nodes=nodes, edges=[PlanEdge(id=f"edge-{index}", source=f"node-{source}", target=f"node-{target}") for index, (source, target) in enumerate(pairs, 1)],
            output_outline=[OutlineSection(id="outline-1", title="目标与输入依据", node_ids=["node-1", "node-2"]), OutlineSection(id="outline-2", title="主体成果与风险处理", node_ids=["node-3", "node-4", "node-5"]), OutlineSection(id="outline-3", title="最终交付与验收", node_ids=["node-6"])],
            layout={f"node-{index}": Position(x=(index - 1) * 270, y=80 if index != 4 else 270) for index in range(1, 7)},
        )

    def execute(self, prompt: str) -> str:
        return "【Mock 演示运行】\n此结果用于验证确认版本 → 编译提示词 → 执行记录的完整链路。Mock 没有调用模型，没有完成真实内容生成。\n\n已接收并绑定所选确认版本的完整编译提示词，共 " + str(len(prompt)) + " 个字符。\n\n切换到 Codex CLI 后，可用同一确认版本发起真实整体执行。"

def codex_executable() -> str | None:
    configured = os.environ.get("PLAN_EDITOR_CODEX_PATH")
    if configured:
        return configured if Path(configured).is_file() else None
    host_cli = os.environ.get("CODEX_CLI_PATH")
    if host_cli and Path(host_cli).is_file():
        return host_cli
    found = shutil.which("codex")
    if found:
        return found
    if os.name == "nt":
        location = Path(os.environ.get("LOCALAPPDATA", "")) / "OpenAI" / "Codex" / "bin"
        candidates = sorted(location.glob("*/codex.exe"), key=lambda path: path.stat().st_mtime, reverse=True)
        if candidates:
            return str(candidates[0])
    return None

def strict_schema(schema: dict) -> dict:
    def visit(value):
        if isinstance(value, dict):
            value.pop("default", None)
            if value.get("type") == "object" and "properties" in value:
                value["additionalProperties"] = False
                value["required"] = list(value["properties"])
            for item in value.values():
                visit(item)
        elif isinstance(value, list):
            for item in value:
                visit(item)
    visit(schema)
    return schema

class CodexProvider:
    id = "codex"
    def _call(self, prompt: str, schema: dict | None = None) -> str:
        timeout_seconds = codex_timeout_seconds()
        executable = codex_executable()
        if not executable:
            raise ProviderError("未检测到 Codex CLI。请先安装 CLI 并执行 codex login。")
        with tempfile.TemporaryDirectory(prefix="visual-plan-codex-") as temporary:
            folder = Path(temporary)
            output = folder / "response.txt"
            command = [executable, "exec", "--skip-git-repo-check", "--ephemeral", "--ignore-user-config", "--ignore-rules", "--sandbox", "read-only", "--color", "never", "-c", 'approval_policy="never"', "--cd", str(folder), "--output-last-message", str(output)]
            for feature in ("hooks", "plugins", "apps", "multi_agent", "shell_tool", "unified_exec", "browser_use", "computer_use"):
                command.extend(["--disable", feature])
            if os.environ.get("PLAN_EDITOR_CODEX_HTTP", "1") != "0":
                command.extend([
                    "-c", 'model_provider="plan_http"',
                    "-c", 'model_providers.plan_http.name="Plan HTTP"',
                    "-c", 'model_providers.plan_http.wire_api="responses"',
                    "-c", 'model_providers.plan_http.requires_openai_auth=true',
                    "-c", 'model_providers.plan_http.supports_websockets=false',
                ])
            if schema is not None:
                schema_path = folder / "schema.json"
                schema_path.write_text(json.dumps(schema, ensure_ascii=False), encoding="utf-8")
                command.extend(["--output-schema", str(schema_path)])
            command.append("-")
            environment = os.environ.copy()
            environment.pop("RUST_LOG", None)
            try:
                process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace", cwd=folder, env=environment, creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
                try:
                    _, stderr = process.communicate(prompt, timeout=timeout_seconds)
                except subprocess.TimeoutExpired as error:
                    if os.name == "nt":
                        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], capture_output=True, timeout=10, creationflags=subprocess.CREATE_NO_WINDOW)
                    else:
                        process.kill()
                    process.communicate(timeout=10)
                    raise ProviderError(f"Codex CLI 运行超过 {timeout_seconds} 秒，已终止。计划与确认版本保留，可以重试。") from error
            except OSError as error:
                raise ProviderError("无法启动 Codex CLI。请检查 CLI 路径和本机运行权限。") from error
            if process.returncode:
                lower = stderr.lower()
                reason = "请检查登录状态、网络连接与 CLI 配置。"
                if "unauthorized" in lower or "authentication" in lower or "not logged" in lower:
                    reason = "请先执行 codex login，完成登录后重试。"
                elif "rate limit" in lower or "quota" in lower or "usage limit" in lower:
                    reason = "账户调用额度或速率受限，请稍后重试。"
                elif "schema" in lower:
                    reason = "CLI 拒绝了结构化输出要求，请检查 CLI 版本。"
                raise ProviderError(f"Codex CLI 未成功完成（退出码 {process.returncode}）。{reason}")
            if not output.is_file() or not output.read_text(encoding="utf-8").strip():
                raise ProviderError("Codex CLI 未返回最终结果；未使用 Mock 代替。")
            return output.read_text(encoding="utf-8").strip()

    def generate(self, request: str) -> PlanDocument:
        prompt = "你是计划编辑器的计划生成器。只返回符合指定 JSON Schema 的计划，不执行计划，不调用工具，不查看文件。所有标题与说明采用中文。通常将用户需求拆成约 5–8 个有明确产物的自包含任务节点，简单需求可以更少，不为凑数拆分。每个节点填写 title/goal/inputs/requirements/output_format/acceptance_criteria/locked_fields。inputs 是输入说明字符串列表；edges 表示前置任务依赖，必须是有向无环图。ID 使用稳定短标识，所有引用必须存在。outline 按最终交付章节排列。只对真实歧义列 pending 假设，不得虚构用户已经同意。严格保留用户意图，不编造资料。\n\n用户需求：\n" + request
        result = self._call(prompt, strict_schema(GeneratedPlan.model_json_schema()))
        try:
            generated = GeneratedPlan.model_validate_json(result)
            document = PlanDocument(id=identifier("plan"), original_request=request, provenance="codex", **generated.model_dump())
            ordered = sorted(document.nodes, key=lambda node: node.id)
            document.layout = {node.id: Position(x=(index % 4) * 270, y=(index // 4) * 210 + 80) for index, node in enumerate(ordered)}
        except ValueError as error:
            raise ProviderError("Codex 返回的计划格式不符合编辑器数据协议，请重试。") from error
        errors = [issue for issue in validate_document(document) if issue.severity == "error"]
        if errors:
            raise ProviderError("Codex 返回的计划未通过校验：" + "；".join(issue.message for issue in errors[:4]))
        return document

    def execute(self, prompt: str) -> str:
        return self._call("根据以下经用户确认的计划，生成最终内容。只返回最终成果文本；不得调用工具、修改文件或执行任何外部操作。如果缺少材料，明确指出限制。\n\n" + prompt)

def get_provider(name: str):
    if name == "mock":
        return MockProvider()
    if name == "codex":
        return CodexProvider()
    raise ProviderError("未知执行提供方。")

def provider_status() -> list[dict]:
    executable = codex_executable()
    available = bool(executable)
    reason = "未检测到 Codex CLI，请安装并登录后重试。"
    if executable:
        try:
            timeout_seconds = codex_timeout_seconds()
            reason = f"已检测到 CLI；生成和执行每次最长 {timeout_seconds} 秒，登录与模型可用性在实际调用时检查。为隔离 hooks，调用不加载用户 config.toml，使用 CLI 默认 OpenAI 配置。"
        except ProviderError as error:
            available, reason = False, str(error)
    return [
        {"id": "mock", "label": "Mock 演示（不调用模型）", "available": True, "reason": None},
        {"id": "codex", "label": "Codex CLI（真实模型）", "available": available, "reason": reason},
    ]
