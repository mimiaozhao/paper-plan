"""Identify the real Windows account, without trusting inherited USERPROFILE."""
import os


def runtime_account() -> str:
    if os.name == "nt":
        import ctypes
        size = ctypes.c_ulong(257)
        value = ctypes.create_unicode_buffer(size.value)
        if not ctypes.windll.advapi32.GetUserNameW(value, ctypes.byref(size)):
            raise OSError("无法确定计划服务的实际 Windows 运行账户。")
        return value.value
    import getpass
    return getpass.getuser()


def restricted_runtime() -> bool:
    return runtime_account().casefold().startswith("codexsandbox")


def require_dispatch_account() -> None:
    if os.environ.get("PLAN_PANEL_DISPATCH", "1") != "0" and restricted_runtime():
        raise RuntimeError("计划服务不能从 Codex 隔离账户启动：该账户无法投递到你的桌面对话。请由已信任的插件启动，或以当前桌面用户运行 start.cmd。")
