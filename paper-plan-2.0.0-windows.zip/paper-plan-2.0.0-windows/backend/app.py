"""Local visual plan editor API and production frontend host."""
from __future__ import annotations
import os
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from . import providers
from .bridge import register_bridge
from .domain import PlanValidationError, STRUCTURAL_CODES, compile_document, validate_document
from .models import ConfirmRequest, DocumentRequest, GenerateRequest, PlanDocument, PlanState, Run, RunRequest, SaveRequest, ValidationRequest
from .storage import NotFoundError, Store, VersionConflict, identifier, now

PROJECT_ROOT = Path(__file__).resolve().parent.parent

def error_detail(message: str, issues: list) -> dict:
    return {"message": message, "issues": [issue.model_dump(exclude_none=True) for issue in issues]}

def create_app(db_path: str | Path | None = None) -> FastAPI:
    database = db_path if db_path is not None else os.environ.get("PLAN_EDITOR_DB", str(PROJECT_ROOT / "data" / "plans.sqlite3"))
    store = Store(database)
    @asynccontextmanager
    async def lifespan(application: FastAPI):
        yield
        store.close()
    application = FastAPI(title="论文式计划", version="2.0.0", lifespan=lifespan)
    application.state.store = store
    application.add_middleware(TrustedHostMiddleware, allowed_hosts=["localhost", "127.0.0.1", "[::1]", "testserver"])
    application.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"], allow_methods=["GET", "POST", "PUT"], allow_headers=["Content-Type"])

    @application.middleware("http")
    async def local_writes(request: Request, call_next):
        origin = request.headers.get("origin")
        if request.method not in {"GET", "HEAD", "OPTIONS"} and origin is not None:
            if origin not in {str(request.base_url).rstrip("/"), "http://localhost:5173", "http://127.0.0.1:5173"}:
                return JSONResponse({"detail": "只允许本地同源面板修改计划。"}, status_code=403)
        return await call_next(request)

    def load(plan_id: str) -> PlanState:
        try:
            return store.get(plan_id)
        except NotFoundError as error:
            raise HTTPException(404, detail=str(error)) from error

    def structural_check(document: PlanDocument) -> None:
        issues = [issue for issue in validate_document(document) if issue.severity == "error" and issue.code in STRUCTURAL_CODES]
        if issues:
            raise HTTPException(422, detail=error_detail("计划结构无效，请修复后保存。", issues))

    @application.get("/api/health")
    def health():
        from .runtime_context import restricted_runtime
        return {"status": "ok", "service": "paper-plan", "version": "2.0.0", "bridge_protocol": 3, "pid": os.getpid(), "project_root": str(PROJECT_ROOT), "execution_context": "restricted" if restricted_runtime() else "desktop"}

    @application.get("/api/schema")
    def schema():
        return PlanDocument.model_json_schema()

    @application.get("/api/providers")
    def list_providers():
        return {"providers": providers.provider_status()}

    @application.get("/api/plans")
    def list_plans():
        return {"plans": store.list()}

    @application.post("/api/plans/generate", response_model=PlanState)
    def generate(payload: GenerateRequest):
        if not payload.request.strip():
            raise HTTPException(422, detail="请输入原始需求。")
        try:
            document = providers.get_provider(payload.provider).generate(payload.request)
            structural_check(document)
            return store.create(document)
        except providers.ProviderError as error:
            raise HTTPException(502, detail=str(error)) from error
        except HTTPException:
            raise
        except Exception as error:
            raise HTTPException(502, detail="计划生成提供方运行失败；没有使用 Mock 代替。") from error

    @application.post("/api/plans", response_model=PlanState)
    def import_plan(payload: DocumentRequest):
        document = payload.document.model_copy(deep=True, update={"id": identifier("plan"), "provenance": "import"})
        structural_check(document)
        return store.create(document)

    @application.get("/api/plans/{plan_id}", response_model=PlanState)
    def get_plan(plan_id: str):
        return load(plan_id)

    @application.put("/api/plans/{plan_id}", response_model=PlanState)
    def save_plan(plan_id: str, payload: SaveRequest):
        load(plan_id)
        if payload.document.id != plan_id:
            raise HTTPException(422, detail="文档 ID 必须与当前计划一致。")
        structural_check(payload.document)
        try:
            return store.save(plan_id, payload.document, payload.expected_version)
        except VersionConflict as error:
            raise HTTPException(409, detail={"message": str(error), "current_version": load(plan_id).version}) from error

    @application.post("/api/validate")
    def validate(payload: ValidationRequest):
        issues = validate_document(payload.document, payload.mode)
        return {"valid": not any(issue.severity == "error" for issue in issues), "issues": [issue.model_dump(exclude_none=True) for issue in issues]}

    @application.post("/api/compile")
    def compile_plan(payload: DocumentRequest):
        try:
            return compile_document(payload.document)
        except PlanValidationError as error:
            raise HTTPException(422, detail=error_detail(str(error), error.issues)) from error

    @application.post("/api/plans/{plan_id}/confirm", response_model=PlanState)
    def confirm_plan(plan_id: str, payload: ConfirmRequest):
        state = load(plan_id)
        if payload.expected_version != state.version:
            raise HTTPException(409, detail={"message": "版本已变化，请重新加载后再确认。", "current_version": state.version})
        issues = validate_document(state.document, "confirm")
        if any(issue.severity == "error" for issue in issues):
            raise HTTPException(422, detail=error_detail("计划尚不满足确认条件。", issues))
        try:
            return store.confirm(plan_id, payload.expected_version)
        except VersionConflict as error:
            raise HTTPException(409, detail={"message": str(error), "current_version": load(plan_id).version}) from error

    @application.get("/api/plans/{plan_id}/versions")
    def list_versions(plan_id: str):
        load(plan_id)
        return {"versions": store.versions(plan_id)}

    @application.post("/api/plans/{plan_id}/runs", response_model=Run)
    def execute_plan(plan_id: str, payload: RunRequest):
        if load(plan_id).binding is not None:
            raise HTTPException(409, detail="此计划已绑定当前对话，请通过同对话续接执行，不能发起独立 CLI 运行。")
        try:
            snapshot = store.snapshot(plan_id, payload.version_id)
        except NotFoundError as error:
            raise HTTPException(404, detail=str(error)) from error
        if not snapshot["confirmed"]:
            raise HTTPException(409, detail="仅可执行已确认的计划版本，请先确认该版本。")
        try:
            compiled = compile_document(snapshot["document"])
        except PlanValidationError as error:
            raise HTTPException(422, detail=error_detail(str(error), error.issues)) from error
        output, error_message, status = "", None, "completed"
        try:
            output = providers.get_provider(payload.provider).execute(compiled.text)
        except providers.ProviderError as error:
            status, error_message = "failed", str(error)
        except Exception as error:
            status, error_message = "failed", f"执行提供方运行失败（{type(error).__name__}）；未使用 Mock 代替。"
        run = Run(id=identifier("run"), plan_id=plan_id, version_id=payload.version_id, version=snapshot["version"], provider=payload.provider, is_mock=payload.provider == "mock", status=status, output=output, error=error_message, created_at=now())
        store.add_run(run)
        return run

    @application.get("/api/plans/{plan_id}/runs")
    def list_runs(plan_id: str):
        load(plan_id)
        return {"runs": store.runs(plan_id)}

    register_bridge(application, store, structural_check)

    frontend = PROJECT_ROOT / "frontend" / "dist"
    @application.get("/{asset_path:path}", include_in_schema=False)
    def frontend_file(asset_path: str):
        if asset_path.startswith("api/") or asset_path == "api":
            raise HTTPException(404, detail="API 不存在。")
        candidate = (frontend / asset_path).resolve()
        if not candidate.is_relative_to(frontend.resolve()):
            raise HTTPException(404, detail="文件不存在。")
        if asset_path and candidate.is_file():
            return FileResponse(candidate)
        index = frontend / "index.html"
        if index.is_file():
            return FileResponse(index)
        return HTMLResponse("<html lang='zh-CN'><meta charset='utf-8'><title>可视化计划调整器</title><body><h1>服务已启动</h1><p>请构建前端后刷新页面，或使用开发服务器。</p></body></html>", status_code=503)
    return application

app = create_app()
