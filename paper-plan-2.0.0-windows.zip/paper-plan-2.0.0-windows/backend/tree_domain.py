"""Ordered outline validation, Markdown capture and deterministic execution input."""
from __future__ import annotations
import re
import uuid
from collections import Counter, defaultdict
from .models import CompileResult, CompileSegment, Issue, PlanDocument, TreeNode

TREE_CODES = {"tree_structure", "tree_dependency", "duplicate_id", "missing_id"}


def ordered_tree(document: PlanDocument) -> list[tuple[TreeNode, str, int]]:
    children: dict[str | None, list[TreeNode]] = defaultdict(list)
    for node in document.tree:
        children[node.parent_id].append(node)
    result = []
    # Iterative traversal also handles deeply nested imported outlines safely.
    roots = sorted(children[None], key=lambda n: (n.order, n.id))
    stack = [(n, str(i), 0) for i, n in reversed(list(enumerate(roots, 1)))]
    visited = set()
    while stack:
        node, number, depth = stack.pop()
        if node.id in visited:
            continue
        visited.add(node.id)
        result.append((node, number, depth))
        siblings = sorted(children[node.id], key=lambda n: (n.order, n.id))
        stack.extend((child, f"{number}.{i}", depth + 1) for i, child in reversed(list(enumerate(siblings, 1))))
    return result


def leaf_ids(document: PlanDocument) -> list[str]:
    parents = {n.parent_id for n in document.tree}
    return [n.id for n, _, _ in ordered_tree(document) if n.id not in parents]


def validate_tree(document: PlanDocument, mode: str = "draft") -> list[Issue]:
    issues = []
    def add(code, message, node=None, field="tree", severity="error"):
        issues.append(Issue(code=code, message=message, node_id=node, field=field, severity=severity))
    if document.nodes or document.edges or document.output_outline:
        add("tree_structure", "v2 计划只使用标题树；不能同时包含旧版任务图或输出大纲。")
    for field in ("title", "goal"):
        if not getattr(document, field).strip():
            add("missing_field", "计划名称和目标不能为空。", field=field)
    if not document.tree:
        add("missing_field", "至少需要一个标题。")
    ids = {n.id for n in document.tree}
    if len(ids) != len(document.tree) or "" in ids:
        add("duplicate_id", "标题 ID 必须非空且唯一。")
    by_id = {n.id: n for n in document.tree}
    sibling_orders = set()
    for n in document.tree:
        if not n.title.strip():
            add("missing_field", "标题不能为空。", n.id, "title")
        if n.parent_id is not None and n.parent_id not in ids:
            add("tree_structure", "父标题不存在。", n.id)
        key = (n.parent_id, n.order)
        if key in sibling_orders:
            add("tree_structure", "同级标题的顺序不能重复。", n.id)
        sibling_orders.add(key)
        seen = {n.id}
        parent = n.parent_id
        while parent in by_id:
            if parent in seen:
                add("tree_structure", "标题不能成为自身或后代的子项。", n.id)
                break
            seen.add(parent)
            parent = by_id[parent].parent_id
        if n.id in n.depends_on or any(d not in ids for d in n.depends_on):
            add("tree_dependency", "依赖不存在或指向自身。", n.id)
    # Dependencies apply only to executable leaves; parent requirements are inherited.
    parents = {n.parent_id for n in document.tree}
    for n in document.tree:
        if n.depends_on and (n.id in parents or any(d in parents for d in n.depends_on)):
            add("tree_dependency", "前置依赖只能连接最末级任务。", n.id)
    pending = {n.id: set(n.depends_on) for n in document.tree}
    while pending:
        ready = {key for key, deps in pending.items() if not deps}
        if not ready:
            add("tree_dependency", "前置依赖存在循环。")
            break
        pending = {key: deps - ready for key, deps in pending.items() if key not in ready}
    for assumption in document.assumptions:
        if assumption.status == "pending":
            add("pending_assumption", f"待确认：{assumption.text}", field="assumptions", severity="error" if mode == "confirm" else "warning")
    for constraint in document.constraints:
        if not constraint.text.strip():
            add("missing_field", "全局约束内容不能为空。", field="constraints")
    return issues


def compile_tree(document: PlanDocument) -> CompileResult:
    from .domain import PlanValidationError, semantic_hash
    issues = validate_tree(document)
    if any(i.severity == "error" for i in issues):
        raise PlanValidationError(issues)
    segments = []
    def add(kind, identity, field, text):
        segments.append(CompileSegment(id=f"{kind}:{identity}:{field}", source_type=kind, source_id=identity, field=field, text=text))
    add("global", document.id, "instructions", "执行已确认的论文式计划。父标题组织阶段，其说明、产出要求与验收条件向后代传递；最末级标题为可执行任务。默认按目录顺序工作，依赖未完成不能启动。必要调序须先向用户说明原因并通过节点进度接口记录 adjustment_reason。改变目标、删除任务或改变验收条件时停止执行，交回用户重新确认。\n在原对话执行，逐叶节点回报 running/completed/failed 和真实产出、验证依据；不能把开始或排队当作完成。按本目录汇报最终结果。")
    add("global", document.id, "goal", f"# {document.title}\n\n目标：{document.goal}\n\n原始需求：{document.original_request}")
    if document.constraints:
        add("global", document.id, "constraints", "全局要求\n" + "\n".join(f"- {c.text}" for c in document.constraints))
    if document.assumptions:
        add("global", document.id, "assumptions", "假设\n" + "\n".join(f"- [{a.status}] {a.text}" for a in document.assumptions))
    parents = {n.parent_id for n in document.tree}
    for n, number, depth in ordered_tree(document):
        text = f"{'#' * min(depth + 2, 6)} {number} {n.title}\n节点 ID：{n.id}；{'阶段' if n.id in parents else '执行任务'}"
        if n.details:
            text += "\n\n" + n.details
        if n.output:
            text += "\n\n预期产出：" + n.output
        if n.acceptance_criteria:
            text += "\n\n验收条件：\n" + "\n".join("- " + c for c in n.acceptance_criteria)
        if n.depends_on:
            text += "\n\n前置依赖：" + ", ".join(n.depends_on)
        add("node", n.id, "details", text)
    return CompileResult(text="\n\n".join(s.text for s in segments) + "\n", semantic_hash=semantic_hash(document), template_version="paper-plan/2.0", segments=segments, issues=issues)


def parse_proposed_plan(message: str) -> PlanDocument | None:
    """Parse only a complete formal block, ignoring fenced examples and ordinary prose."""
    blocks = []
    active = None
    fence = None
    for line in message.splitlines():
        stripped = line.strip()
        marker = re.match(r"^(`{3,}|~{3,})", stripped)
        if marker:
            token = marker[1]
            if fence is None:
                fence = token
            elif token[0] == fence[0] and len(token) >= len(fence):
                fence = None
            if active is not None:
                active.append(line)
            continue
        if fence is None and stripped == "<proposed_plan>":
            if active is not None:
                raise ValueError("正式计划块不能嵌套。")
            active = []
        elif fence is None and stripped == "</proposed_plan>" and active is not None:
            blocks.append(active)
            active = None
        elif active is not None:
            active.append(line)
    if not blocks:
        return None
    if len(blocks) != 1 or active is not None:
        raise ValueError("每轮应包含一个完整正式计划。")
    title = ""
    preamble = []
    nodes = []
    stack = []
    counts = Counter()
    fence = None
    for line in blocks[0]:
        marker = re.match(r"^\s*(`{3,}|~{3,})", line)
        in_fence = fence is not None
        if marker:
            token = marker[1]
            if fence is None:
                fence = token
            elif token[0] == fence[0] and len(token) >= len(fence):
                fence = None
        heading = None if marker or in_fence else re.match(r"^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$", line)
        if heading and len(heading[1]) == 1 and not title and not nodes:
            title = heading[2]
            continue
        if heading:
            depth = len(heading[1])
            while stack and stack[-1][0] >= depth:
                stack.pop()
            parent = stack[-1][1] if stack else None
            text = re.sub(r"^\d+(?:\.\d+)*(?:[.、．])?\s+", "", heading[2])
            node = TreeNode(id="n_" + uuid.uuid4().hex, parent_id=parent, order=counts[parent], title=text)
            counts[parent] += 1
            nodes.append(node)
            stack.append((depth, node.id))
        elif nodes:
            nodes[-1].details += line + "\n"
        else:
            preamble.append(line)
    if not title or not nodes:
        raise ValueError("正式计划需要一个一级总标题和至少一个二级任务标题。")
    for node in nodes:
        node.details = node.details.strip()
    intro = "\n".join(preamble).strip()
    return PlanDocument(id="plan_" + uuid.uuid4().hex, schema_version=2, title=title, goal=intro or title, original_request=intro or title, provenance="conversation", tree=nodes)
