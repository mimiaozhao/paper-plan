"""Visual plan editor service."""
