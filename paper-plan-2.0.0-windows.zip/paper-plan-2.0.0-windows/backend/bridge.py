"""Same-thread bridge routes. Request/claim never launch a standalone model run."""
from __future__ import annotations
from typing import Annotated, Callable
from fastapi import APIRouter, HTTPException, Path, Request
from .domain import PlanValidationError
from .models import CandidateRequest, ClaimRequest, CompleteRequest, Continuation, ContinuationRequest, PlanRevision, PlanState, ProgressRequest, RevisionRequest, ThreadPlanRequest, ThreadPlanView, ThreadSaveRequest
from .storage import ExecutionContextError, NotFoundError, Store, VersionConflict, identifier, make_binding

ThreadId = Annotated[str, Path(pattern=r"^[A-Za-z0-9_-]{1,128}$")]

def bridge_call(operation: Callable):
    try:
        return operation()
    except NotFoundError as error:
        raise HTTPException(404, detail=str(error)) from error
    except VersionConflict as error:
        raise HTTPException(409, detail={"message": str(error)}) from error
    except PlanValidationError as error:
        raise HTTPException(422, detail={"message": str(error), "issues": [issue.model_dump(exclude_none=True) for issue in error.issues]}) from error

def register_bridge(application, store: Store, structural_check: Callable) -> None:
    router = APIRouter(prefix="/api/threads", tags=["conversation bridge"])

    @router.get("/{thread_id}/plan", response_model=ThreadPlanView)
    def get_thread_plan(thread_id: ThreadId):
        return {"state": store.thread_plan(thread_id)}

    @router.get("/{thread_id}/outline")
    def get_outline(thread_id: ThreadId):
        with store.lock:
            runtime = store.runtime(thread_id)
            return {"state": store.thread_plan(thread_id), "runtime": runtime, "sync": store.capture_status(thread_id, runtime["turn_id"]) if runtime else None, "candidates": store.candidates(thread_id), "continuations": store.continuations(thread_id), "revisions": store.revisions(thread_id)}

    @router.post('/{thread_id}/revisions',response_model=PlanRevision)
    def request_revision(thread_id: ThreadId,payload: RevisionRequest):
        return bridge_call(lambda:store.request_revision(thread_id,payload.expected_version,payload.version_id,payload.notes))

    @router.get('/{thread_id}/revisions/{revision_id}')
    def read_revision(thread_id: ThreadId,revision_id: str):
        return bridge_call(lambda:store.revision_snapshot(thread_id,revision_id))

    @router.post('/{thread_id}/revisions/{revision_id}/cancel',response_model=PlanRevision)
    def cancel_revision(thread_id: ThreadId,revision_id: str):
        return bridge_call(lambda:store.cancel_revision(thread_id,revision_id))

    @router.post('/{thread_id}/revisions/{revision_id}/dispatch',response_model=PlanRevision)
    def dispatch_revision(thread_id: ThreadId,revision_id: str):
        item,send = bridge_call(lambda:store.begin_revision_dispatch(thread_id,revision_id))
        if not send:
            return item
        try:
            from .dispatcher import dispatch_to_codex
            result = dispatch_to_codex(thread_id,item.message)
            if result.get('status') not in {'queued','manual'}:
                raise ValueError('invalid dispatch result')
        except Exception:
            result = {'status':'manual','error':'再修改请求未能投递，请复制提问指令到原对话。'}
        return bridge_call(lambda:store.finish_revision_dispatch(thread_id,revision_id,result['status'],result.get('error')))

    @router.post("/{thread_id}/candidates/{turn_id}")
    def candidate(thread_id: ThreadId, turn_id: str, payload: CandidateRequest):
        return bridge_call(lambda: store.resolve_candidate(thread_id, turn_id, payload.expected_version, payload.accept))

    @router.post("/{thread_id}/continuations/{continuation_id}/cancel")
    def cancel(thread_id: ThreadId, continuation_id: str):
        return bridge_call(lambda: store.cancel_continuation(thread_id, continuation_id))

    @router.post("/{thread_id}/continuations/{continuation_id}/nodes/{node_id}")
    def report_node(thread_id: ThreadId, continuation_id: str, node_id: str, payload: ProgressRequest):
        return bridge_call(lambda: store.report_progress(thread_id, continuation_id, node_id, payload))

    @router.post("/{thread_id}/plan", response_model=PlanState)
    def create_thread_plan(thread_id: ThreadId, payload: ThreadPlanRequest):
        document = payload.document.model_copy(deep=True, update={"id": identifier("plan"), "provenance": "conversation"})
        structural_check(document)
        binding = make_binding(thread_id, payload.thread_title, payload.task_brief, payload.confirmed_decisions)
        return bridge_call(lambda: store.create_bound(document, binding))

    @router.put("/{thread_id}/plan", response_model=PlanState)
    def save_thread_plan(thread_id: ThreadId, payload: ThreadSaveRequest):
        document = payload.document.model_copy(deep=True, update={"provenance": "conversation"})
        structural_check(document)
        binding = make_binding(thread_id, payload.thread_title, payload.task_brief, payload.confirmed_decisions)
        return bridge_call(lambda: store.save_bound(document, payload.expected_version, binding))

    @router.get("/{thread_id}/confirmed-plan")
    def confirmed_plan(thread_id: ThreadId, version_id: str | None = None):
        return bridge_call(lambda: store.confirmed_thread_plan(thread_id, version_id))

    @router.get("/{thread_id}/continuations")
    def continuations(thread_id: ThreadId):
        return {"continuations": store.continuations(thread_id)}

    @router.post("/{thread_id}/continuations", response_model=Continuation)
    def request_continuation(thread_id: ThreadId, payload: ContinuationRequest):
        return bridge_call(lambda: store.request_continuation(thread_id, payload.expected_version, payload.version_id))

    @router.post("/{thread_id}/continuations/{continuation_id}/claim")
    def claim_continuation(thread_id: ThreadId, continuation_id: str, payload: ClaimRequest):
        def claim():
            try:
                return store.claim_continuation(thread_id, continuation_id, payload.claimant_id)
            except ExecutionContextError as error:
                store.record_claim_blocked(thread_id, continuation_id, error)
                raise HTTPException(409, detail={"message": str(error), "code": "plan_mode" if error.waiting_for_mode else "hook_event_missing"}) from error
        return bridge_call(claim)

    @router.post("/{thread_id}/continuations/{continuation_id}/complete", response_model=Continuation)
    def complete_continuation(thread_id: ThreadId, continuation_id: str, payload: CompleteRequest):
        return bridge_call(lambda: store.complete_continuation(thread_id, continuation_id, payload.claim_token, payload.status, payload.output, payload.error))

    @router.post("/{thread_id}/continuations/{continuation_id}/dispatch", response_model=Continuation)
    def dispatch_continuation(thread_id: ThreadId, continuation_id: str, request: Request):
        origin = request.headers.get("origin")
        allowed_origins = {str(request.base_url).rstrip("/"), "http://localhost:5173", "http://127.0.0.1:5173"}
        if origin is not None and origin not in allowed_origins:
            raise HTTPException(403, detail="续接消息只能从本地同源计划面板投递。")
        continuation, should_send = bridge_call(lambda: store.begin_dispatch(thread_id, continuation_id))
        if not should_send:
            return continuation
        try:
            from . import dispatcher
            result = dispatcher.dispatch_to_codex(thread_id, continuation.message)
            if not isinstance(result, dict) or result.get("status") not in ("queued", "manual"):
                raise ValueError("invalid dispatcher result")
            status, error = result["status"], result.get("error")
        except Exception:
            status, error = "manual", "未能自动投递到当前对话，请复制续接消息并在此对话发送。未标记为执行成功。"
        return bridge_call(lambda: store.finish_dispatch(thread_id, continuation_id, status, error))

    application.include_router(router)
