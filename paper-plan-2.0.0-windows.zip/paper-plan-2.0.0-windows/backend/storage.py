"""Transactional SQLite plans, immutable snapshots, and same-chat continuations."""
from __future__ import annotations
import hashlib
import hmac
import json
import secrets
import sqlite3
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from .domain import compile_document, semantic_hash
from .models import Continuation, NodeProgress, PlanDocument, PlanRevision, PlanState, Run, ThreadBinding

def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")

def identifier(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"

class NotFoundError(LookupError):
    pass

class VersionConflict(ValueError):
    pass

class ExecutionContextError(VersionConflict):
    def __init__(self, message: str, waiting_for_mode: bool = False):
        super().__init__(message)
        self.waiting_for_mode = waiting_for_mode

class LockedFieldError(VersionConflict):
    pass

def make_binding(thread_id: str, thread_title: str, task_brief: str, decisions: list[str]) -> ThreadBinding:
    context = json.dumps({"task_brief": task_brief, "confirmed_decisions": decisions}, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return ThreadBinding(thread_id=thread_id, thread_title=thread_title, task_brief=task_brief, confirmed_decisions=decisions, context_revision=hashlib.sha256(context.encode("utf-8")).hexdigest(), updated_at=now())

def check_agent_locks(previous: PlanDocument, proposed: PlanDocument) -> None:
    constraints = {item.id: item for item in proposed.constraints}
    for old in previous.constraints:
        if old.locked:
            new = constraints.get(old.id)
            if new is None or new.text != old.text or not new.locked:
                raise LockedFieldError(f"代理不能更改、解锁或删除锁定约束「{old.id}」。请由用户在计划面板修改。")
    nodes = {item.id: item for item in proposed.nodes}
    for old in previous.nodes:
        if not old.locked_fields:
            continue
        new = nodes.get(old.id)
        if new is None:
            raise LockedFieldError(f"代理不能删除含锁定字段的节点「{old.id}」。")
        if not set(old.locked_fields).issubset(new.locked_fields):
            raise LockedFieldError(f"代理不能解除节点「{old.id}」的已有字段锁定。")
        for field in old.locked_fields:
            if getattr(old, field) != getattr(new, field):
                raise LockedFieldError(f"代理不能更改节点「{old.id}」的锁定字段「{field}」。请由用户在计划面板修改。")

class Store:
    def __init__(self, db_path: str | Path):
        path = str(db_path)
        if path != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path, check_same_thread=False)
        self.connection.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.connection.execute("PRAGMA foreign_keys = ON")
        self.connection.execute("PRAGMA journal_mode = WAL")
        self.connection.executescript("""
        CREATE TABLE IF NOT EXISTS plans (
            id TEXT PRIMARY KEY, document TEXT NOT NULL, version INTEGER NOT NULL,
            semantic_hash TEXT NOT NULL, confirmed INTEGER NOT NULL,
            version_id TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS versions (
            id TEXT PRIMARY KEY, plan_id TEXT NOT NULL REFERENCES plans(id),
            version INTEGER NOT NULL, document TEXT NOT NULL, semantic_hash TEXT NOT NULL,
            confirmed INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL,
            UNIQUE(plan_id, version)
        );
        CREATE TABLE IF NOT EXISTS runs (
            id TEXT PRIMARY KEY, plan_id TEXT NOT NULL REFERENCES plans(id),
            version_id TEXT NOT NULL REFERENCES versions(id), payload TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS thread_bindings (
            thread_id TEXT PRIMARY KEY, plan_id TEXT NOT NULL UNIQUE REFERENCES plans(id),
            binding TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS continuations (
            id TEXT PRIMARY KEY, thread_id TEXT NOT NULL REFERENCES thread_bindings(thread_id),
            plan_id TEXT NOT NULL REFERENCES plans(id), version_id TEXT NOT NULL REFERENCES versions(id),
            status TEXT NOT NULL, payload TEXT NOT NULL, claimant_id TEXT, claim_token TEXT,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE UNIQUE INDEX IF NOT EXISTS active_continuation_version
            ON continuations(thread_id, version_id) WHERE status IN ('pending', 'running');
        CREATE TABLE IF NOT EXISTS thread_runtime (
            thread_id TEXT PRIMARY KEY, permission_mode TEXT NOT NULL,
            turn_id TEXT NOT NULL, updated_at TEXT NOT NULL, last_error TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS plan_captures (
            thread_id TEXT NOT NULL, turn_id TEXT NOT NULL, base_version INTEGER NOT NULL,
            message_hash TEXT, status TEXT NOT NULL DEFAULT 'started', document TEXT,
            error TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
            PRIMARY KEY (thread_id, turn_id)
        );
        CREATE TABLE IF NOT EXISTS plan_revisions (
            id TEXT PRIMARY KEY, thread_id TEXT NOT NULL REFERENCES thread_bindings(thread_id),
            plan_id TEXT NOT NULL REFERENCES plans(id), version_id TEXT NOT NULL REFERENCES versions(id),
            status TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE UNIQUE INDEX IF NOT EXISTS active_revision_thread
            ON plan_revisions(thread_id) WHERE status IN ('pending','discussing');
        """)
        self.connection.execute("BEGIN IMMEDIATE")
        capture_columns = {row[1] for row in self.connection.execute("PRAGMA table_info(plan_captures)")}
        for name, declaration in (("source_kind", "TEXT"), ("source_item_id", "TEXT"), ("revision_id", "TEXT")):
            if name not in capture_columns:
                self.connection.execute(f"ALTER TABLE plan_captures ADD COLUMN {name} {declaration}")
        self.connection.commit()

    def close(self) -> None:
        with self.lock:
            self.connection.close()

    def state(self, row: sqlite3.Row) -> PlanState:
        binding = self.connection.execute("SELECT binding FROM thread_bindings WHERE plan_id=?", (row["id"],)).fetchone()
        return PlanState(document=PlanDocument.model_validate_json(row["document"]), version=row["version"], semantic_hash=row["semantic_hash"], confirmed=bool(row["confirmed"]), version_id=row["version_id"], updated_at=row["updated_at"], binding=ThreadBinding.model_validate_json(binding["binding"]) if binding else None)

    def _get(self, plan_id: str) -> sqlite3.Row:
        row = self.connection.execute("SELECT * FROM plans WHERE id=?", (plan_id,)).fetchone()
        if row is None:
            raise NotFoundError("计划不存在。")
        return row

    def get(self, plan_id: str) -> PlanState:
        with self.lock:
            return self.state(self._get(plan_id))

    def list(self) -> list[dict]:
        with self.lock:
            return [{"id": row["id"], "title": json.loads(row["document"])["title"], "version": row["version"], "confirmed": bool(row["confirmed"]), "updated_at": row["updated_at"]} for row in self.connection.execute("SELECT * FROM plans ORDER BY updated_at DESC, id")]

    def _create(self, document: PlanDocument) -> None:
        created = now()
        version_id = identifier("version")
        hash_value = semantic_hash(document)
        encoded = document.model_dump_json()
        self.connection.execute("INSERT INTO plans VALUES (?, ?, ?, ?, ?, ?, ?)", (document.id, encoded, 1, hash_value, 0, version_id, created))
        self.connection.execute("INSERT INTO versions VALUES (?, ?, ?, ?, ?, ?, ?)", (version_id, document.id, 1, encoded, hash_value, 0, created))

    def create(self, document: PlanDocument) -> PlanState:
        with self.lock, self.connection:
            self._create(document)
            return self.state(self._get(document.id))

    def _save(self, plan_id: str, document: PlanDocument, expected_version: int) -> PlanState:
        row = self._get(plan_id)
        if document.schema_version == 2 or json.loads(row["document"]).get("schema_version") == 2:
            self._ensure_editable(plan_id)
        if row["version"] != expected_version:
            raise VersionConflict(f"当前版本为 v{row['version']}，请重新加载后再保存。")
        hash_value = semantic_hash(document)
        updated = now()
        encoded = document.model_dump_json()
        if hash_value == row["semantic_hash"]:
            self.connection.execute("UPDATE plans SET document=?, updated_at=? WHERE id=?", (encoded, updated, plan_id))
        else:
            version = row["version"] + 1
            version_id = identifier("version")
            self.connection.execute("INSERT INTO versions VALUES (?, ?, ?, ?, ?, ?, ?)", (version_id, plan_id, version, encoded, hash_value, 0, updated))
            self.connection.execute("UPDATE plans SET document=?, version=?, semantic_hash=?, confirmed=0, version_id=?, updated_at=? WHERE id=?", (encoded, version, hash_value, version_id, updated, plan_id))
            for continuation_row in self.connection.execute("SELECT * FROM continuations WHERE plan_id=? AND status='pending'", (plan_id,)).fetchall():
                continuation = self._model(continuation_row).model_copy(update={"status": "superseded", "updated_at": updated})
                self._write_continuation(continuation)
        return self.state(self._get(plan_id))

    def save(self, plan_id: str, document: PlanDocument, expected_version: int) -> PlanState:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            return self._save(plan_id, document, expected_version)

    def confirm(self, plan_id: str, expected_version: int) -> PlanState:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            row = self._get(plan_id)
            if row["version"] != expected_version:
                raise VersionConflict(f"当前版本为 v{row['version']}，请重新加载后再确认。")
            self.connection.execute("UPDATE plans SET confirmed=1, updated_at=? WHERE id=?", (now(), plan_id))
            self.connection.execute("UPDATE versions SET confirmed=1 WHERE id=?", (row["version_id"],))
            return self.state(self._get(plan_id))

    def versions(self, plan_id: str) -> list[dict]:
        with self.lock:
            self._get(plan_id)
            return [{"id": row["id"], "version": row["version"], "confirmed": bool(row["confirmed"]), "created_at": row["created_at"], "semantic_hash": row["semantic_hash"], "document": json.loads(row["document"])} for row in self.connection.execute("SELECT * FROM versions WHERE plan_id=? ORDER BY version DESC", (plan_id,))]

    def snapshot(self, plan_id: str, version_id: str) -> dict:
        with self.lock:
            self._get(plan_id)
            row = self.connection.execute("SELECT * FROM versions WHERE plan_id=? AND id=?", (plan_id, version_id)).fetchone()
            if row is None:
                raise NotFoundError("该计划版本不存在。")
            return {"document": PlanDocument.model_validate_json(row["document"]), "version": row["version"], "id": row["id"], "confirmed": bool(row["confirmed"])}

    def add_run(self, run: Run) -> None:
        with self.lock, self.connection:
            self.connection.execute("INSERT INTO runs VALUES (?, ?, ?, ?, ?)", (run.id, run.plan_id, run.version_id, run.model_dump_json(), run.created_at))

    def runs(self, plan_id: str) -> list[Run]:
        with self.lock:
            self._get(plan_id)
            return [Run.model_validate_json(row["payload"]) for row in self.connection.execute("SELECT * FROM runs WHERE plan_id=? ORDER BY created_at DESC, id", (plan_id,))]

    def _thread_row(self, thread_id: str) -> sqlite3.Row:
        binding = self.connection.execute("SELECT * FROM thread_bindings WHERE thread_id=?", (thread_id,)).fetchone()
        if binding is None:
            raise NotFoundError("当前对话尚未绑定计划。")
        return self._get(binding["plan_id"])

    def thread_plan(self, thread_id: str) -> PlanState | None:
        with self.lock:
            binding = self.connection.execute("SELECT * FROM thread_bindings WHERE thread_id=?", (thread_id,)).fetchone()
            return self.state(self._get(binding["plan_id"])) if binding else None

    def create_bound(self, document: PlanDocument, binding: ThreadBinding) -> PlanState:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            if self.connection.execute("SELECT 1 FROM thread_bindings WHERE thread_id=?", (binding.thread_id,)).fetchone():
                raise VersionConflict("当前对话已经绑定计划；请读取现有计划后更新，不能覆盖。")
            self._create(document)
            self.connection.execute("INSERT INTO thread_bindings VALUES (?, ?, ?)", (binding.thread_id, document.id, binding.model_dump_json()))
            return self.state(self._get(document.id))

    def save_bound(self, document: PlanDocument, expected_version: int, binding: ThreadBinding) -> PlanState:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            row = self._thread_row(binding.thread_id)
            if row["version"] != expected_version:
                raise VersionConflict(f"当前版本为 v{row['version']}，请重新读取再更新。")
            if row["id"] != document.id:
                raise VersionConflict("代理文档 ID 与当前对话绑定的计划不一致。")
            check_agent_locks(PlanDocument.model_validate_json(row["document"]), document)
            self._save(document.id, document, expected_version)
            self.connection.execute("UPDATE thread_bindings SET binding=? WHERE thread_id=?", (binding.model_dump_json(), binding.thread_id))
            return self.state(self._get(document.id))

    def _current_confirmed(self, thread_id: str, version_id: str | None = None, expected_version: int | None = None) -> PlanState:
        state = self.state(self._thread_row(thread_id))
        if not state.confirmed:
            raise VersionConflict("当前对话的最新计划尚未确认，请先确认当前版本。")
        if version_id is not None and state.version_id != version_id:
            raise VersionConflict("所请求的确认版本已经过期，请重新读取当前计划。")
        if expected_version is not None and state.version != expected_version:
            raise VersionConflict("计划版本已变化，请重新读取当前计划。")
        return state

    def confirmed_thread_plan(self, thread_id: str, version_id: str | None = None) -> dict:
        with self.lock, self.connection:
            self.connection.execute("BEGIN")
            state = self._current_confirmed(thread_id, version_id)
            document = self.snapshot(state.document.id, state.version_id)["document"]
            return {"state": state, "document": document, "compiled": compile_document(document)}

    def revisions(self, thread_id: str) -> list[PlanRevision]:
        with self.lock:
            return [PlanRevision.model_validate_json(row['payload']) for row in self.connection.execute("SELECT payload FROM plan_revisions WHERE thread_id=? ORDER BY created_at DESC,id", (thread_id,))]

    def active_revision(self, thread_id: str) -> PlanRevision | None:
        with self.lock:
            row = self.connection.execute("SELECT payload FROM plan_revisions WHERE thread_id=? AND status IN ('pending','discussing')", (thread_id,)).fetchone()
            return PlanRevision.model_validate_json(row['payload']) if row else None

    def _revision(self, thread_id: str, revision_id: str) -> PlanRevision:
        row = self.connection.execute("SELECT * FROM plan_revisions WHERE id=?", (revision_id,)).fetchone()
        if row is None:
            raise NotFoundError("再修改请求不存在。")
        if row['thread_id'] != thread_id:
            raise VersionConflict("再修改请求不属于当前对话。")
        return PlanRevision.model_validate_json(row['payload'])

    def _write_revision(self, revision: PlanRevision) -> None:
        self.connection.execute("UPDATE plan_revisions SET status=?,payload=?,updated_at=? WHERE id=?", (revision.status, revision.model_dump_json(), revision.updated_at, revision.id))

    def request_revision(self, thread_id: str, expected_version: int, version_id: str, notes: str = "") -> PlanRevision:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            state = self.state(self._thread_row(thread_id))
            if state.version != expected_version or state.version_id != version_id:
                raise VersionConflict("目录版本已变化，请保存并重新发送再修改请求。")
            if state.document.schema_version != 2:
                raise VersionConflict("再修改功能适用于论文式目录计划。")
            self._ensure_editable(state.document.id)
            previous = self.active_revision(thread_id)
            if previous and previous.version_id == version_id and previous.notes == notes:
                return previous
            if previous:
                self._write_revision(previous.model_copy(update={"status":"superseded","updated_at":now()}))
            revision_id = identifier('revision')
            root = Path(__file__).resolve().parents[1]
            message = (f"请使用 plan-panel 技能，对我在右侧编辑后的计划进行再修改。thread_id={thread_id}；revision_id={revision_id}；version_id={version_id}；version={state.version}。"
                       f"先读取技能 {(root/'skills/plan-panel/SKILL.md').as_posix()}，通过 get_plan_revision 读取此请求的不可变目录快照；若工具尚未加载，运行本地桥接脚本 {(root/'scripts/bridge.py').as_posix()} revision --thread {thread_id} --revision-id {revision_id}。"
                       "这是澄清与重新规划请求，不是执行请求。先检查宿主协作模式；若不是 Plan 模式，仅提示我手动切换后继续，不能声称已自动切换。"
                       "在计划模式下先根据修改后的目录提出2–3个有实质影响的问题，等待我回答后继续澄清。需求明确后再输出一份完整正式计划，同步右侧让我重新确认。保留我的要求和锁定约束，不执行项目任务，不创建新对话；请求若已取消或被替代则停止。")
            item = PlanRevision(id=revision_id,thread_id=thread_id,plan_id=state.document.id,version_id=version_id,version=state.version,semantic_hash=state.semantic_hash,notes=notes,message=message,created_at=now(),updated_at=now())
            self.connection.execute("INSERT INTO plan_revisions VALUES (?,?,?,?,?,?,?,?)", (item.id,thread_id,item.plan_id,version_id,item.status,item.model_dump_json(),item.created_at,item.updated_at))
            return item

    def revision_snapshot(self, thread_id: str, revision_id: str) -> dict:
        with self.lock:
            item = self._revision(thread_id,revision_id)
            if item.status not in {'pending','discussing'}:
                raise VersionConflict("此再修改请求已结束、取消或被替代，请勿继续。")
            snapshot = self.snapshot(item.plan_id,item.version_id)
            state = self.thread_plan(thread_id)
            return {'revision':item,'document':snapshot['document'],'current_version':state.version,'draft_changed':state.version_id != item.version_id}

    def begin_revision_dispatch(self, thread_id: str, revision_id: str) -> tuple[PlanRevision,bool]:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            item = self._revision(thread_id,revision_id)
            if item.status not in {'pending','discussing'}:
                raise VersionConflict("此再修改请求已结束、取消或被替代。")
            if item.status == 'discussing' or item.delivery_status in {'sending','queued'}:
                return item,False
            state = self.state(self._thread_row(thread_id))
            if state.version_id != item.version_id:
                raise VersionConflict("目录又有修改，请按最新版本重新发送。")
            self._ensure_editable(item.plan_id)
            item = item.model_copy(update={'delivery_status':'sending','delivery_error':None,'updated_at':now()})
            self._write_revision(item)
            return item,True

    def finish_revision_dispatch(self, thread_id: str, revision_id: str, status: str, error: str | None) -> PlanRevision:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            item = self._revision(thread_id,revision_id)
            if item.delivery_status == 'sending':
                item = item.model_copy(update={'delivery_status':status,'delivery_error':error,'updated_at':now()})
                self._write_revision(item)
            return item

    def cancel_revision(self, thread_id: str, revision_id: str) -> PlanRevision:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            item = self._revision(thread_id,revision_id)
            if item.status == 'cancelled':
                return item
            if item.status not in {'pending','discussing'}:
                raise VersionConflict("此再修改请求已经结束。")
            item = item.model_copy(update={'status':'cancelled','updated_at':now()})
            self._write_revision(item)
            return item

    @staticmethod
    def _model(row: sqlite3.Row) -> Continuation:
        return Continuation.model_validate_json(row["payload"])

    def _continuation_row(self, thread_id: str, continuation_id: str) -> sqlite3.Row:
        row = self.connection.execute("SELECT * FROM continuations WHERE id=?", (continuation_id,)).fetchone()
        if row is None:
            raise NotFoundError("续接请求不存在。")
        if row["thread_id"] != thread_id:
            raise VersionConflict("续接请求不属于当前对话。")
        return row

    def _write_continuation(self, continuation: Continuation) -> None:
        self.connection.execute("UPDATE continuations SET status=?, payload=?, updated_at=? WHERE id=?", (continuation.status, continuation.model_dump_json(), continuation.updated_at, continuation.id))

    def continuations(self, thread_id: str) -> list[Continuation]:
        with self.lock:
            return [self._model(row) for row in self.connection.execute("SELECT * FROM continuations WHERE thread_id=? ORDER BY created_at DESC, id", (thread_id,))]

    def request_continuation(self, thread_id: str, expected_version: int, version_id: str) -> Continuation:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            state = self._current_confirmed(thread_id, version_id, expected_version)
            if self.active_revision(thread_id):
                raise VersionConflict("正在再修改，请先完成问答或取消再修改，再开始执行。")
            existing = self.connection.execute("SELECT * FROM continuations WHERE thread_id=? AND version_id=? AND status IN ('pending','running')", (thread_id, version_id)).fetchone()
            if existing:
                return self._model(existing)
            if state.document.schema_version == 2:
                self._ensure_editable(state.document.id)
            continuation_id = identifier("continuation")
            timestamp = now()
            root = Path(__file__).resolve().parent.parent
            skill_path = (root / "skills" / "plan-panel" / "SKILL.md").as_posix()
            bridge_path = (root / "scripts" / "bridge.py").as_posix()
            message = f"请使用 plan-panel 技能，在当前同一个 Codex 对话继续执行已确认计划。thread_id={thread_id}；plan_id={state.document.id}；version_id={version_id}；version={state.version}；continuation_id={continuation_id}。先读取并 claim 此精确对话/版本的续接请求，使用返回的不可变确认快照和编译提示词完成当前任务，不生成另一份计划、不另开对话。若请求已过期则停止执行并告知用户。执行完成后调用 complete 回传真实结果或失败原因。若已安装的 MCP 接口尚未加载，先读取本地技能 {skill_path}，再通过本地桥接脚本 {bridge_path} 的接口读取、认领并回传本请求。"
            if state.document.schema_version == 2:
                message += " 本请求为论文式目录计划：如果仍在计划模式，不认领、不执行、不重新生成计划，告知用户切回执行模式后重试。否则先读取本地技能并逐叶节点回报真实进度和验证依据；需要调序时先说明并记录理由。"
            continuation = Continuation(id=continuation_id, thread_id=thread_id, plan_id=state.document.id, version_id=version_id, version=state.version, semantic_hash=state.semantic_hash, status="pending", message=message, created_at=timestamp, updated_at=timestamp)
            self.connection.execute("INSERT INTO continuations VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", (continuation.id, thread_id, state.document.id, version_id, "pending", continuation.model_dump_json(), None, None, timestamp, timestamp))
            return continuation

    def claim_continuation(self, thread_id: str, continuation_id: str, claimant_id: str) -> dict:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            row = self._continuation_row(thread_id, continuation_id)
            continuation = self._model(row)
            snapshot_document = self.snapshot(continuation.plan_id, continuation.version_id)["document"]
            runtime = self.runtime(thread_id)
            if continuation.status not in {"pending", "running"}:
                raise VersionConflict("续接请求已经结束、取消或被新版本替代，不能再次认领。")
            if continuation.status == "pending":
                self._current_confirmed(thread_id, continuation.version_id, continuation.version)
            if snapshot_document.schema_version == 2:
                if runtime and runtime["permission_mode"] == "plan":
                    raise ExecutionContextError("当前仍是计划模式，请切换执行模式后重试。", waiting_for_mode=True)
                if not runtime or runtime["permission_mode"] == "unknown" or continuation.execution_turn_id != runtime["turn_id"]:
                    raise ExecutionContextError("桥接尚未收到本次请求的可信 UserPromptSubmit 事件。计划和请求均已保留；恢复宿主钩子后可重试，不能据此判断你仍在计划模式。")
            if continuation.status == "running" and row["claimant_id"] == claimant_id:
                bound_row = self._thread_row(thread_id)
                if bound_row["id"] != continuation.plan_id:
                    raise VersionConflict("续接请求不属于当前对话绑定的计划。")
                snapshot = self.snapshot(continuation.plan_id, continuation.version_id)
                if not snapshot["confirmed"]:
                    raise VersionConflict("原认领快照未确认，不能恢复续接请求。")
                document = snapshot["document"]
                compiled = compile_document(document)
                if compiled.semantic_hash != continuation.semantic_hash:
                    raise VersionConflict("原认领快照与续接请求不一致。")
                return {"continuation": continuation, "document": document, "compiled": compiled, "claim_token": row["claim_token"]}
            if continuation.status != "pending":
                raise VersionConflict("续接请求已经认领、完成或被新版本替代，不能再次认领。")
            state = self._current_confirmed(thread_id, continuation.version_id, continuation.version)
            if state.document.id != continuation.plan_id or state.semantic_hash != continuation.semantic_hash:
                raise VersionConflict("续接请求与当前确认计划不一致。")
            document = self.snapshot(continuation.plan_id, continuation.version_id)["document"]
            compiled = compile_document(document)
            token = secrets.token_urlsafe(32)
            progress = {node_id: NodeProgress() for node_id in self._leaves(document)} if document.schema_version == 2 else {}
            continuation = continuation.model_copy(update={"status": "running", "updated_at": now(), "progress": progress, "execution_turn_id": runtime["turn_id"] if runtime else None, "waiting_for_mode": False, "waiting_for_context": False, "blocked_reason": None})
            self._write_continuation(continuation)
            self.connection.execute("UPDATE continuations SET claimant_id=?, claim_token=? WHERE id=?", (claimant_id, token, continuation.id))
            return {"continuation": continuation, "document": document, "compiled": compiled, "claim_token": token}

    def complete_continuation(self, thread_id: str, continuation_id: str, claim_token: str, status: str, output: str, error: str | None) -> Continuation:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            row = self._continuation_row(thread_id, continuation_id)
            continuation = self._model(row)
            if not row["claim_token"] or not hmac.compare_digest(row["claim_token"], claim_token):
                raise VersionConflict("认领令牌不匹配，不能回传该续接请求。")
            if continuation.status in ("completed", "failed"):
                if (continuation.status, continuation.output, continuation.error) == (status, output, error):
                    return continuation
                raise VersionConflict("续接请求已经结束，重试结果与既有结果不同。")
            if continuation.status != "running":
                raise VersionConflict("只有已认领的运行中请求可以回传结果。")
            document = self.snapshot(continuation.plan_id, continuation.version_id)["document"]
            if document.schema_version == 2 and status == "completed":
                if any(continuation.progress.get(i, NodeProgress()).status != "completed" for i in self._leaves(document)):
                    raise VersionConflict("还有叶节点没有实际完成，不能将整个计划标记完成。")
            continuation = continuation.model_copy(update={"status": status, "output": output, "error": error, "updated_at": now()})
            self._write_continuation(continuation)
            return continuation

    def begin_dispatch(self, thread_id: str, continuation_id: str) -> tuple[Continuation, bool]:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            row = self._continuation_row(thread_id, continuation_id)
            continuation = self._model(row)
            state = self._current_confirmed(thread_id, continuation.version_id, continuation.version)
            if state.document.id != continuation.plan_id or state.semantic_hash != continuation.semantic_hash:
                raise VersionConflict("续接请求与当前确认计划不一致。")
            if continuation.status != "pending":
                raise VersionConflict("仅可投递当前确认版本的待认领续接请求。")
            if continuation.delivery_status in ("sending", "queued"):
                return continuation, False
            continuation = continuation.model_copy(update={"delivery_status": "sending", "delivery_error": None, "updated_at": now(), "waiting_for_context": False, "blocked_reason": None})
            self._write_continuation(continuation)
            return continuation, True

    def finish_dispatch(self, thread_id: str, continuation_id: str, status: str, error: str | None) -> Continuation:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            continuation = self._model(self._continuation_row(thread_id, continuation_id))
            if continuation.delivery_status != "sending":
                return continuation
            continuation = continuation.model_copy(update={"delivery_status": status, "delivery_error": error, "updated_at": now()})
            self._write_continuation(continuation)
            return continuation

    @staticmethod
    def _leaves(document: PlanDocument) -> list[str]:
        from .tree_domain import leaf_ids
        return leaf_ids(document)

    def _ensure_editable(self, plan_id: str) -> None:
        row = self.connection.execute("SELECT 1 FROM continuations WHERE plan_id=? AND status IN ('pending','running')", (plan_id,)).fetchone()
        if row:
            raise VersionConflict("计划已排队或正在执行，目录编辑已锁定；先取消未领取请求或在 Codex 中停止执行。")

    def runtime(self, thread_id: str) -> dict | None:
        with self.lock:
            row = self.connection.execute("SELECT * FROM thread_runtime WHERE thread_id=?", (thread_id,)).fetchone()
            return dict(row) if row else None

    def record_claim_blocked(self, thread_id: str, continuation_id: str, error: ExecutionContextError) -> None:
        """Persist an actual failed claim after its transaction has rolled back."""
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            item = self._model(self._continuation_row(thread_id, continuation_id))
            if item.status != "pending":
                return
            item = item.model_copy(update={"waiting_for_context": not error.waiting_for_mode, "waiting_for_mode": error.waiting_for_mode, "blocked_reason": str(error), "delivery_status": "not_sent", "updated_at": now()})
            self._write_continuation(item)

    def start_turn(self, thread_id: str, turn_id: str, mode: str, prompt: str = "") -> None:
        """Called only by the local trusted hook, never exposed as a browser API."""
        import re
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            self.connection.execute("INSERT INTO thread_runtime VALUES (?,?,?,?,?) ON CONFLICT(thread_id) DO UPDATE SET permission_mode=excluded.permission_mode, turn_id=excluded.turn_id, updated_at=excluded.updated_at, last_error=''", (thread_id, mode, turn_id, now(), ""))
            state = self.thread_plan(thread_id)
            # permission_mode describes tool permissions, not the desktop's
            # collaboration mode. Record only a baseline here; ordinary replies
            # never create a plan/version. Stop must supply a formal plan block.
            revision_match = re.search(r"revision_id=([A-Za-z0-9_-]+)", prompt)
            revision = None
            if revision_match:
                row = self.connection.execute("SELECT payload FROM plan_revisions WHERE thread_id=? AND id=? AND status IN ('pending','discussing')", (thread_id,revision_match[1])).fetchone()
                if row:
                    revision = PlanRevision.model_validate_json(row['payload']).model_copy(update={'status':'discussing','received_turn_id':turn_id,'updated_at':now()})
                    self._write_revision(revision)
            else:
                active_revision = self.active_revision(thread_id)
                if active_revision and active_revision.status == 'discussing':
                    revision = active_revision
            base_version = revision.version if revision else state.version if state else 0
            revision_id = revision.id if revision else revision_match[1] if revision_match else None
            self.connection.execute("INSERT OR IGNORE INTO plan_captures(thread_id,turn_id,base_version,created_at,revision_id) VALUES (?,?,?,?,?)", (thread_id,turn_id,base_version,now(),revision_id))
            match = re.search(r"continuation_id=([A-Za-z0-9_-]+)", prompt)
            if match:
                row = self.connection.execute("SELECT * FROM continuations WHERE thread_id=? AND id=? AND status='pending'", (thread_id, match[1])).fetchone()
                if row:
                    update = {"execution_turn_id": turn_id if mode not in {"plan", "unknown"} else None, "waiting_for_mode": mode == "plan", "waiting_for_context": mode == "unknown", "blocked_reason": None, "updated_at": now()}
                    if mode == "plan":
                        update["delivery_status"] = "not_sent"
                    item = self._model(row).model_copy(update=update)
                    self._write_continuation(item)

    def hook_error(self, thread_id: str, message: str) -> None:
        with self.lock, self.connection:
            self.connection.execute("UPDATE thread_runtime SET last_error=?,updated_at=? WHERE thread_id=?", (message, now(), thread_id))

    def capture_status(self, thread_id: str, turn_id: str) -> dict | None:
        with self.lock:
            row = self.connection.execute("SELECT turn_id,base_version,status,error,source_kind,source_item_id,revision_id FROM plan_captures WHERE thread_id=? AND turn_id=?", (thread_id, turn_id)).fetchone()
            return dict(row) if row else None

    def mark_capture_result(self, thread_id: str, turn_id: str, status: str, error: str = "") -> None:
        if status not in {"ignored", "error"}:
            raise ValueError("非法捕获结果。")
        with self.lock, self.connection:
            self.connection.execute("UPDATE plan_captures SET status=?,error=? WHERE thread_id=? AND turn_id=? AND message_hash IS NULL", (status, error, thread_id, turn_id))

    def capture_plan(self, thread_id: str, turn_id: str, message: str, *, source_kind: str = "final_text", source_item_id: str | None = None) -> dict:
        from .tree_domain import parse_proposed_plan, validate_tree
        document = parse_proposed_plan(message)
        if document is None:
            return {"status": "ignored"}
        digest = hashlib.sha256(message.encode("utf-8")).hexdigest()
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            capture = self.connection.execute("SELECT * FROM plan_captures WHERE thread_id=? AND turn_id=?", (thread_id, turn_id)).fetchone()
            runtime = self.runtime(thread_id)
            if not capture or not runtime or runtime["turn_id"] != turn_id:
                return {"status": "ignored"}
            if capture["message_hash"]:
                return {"status": capture["status"], "duplicate": True}
            revision = None
            if capture['revision_id']:
                row = self.connection.execute("SELECT payload FROM plan_revisions WHERE thread_id=? AND id=? AND status='discussing'", (thread_id,capture['revision_id'])).fetchone()
                if not row:
                    return {'status':'ignored','reason':'revision_no_longer_active'}
                revision = PlanRevision.model_validate_json(row['payload'])
            state = self.thread_plan(thread_id)
            if state:
                document.id = state.document.id
                document.original_request = state.document.original_request
                document.constraints = state.document.constraints
                document.assumptions = state.document.assumptions
            if any(i.severity == "error" for i in validate_tree(document)):
                raise VersionConflict("生成的目录无效；聊天中的原计划已保留。")
            active = state and self.connection.execute("SELECT 1 FROM continuations WHERE plan_id=? AND status IN ('pending','running')", (state.document.id,)).fetchone()
            conflict = (state.version if state else 0) != capture["base_version"] or bool(active)
            if state and not conflict:
                try:
                    check_agent_locks(state.document, document)
                except LockedFieldError:
                    conflict = True
            status = "candidate" if conflict else "applied"
            if not conflict:
                if state:
                    self._save(document.id, document, state.version)
                else:
                    self._create(document)
                    binding = make_binding(thread_id, document.title, document.goal, [])
                    self.connection.execute("INSERT INTO thread_bindings VALUES (?,?,?)", (thread_id, document.id, binding.model_dump_json()))
            self.connection.execute("UPDATE plan_captures SET message_hash=?,status=?,document=?,error='',source_kind=?,source_item_id=? WHERE thread_id=? AND turn_id=?", (digest, status, document.model_dump_json(), source_kind, source_item_id, thread_id, turn_id))
            if revision:
                result_version = self.thread_plan(thread_id).version_id if status == 'applied' else None
                self._write_revision(revision.model_copy(update={'status':'completed' if status=='applied' else 'candidate','result_turn_id':turn_id,'result_version_id':result_version,'updated_at':now()}))
            return {"status": status}

    def candidates(self, thread_id: str) -> list[dict]:
        with self.lock:
            return [{"turn_id": r["turn_id"], "base_version": r["base_version"], "document": json.loads(r["document"]), "created_at": r["created_at"], "reason": r["error"]} for r in self.connection.execute("SELECT * FROM plan_captures WHERE thread_id=? AND status='candidate' ORDER BY created_at DESC", (thread_id,))]

    def recover_plan_candidate(self, thread_id: str, source_turn_id: str, message: str, expected_version: int) -> dict:
        """Explicit repair from a visible final answer, never a fabricated hook.

        Keep the current document intact: the user must compare and adopt this
        candidate. This local repair operation does not authorize execution.
        """
        from .tree_domain import parse_proposed_plan, validate_tree
        document = parse_proposed_plan(message)
        if document is None or any(i.severity == "error" for i in validate_tree(document)):
            raise ValueError("恢复内容必须是完整、有效的正式计划。")
        digest = hashlib.sha256(message.encode("utf-8")).hexdigest()
        recovery_id = "recovered-" + source_turn_id
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            state = self.state(self._thread_row(thread_id))
            if state.version != expected_version:
                raise VersionConflict("版本变化，请重新比较恢复内容。")
            prior = self.connection.execute("SELECT * FROM plan_captures WHERE thread_id=? AND turn_id=?", (thread_id, recovery_id)).fetchone()
            if prior:
                if prior["message_hash"] != digest:
                    raise VersionConflict("此恢复来源已有不同内容。")
                return {"status": prior["status"], "duplicate": True}
            document.id = state.document.id
            document.constraints = state.document.constraints
            document.assumptions = state.document.assumptions
            self.connection.execute("INSERT INTO plan_captures(thread_id,turn_id,base_version,message_hash,status,document,error,created_at) VALUES (?,?,?,?,?,?,?,?)", (thread_id, recovery_id, expected_version, digest, "candidate", document.model_dump_json(), "从当前对话中已生成但漏同步的正式计划恢复；保留现有目录，采用前请比较。", now()))
            return {"status": "candidate", "turn_id": recovery_id}

    def resolve_candidate(self, thread_id: str, turn_id: str, expected_version: int, accept: bool) -> dict:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            row = self.connection.execute("SELECT * FROM plan_captures WHERE thread_id=? AND turn_id=? AND status='candidate'", (thread_id, turn_id)).fetchone()
            if not row:
                raise NotFoundError("候选计划不存在或已处理。")
            state = self.state(self._thread_row(thread_id))
            if state.version != expected_version:
                raise VersionConflict("版本变化，请重新比较。")
            self._ensure_editable(state.document.id)
            if accept:
                document = PlanDocument.model_validate_json(row["document"])
                document.id = state.document.id
                self._save(document.id, document, expected_version)
            self.connection.execute("UPDATE plan_captures SET status=? WHERE thread_id=? AND turn_id=?", ("applied" if accept else "dismissed", thread_id, turn_id))
            if row['revision_id']:
                revision = self._revision(thread_id,row['revision_id'])
                self._write_revision(revision.model_copy(update={'status':'completed' if accept else 'cancelled','result_version_id':self.thread_plan(thread_id).version_id if accept else None,'updated_at':now()}))
            return {"state": self.state(self._thread_row(thread_id))}

    def cancel_continuation(self, thread_id: str, continuation_id: str) -> Continuation:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            item = self._model(self._continuation_row(thread_id, continuation_id))
            if item.status == "cancelled":
                return item
            if item.status != "pending":
                raise VersionConflict("只能取消未领取请求；运行中请使用 Codex 的停止按钮。")
            item = item.model_copy(update={"status": "cancelled", "updated_at": now()})
            self._write_continuation(item)
            return item

    def finish_turn(self, thread_id: str, turn_id: str, interrupted: bool = False) -> None:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            for row in self.connection.execute("SELECT * FROM continuations WHERE thread_id=? AND status='running'", (thread_id,)).fetchall():
                item = self._model(row)
                if item.execution_turn_id != turn_id:
                    continue
                message = "用户停止了当前执行。" if interrupted else "执行回合已结束，但尚未回传完整结果；请检查已完成项目后重新确认。"
                progress = {key: value.model_copy(update={"status": "interrupted", "updated_at": now()}) if value.status == "running" else value for key, value in item.progress.items()}
                item = item.model_copy(update={"status": "interrupted", "progress": progress, "error": message, "updated_at": now()})
                self._write_continuation(item)

    def report_progress(self, thread_id: str, continuation_id: str, node_id: str, payload) -> Continuation:
        with self.lock, self.connection:
            self.connection.execute("BEGIN IMMEDIATE")
            row = self._continuation_row(thread_id, continuation_id)
            item = self._model(row)
            if not row["claim_token"] or not hmac.compare_digest(row["claim_token"], payload.claim_token):
                raise VersionConflict("认领令牌不匹配。")
            if item.status != "running" or item.version_id != payload.version_id:
                raise VersionConflict("只能更新当前运行的精确确认版本。")
            document = self.snapshot(item.plan_id, item.version_id)["document"]
            leaves = self._leaves(document)
            if document.schema_version != 2 or node_id not in leaves:
                raise VersionConflict("进度只可回报此版本的最末级任务。")
            old = item.progress.get(node_id, NodeProgress())
            incoming = NodeProgress(**payload.model_dump(exclude={"claim_token", "version_id"}))
            incoming.adjustment_reason = incoming.adjustment_reason or old.adjustment_reason
            if old.model_dump(exclude={"updated_at"}) == incoming.model_dump(exclude={"updated_at"}):
                return item
            allowed = {"pending": {"running"}, "running": {"completed", "failed", "interrupted"}, "completed": set(), "failed": set(), "interrupted": set()}
            if incoming.status not in allowed[old.status]:
                raise VersionConflict(f"不能从 {old.status} 改为 {incoming.status}。")
            if incoming.status == "running":
                if any(v.status == "running" for v in item.progress.values()):
                    raise VersionConflict("先结束正在处理的任务，再开始下一项。")
                node = next(n for n in document.tree if n.id == node_id)
                if any(item.progress[d].status != "completed" for d in node.depends_on):
                    raise VersionConflict("前置依赖尚未完成。")
                first = next((i for i in leaves if item.progress[i].status != "completed"), None)
                if node_id != first and not incoming.adjustment_reason.strip():
                    raise VersionConflict("调序前须说明原因，并提供 adjustment_reason。")
            if incoming.status == "completed" and (not incoming.output.strip() or not incoming.evidence.strip()):
                raise VersionConflict("完成节点必须包含实际产出及验证依据。")
            if incoming.status in ("failed", "interrupted") and not incoming.output.strip():
                raise VersionConflict("请说明失败或中断原因。")
            incoming.updated_at = now()
            incoming.adjustment_reason = incoming.adjustment_reason or old.adjustment_reason
            item.progress[node_id] = incoming
            item.updated_at = now()
            self._write_continuation(item)
            return item
