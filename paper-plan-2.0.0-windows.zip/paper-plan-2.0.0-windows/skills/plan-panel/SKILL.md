---
name: plan-panel
description: 在当前 Codex 对话中生成论文式多级计划目录，并依据用户编辑确认的版本继续执行、逐项回报进度。适用于计划面板、目录计划和携带 continuation_id 的继续请求。
---

# 论文式计划

面板属于当前对话，标题树同时决定工作组织和结果汇报结构。只使用可信宿主元数据或 CODEX_THREAD_ID 获取当前对话 ID，不从标题猜测，不读取其他聊天或扫描会话数据库。

## 在计划模式生成

本插件的 UserPromptSubmit 和 Stop 钩子负责自动呈现与保存。讨论、澄清照常进行；形成正式计划时：

`permission_mode` 表示工具权限，不等同于宿主的 Plan/Default 协作模式；桌面计划模式也可能返回 `default`。始终依据宿主当前协作模式约束行动。宿主可能将正式计划保存为独立 `plan` 条目，此时 Stop 的普通回复字段为空。钩子先解析完整正式计划块，未取得时通过官方只读 `thread/items/list` 查询事件指定的精确对话、精确轮次，仅保存原生 `plan` 条目；普通问答不产生计划版本。读取过程不会启动模型、恢复对话或扫描 transcript 文件。

1. 调用 `get_plan_panel_url` 读取当前 thread_id 对应的地址，在当前对话右侧用 `open_in_codex` 打开，不指定其他 threadId。也可使用钩子给出的同一地址。UI 返回 queued 不代表已经显示。
2. 最终输出一个完整 `<proposed_plan>` 块：一个 `#` 总标题，`##`、`###` 等简短任务标题，正文保存具体要求、预期产出、验收条件。父标题组织阶段、要求对子项生效；独立工作放在最末级。代码示例放围栏中。
3. Stop 钩子保存本轮正式计划，面板自动刷新。不要在计划模式调用写入工具、写文件、代替用户确认或开始执行。保存失败时仍保留完整聊天计划。新生成结果与人工编辑冲突时作为候选，由用户比较。

首版由用户手动切回执行模式，再点击面板“开始执行”。不能通过发消息声称已切换模式。

## 再修改与提问

面板“再修改”用于把用户编辑后的目录交回同一对话重新梳理。现有投递接口不能切换宿主协作模式，用户需先手动切到计划模式，再发送提问请求。

1. 收到 `revision_id` 后，核对可信 thread_id；如果当前不是 Plan 模式，只提示用户切换后继续，不声称已切换，不执行计划。
2. 用只读 `get_plan_revision(thread_id, revision_id)` 获取用户提交的不可变目录和 `notes`。工具未加载时使用本地桥接 `revision --thread <id> --revision-id <id>`。请求已取消或被替代时停止。
3. 先依据编辑后的结构、说明和用户重点提出2–3个实质问题，优先使用计划模式的提问工具。不要只询问“是否开始执行”；等待回答，再消除影响计划的缺口和取舍。
4. 问答不生成新的正式计划、不实施项目变更。需求明确后才输出一份完整 `<proposed_plan>`，沿用用户要求及锁定约束。新计划仍交回右侧等待用户确认。
5. `draft_changed` 表示提交请求后用户又编辑了目录。说明这一情况，不覆盖人工修改；系统会将生成结果保留为候选。整个问答过程保留首次提交版本作为冲突检测基线。取消再修改不会删除当前目录。

## 按确认版本执行

1. 核对续接消息的 thread_id 与当前可信对话 ID 一致。如果仍在计划模式，不领取、不执行、不生成替代计划；告知用户切换模式后在面板重试。
2. 读取 `list_thread_continuations`，仅处理指定 continuation_id。用稳定 claimant_id（`<thread_id>:<continuation_id>`）调用 `claim_thread_continuation`。未确认、取消、过期或其他领取者占用时停止；不创建独立 `codex exec`、新对话或替代计划。
3. 使用返回的不可变 `document` 与 `compiled.text`。claim_token 只保留于执行状态，不展示给用户。编辑锁由服务维护，不绕过。
4. 对 v2 计划，父标题仅组织阶段；最末级节点才执行。开始每个叶节点前调用 `report_node_progress`，提供 thread_id、continuation_id、version_id、claim_token、node_id 和 status=`running`。默认目录顺序，必要调序须先在当前对话说明原因，并传 adjustment_reason；有未完成前置依赖时不得开始。
5. 实际完成后回报 status=`completed`、output（实际产物或结果）及 evidence（验证依据、文件路径或检查结果）。失败回报 `failed` 和原因。不要为未做的工作补记成功。改变目标、删减任务或修改验收条件，报告无法按当前版本完成并交回用户重新确认。
6. 所有叶节点真实完成后调用 `complete_thread_continuation` 回报 completed 和按目录组织的结果；无法完成时回报 failed、已完成部分和原因。v1 旧计划仍支持整次回报，不要求节点接口。用户中断时 Interrupt 钩子记录中断、解锁；已排队不等于运行，已领取不等于完成。

## MCP 尚未重载时

本地回退位置由本技能所属插件根目录的 `runtime.json` 提供：`python` 是解释器，`project` 是安装目录。读取这两个值，使用 `<python> <project>/scripts/bridge.py`；不要假设盘符、用户名或安装位置。钩子提供的绝对路径也可直接使用。

`get|panel|confirmed|requests|request|claim|complete|dispatch|progress` 都传 `--thread`。领取传 `--continuation-id` 与 `--claimant-id`。节点回报传 `--continuation-id`、`--node-id` 和 `--payload`。payload 是本地 UTF-8 JSON 文件，包含 version_id、claim_token、status、output、evidence 和可选 adjustment_reason；不要把私密令牌拼入命令行。complete 使用相同 payload 文件方式。

服务不可用时先重试原生 MCP，连接被拒绝时会尝试恢复服务。Windows 不得从 `CodexSandbox*` 隔离账户启动生产服务，否则无法访问用户的桌面对话；需要 shell 恢复时，用宿主批准的桌面用户执行环境运行 `start.ps1 -NoBrowser`。不自动改为 Mock。

## 非计划模式中的显式编辑请求

先读取当前版本，再用 `create_thread_plan` 或 `update_thread_plan` 保存 schema_version=2 的标题树，传 expected_version 并保留用户内容。v2 使用 tree 数组（id、parent_id、order、title、details、output、acceptance_criteria、depends_on）；nodes、edges、output_outline 留空。执行中拒绝修改；版本冲突重新读取比较，不覆盖。已有 v1 计划保持原格式，不隐式迁移历史确认版本。
