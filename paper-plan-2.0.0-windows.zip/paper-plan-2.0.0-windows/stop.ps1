﻿$ErrorActionPreference = 'Stop'
$pidFile = Join-Path $PSScriptRoot 'data\app.pid'
if (-not (Test-Path -LiteralPath $pidFile)) { Write-Host 'No managed application is running.'; exit 0 }
$serverProcessId = [int](Get-Content -LiteralPath $pidFile -Raw).Trim()
$serverProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $serverProcessId"
if (-not $serverProcess) { Remove-Item -LiteralPath $pidFile -ErrorAction SilentlyContinue; Write-Host 'Application already stopped.'; exit 0 }
$expectedWorkspace = [regex]::Escape((Join-Path $PSScriptRoot '.venv\Scripts\python.exe'))
$expectedEntry = [regex]::Escape((Join-Path $PSScriptRoot 'scripts\run_server.py'))
$legacyMatches = $serverProcess.CommandLine -match $expectedWorkspace -and $serverProcess.CommandLine -match 'backend\.app:app'
$paperMatches = $serverProcess.CommandLine -match $expectedEntry
if (-not $legacyMatches -and -not $paperMatches) {
    throw 'Process identity does not match this workspace. No process was stopped.'
}
$stopMarker = Join-Path $PSScriptRoot 'data\app.stop'
Set-Content -LiteralPath $stopMarker -Value $serverProcessId -Encoding ASCII
try { Stop-Process -Id $serverProcessId -ErrorAction Stop }
catch {
    & taskkill.exe /PID $serverProcessId /F
    if ($LASTEXITCODE -ne 0) { throw 'Could not stop the verified application process.' }
}
if (Test-Path -LiteralPath $pidFile) { Remove-Item -LiteralPath $pidFile -ErrorAction SilentlyContinue }
Write-Host 'Application stopped. Saved plans are retained.'
